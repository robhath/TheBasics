#!ruby

if $0 == __FILE__ then
  $LOAD_PATH.unshift File.join(File.dirname($0), './lib')
end

require 'XML.rb'
require 'Stringx.rb'

  def count_words(x, word_counts = {})
    x.each do |y|
      if y.tag.empty? then
        str = y.pcdata.force_encoding("utf-8")
        begin
        #~ while pos = (str =~ /(?<=\b)([A-Za-z][-.0-9_A-Za-z]+)('d|'s|'ll|'t|'ve|'re)*(?=\b)/) do
          while pos = (str =~ /(?<=\b)([\p{alpha}][-.\p{word}]+)('d|'s|'ll|'t|'ve|'re)*(?=\b)/) do
            pre = $`
            w = $&
            str = $'
            if pre[-1,1] == "&" && str =~ /^\S*;/ then
              word_counts["&" + w + ";"] = 0 unless word_counts.has_key?("&" + w + ";")
              word_counts["&" + w + ";"] += 1
            else
              w.downcase! if w =~ /^[A-Z][a-z]+$/
              word_counts[w] = 0 unless word_counts.has_key?(w)
              word_counts[w] += 1
            end
          end
        rescue
          $stderr.puts "ERROR: not UTF-8 '#{str}'"
        end
      end
    end
  end  # count_words
  

  

if __FILE__ == $0 then
  
  if ARGV.length < 1 then
    $stderr.puts "get_words.rb <path, file or directory> ...  [-depth <integer>] [-stay]"
    exit
  else
    line1 = "Get Words  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    puts line1
    puts "=" * line1.length
    puts
  end
  
  recursive_depth = 1
  stay_in_domain = false
  current_domain = nil
  visited = []
  
  if i = ARGV.index("-depth") then
    rd = ARGV[i+1].to_i(0)
    recursive_depth = rd if rd > -1 && rd < 2048
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-stay") then
    stay_in_domain = true
  end

  word_counts = {}
  links = []
  
  x = nil
  indexfn = ""
  ARGV.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
    current_depth = 0
  
    links = []
    if arg =~ /^\s*http/ then
      links << arg
    elsif File.directory?(arg) then
      links += Dir.glob("#{arg}/**/*.{html,xml}")
    else
      links << arg
    end
    
    recursion_cutoff = links.length
    i = 0
    current_domain = links[i].get_link_parts()["domain"] unless current_domain
    while i < links.length do
      $stderr.puts "#{links[i]} not in same domain, skipping..." if stay_in_domain && links[i].get_link_parts()["domain"] != current_domain
      if stay_in_domain && links[i].get_link_parts()["domain"] != current_domain then
        i += 1
        next 
      end
      x = XML.parse_link(links[i])
      count_words(x, word_counts)
      visited << links[i]
      
      cur_path = File.dirname(links[i])
      if cur_path == "." then
        cur_path = ""
      else
        cur_path << "/"
      end
      
      if current_depth < recursive_depth then
        more_links = x.get_links
        more_links.each do |link|
          if link =~ /\.html\?/ then
            # ignore it
          elsif link =~ /^\s*http/ then
            links << link unless links.index {|obj| obj.downcase == link.downcase }
            #~ $stderr.puts "!!!circular:#{link}" if links.index {|obj| obj.downcase == link.downcase }
          else
            links << (cur_path + link) unless links.index {|obj| obj.downcase == (cur_path + link).downcase }
            #~ $stderr.puts "!!!circular:#{link}" if links.index {|obj| obj.downcase == (cur_path + link).downcase }
          end
        end
        if i >= recursion_cutoff then
          current_depth += 1 
          recursion_cutoff = links.length
        end
      end
      
      i += 1
    end
  end
  
  puts "Words in alphabetic order"
  puts "========================="
  word_counts.sort {|a, b| a[0].downcase <=> b[0].downcase }.each do |key, value|
    puts "#{key}  #{value}"
  end
  puts
  
  puts "Words in frequency order"
  puts "========================"
  word_counts.sort {|a, b| a[1] <=> b[1] }.each do |key, value|
    puts "#{key}  #{value}"
  end
  puts
  
  puts "links visited"
  puts "============="
  puts visited.join("\n")
  
end
