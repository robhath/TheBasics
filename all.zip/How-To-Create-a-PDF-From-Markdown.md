How to Create a PDF from Markdown Files:

1. Add HTML link targets in your markdown files for each example, figure, listing, and table you wish to
   include in the table of contents of the PDF. The following are example link targets for each type:

   ```
   <a name="example4.1" title="Example 4.1 Creating tasks"></a>

   <a name="fig10.6" title="Figure 10.6 The communication paths from the application tasks to the cloud server, and back again"></a>

   <a name="list10.13" title="Listing 10.13 Pseudo code demonstrating how a task notification can be used to pass a value to a task"></a>

   <a name="tbl5" title="Table 5 The Effect of the uxBitsToWaitFor and xWaitForAllBits Parameters"></a>
   ```

   Note that these link targets are best placed before the items to be referenced, since browsers and PDF
   readers display the location of the target at the extreme top of the view when they follow the links.

1. In the directory that contains the markdown files, run:

   ```
   md-links.rb -o book-toc.md --nofn
   ```

   This creates a file "book-toc.md" which contains links to all section headings and to the link targets
   you added in the previous step[^1]. The "--nofn" parameter causes the script to not add file references for 
   these links--since we will be creating the PDF from a single file compiled from all those you wish to 
   include, these original file references will not work.

1. Edit the table of contents file you just created ("book-toc.md") to remove the links to items you do
   not want to include in the table of contents for the PDF. For example, for the FreeRTOS Kernel book,
   the existing table of contents file contains section headings. For the FreeRTOS Kernel book, for 
   example, you will delete links for content which appears under "Contributing Guidelines", 
   "FreeRTOS-Kernel-Book", "Mastering the FreeRTOS™\[^1\]\[^2\] Real Time Kernel" (title page), and the
   existing "Table of Contents" (which currently appears after the links to section headings.

1. Prepare a "manifest" file which contains the names of the files to be compiled into a single file ready
   to be converted to PDF. Enter one filename per line. Comment lines can be included and must begin with 
   a '#' (hash) character in the first non-blank position of the line. Blank lines are ignored. For
   example, the following manifest was used for the FreeRTOS Kernel Book:

   ```
   booktitle.md                                                                                                                             2 copyright.md
   dedication.md
   abbreviations.md
   book-toc.md
   ch01.md
   ch02.md
   ch03.md
   ch04.md
   ch05.md
   ch06.md
   ch07.md
   ch08.md
   ch09.md
   ch10.md
   ch11.md
   ch12.md
   ch13.md
   ```

   Note the inclusion of the table of contents file ("book-toc.md") which you created and edited
   in the previous steps.

1. In the directory that contains the markdown files, run:

   ```
   md-compile.rb  -m manifest  -o book.md
   ```

   where "manifest" is the name of the manifest file you created in the previous step, and "book.md" is 
   the name of the compiled markdown file to be created. Note that the compilation script will remove 
   the file reference portion from all local links in the compiled file, so that these links will point 
   to the targets within the compiled markdown file, and ultimately in the PDF. The script reports the 
   number of links changed in this way.

   For the FreeRTOS Kernel book, I edit the compiled file ("book.md") to remove the footnotes in the
   book title, and make those two footnotes into three simple lines. (I remove the footnote definition
   syntax at the beginning, and enter three spaces at the end of each of the three lines to enforce a 
   carriage-return.)

1. If you haven't already, install an extension to create PDF output in your Visual Studio app. For the
   FreeRTOS Kernel book, I installed "Markdown PDF". 

   In the settings for this extension, edit how you want the PDF's page header and footer to look. For 
   the FreeRTOS Kernel book, I make the header contain the book name and remove the date. For the footer, 
   I keep the page number and total pages. In particular, I:

   + check the box "Markdown-pdf: Display Header Footer".
   + edit the box under "Markdown-pdf: Footer Template" to contain-   
     `<div style="font-size: 9px; margin: 0 auto;"> <span class='pageNumber'></span> / <span class='totalPages'></span></div>`
   + edit the box under "Markdown-pdf: Header Template" to contain-   
     `<div style="font-size: 9px; margin-left: auto; margin-right: 1cm; ">Mastering the FreeRTOS Real Time Kernel</div>`


1. Open the compiled markdown file in Visual Studio. If you're running Visual Studio on a different
   environment, note that you must also bring over any support files referenced in the combined file 
   (for example, images). Use your installed extension to create a PDF. (For Markdown PDF, press \<F1\>,
   then choose "Markdown PDF: Export (pdf)". The PDF file will be created in the same directory as the
   combined markdown file.)

   
[^1]: The "md-links.rb" script also reports any "broken" links it finds in any markdown file in the specified
directory. It can be used during development of the markdown files to identify any such broken links.
