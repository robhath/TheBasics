#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'

if __FILE__ == $0 then
  
  get_args(min: 1, nmin: 1, syntax: "tag-fnr.rb <file-or-directory-name>... -f <find-tag> -r <replace-tag> -ext <file-extensions> -o <output-file-extension>")
  files = []
  changed_files = []
  extensions = $args["-ext"] || "html,HTML,xhtml,XHTML"
  output_extension = $args["-o"] || "xml"

  findRE = /<!--|-->|<(\/)?(\w+)(\s|>|$)/
  fnrs = {}

  if $args["-f"] then
    if File.file?($args["-f"]) then
      
    else
      fnrs[$args["-f"]] = ($args["-r"] || "")
    end
  else
    # set of substitutions for html to DocBook
    fnrs["b"] = ["emphasis", " role=\"bold\""]  # Array
    fnrs["em"] = "emphasis"

    fnrs["h1"] = "chapter"
    fnrs["h2"] = ["section", " lvl=\"2\""]  # Array
    fnrs["h3"] = ["section", " lvl=\"3\""]  # Array
    fnrs["h4"] = ["section", " lvl=\"4\""]  # Array
    fnrs["h5"] = ["section", " lvl=\"5\""]  # Array

    fnrs["i"] = "emphasis"
    fnrs["kbd"] = "userinput"
    fnrs["li"] = "listitem"
    fnrs["ol"] = "orderedlist"
    fnrs["p"] = "para"
    fnrs["pre"] = ["programlisting", " language=\"\""]  # Array
    fnrs["strong"] = ["emphasis", " role=\"bold\""]  # Array
    fnrs["sub"] = "subscript"
    fnrs["sup"] = "superscript"
    fnrs["td"] = "entry"
    fnrs["tr"] = "row"
    fnrs["tt"] = "code"
    fnrs["ul"] = "itemizedlist"
  end
 
  # $stderr.puts fnrs.to_a.join("; ")  # debug

  if $nargs.empty? then
    files += Dir.glob("./**/*.{#{extensions}}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{#{extensions}}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{#{extensions}}")
       else
         files << narg
       end
     end  # $nargs.each
  end

  count = 0

  files.each do |f|
    buffer = String.new
    changed = false
    $stderr.puts ">>> " + f
    File.open(f, "r") do |input|

      in_comment = false
      while line = input.gets do
        line.gsub!(findRE) do |str|
          # $stderr.puts "str[#{str}] 1[#{$1}] 2[#{$2}] 3[#{$3}]"
          if in_comment then
            $stderr.print "."
            in_comment = false if str == "-->"
            str
          elsif str == "<!--" then
            $stderr.print "."
            in_comment = true
            str
          elsif $2 && fnrs[$2] then
            changed = true
            $stderr.print "*"
            count += 1
            repl = fnrs[$2]
            if fnrs[$2].kind_of?(Array) then
              if $1 then
                repl = fnrs[$2][0]
              else
                repl = fnrs[$2].join("")
              end
            end
            "<#{$1}#{repl}#{$3}"
          else
            changed = false
            $stderr.print "."
            str
          end
        end
        buffer << line
      end
    end
    $stderr.puts
    if changed then
      changed_files << f
      new_fn = f.sub(/\.\w+$/, ".#{output_extension}")
      File.open(new_fn, "w") do |output|
        output.print buffer
      end
    end
  end

  $stderr.puts "#{count.to_s} instances replaced"
end

