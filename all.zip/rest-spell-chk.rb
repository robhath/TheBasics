#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'restructured.rb'
require 'binary_search.rb'


  $words = [] if $words.nil?

class RESTSpellChecker < Restructured
  
  @@outside = Regexp.new(/(^|\s)(#{@@quote_chars.join("|")})(\S)|(?<=\b)([A-Za-z][a-z]+)('d|'s|'ll|'t|'ve|'re)*(?=\b)/)
  
  if $words.empty? then
    # assume word list all downcase and already sorted...
    #~ File.open("#{ $0[/.+\//] || ""}words.txt", "r:ISO-8859-1:UTF-8") do |input| 
    File.open("#{File.dirname(File.expand_path(__FILE__))}/lib/words.txt", "r:ISO-8859-1:UTF-8") do |input| 
      while line = input.gets do
        if line =~ /^\s*#/ then
          # comment
        else
          $words << line.chomp
        end
      end
    end
    #~ $stderr.puts $words.length
    #~ $stderr.puts $words[-1]
  end


  def initialize()
    @inside_literal = nil
    @current_re = @@outside
    @entering_literal = true
    super
  end  # initialize
  

  def check(str, start_offset = 1)
    #~ $stderr.puts "check(#{str}, #{start_offset})"  # debug
    len = str.length
    offset = len
    
    while pos = (str =~ @current_re) do
      matched = $&
      str = $'
      pre = $`
      
      #~ $stderr.puts ">>>#{matched}<<<"
      if @inside_literal then
        @inside_literal = nil
        @current_re = @@outside
        offset = str.length
        next
      elsif matched =~ /(^|\s)(#{@@quote_chars.join("|")})(\S)/ then
        @inside_literal = $2
        @current_re = /(\S)#{@inside_literal == "|" ? "\\|" : @inside_literal}(?=\s|#{@@quote_chars.join("|")}|$)/
        offset = str.length
        next
      end
      
      w = matched.downcase
      #~ if $words.bsearch {|val| val >= w } == w then
      if $words.binary_search(w) then
        #~ $stderr.puts "#{w} okay"
      else
        puts "\n>>>File: #{$fn}" unless $found
        puts "#{w} bad loc=#{@line},#{len-offset+pos+start_offset}"
        if $error_file then
          $error_out = File.open($error_file, "w") unless $error_out
          $error_out.puts "#{$fn}:#{@line}:#{len-offset+pos+start_offset}:#{w}"
        end
        $found = true
      end
      offset = str.length
    end
  end  # check
  
  
  def do_directive(buffer)
    #~ $stderr.puts "directive/literal"
    # don't check!
  end  # do_directive
  
  
  def do_literal(buffer)
    #~ $stderr.puts "literal block/construct" + ": " + @entering_literal.to_s
    if @entering_literal then
      check(buffer)
      @entering_literal = false
    else
      # don't check!
    end
  end  # do_literal
  
  
  def do_enum_list(buffer)
    #~ $stderr.puts "enumerated list"
    check(buffer)
  end  # do_enum_list
  
  
  def do_bullet_list(buffer)
    #~ $stderr.puts "bullet list"
    check(buffer)
  end  # do_bullet_list
  
  
  def do_option_list(buffer)
    #~ $stderr.puts "option list"
    if buffer =~ /^\s*\S.*( {2,}|\t)/ then
      check($', $&.length+1)
    else
      check(buffer)
    end
  end  # do_option_list
  
  
  def do_title(buffer)
    #~ $stderr.puts "title"
    check(buffer)
  end  # do_title
  
  
  def do_field_list(buffer)
    #~ $stderr.puts "field list"
    check(buffer)
  end  # do_field_list
  
  
  def do_defn_list(buffer)
    #~ $stderr.puts "definition list"
    check(buffer)
  end  # do_defn_list
  
  
  def do_block_quote(buffer)
    #~ $stderr.puts "block quote"
    check(buffer)
  end  # do_block_quote
  
  
  def do_paragraph(buffer)
    #~ $stderr.puts "paragraph"
    check(buffer)
  end  # do_paragraph
  
  
  def do_blank(line)
    #~ $stderr.puts "blank"
    @inside_literal = nil
    @current_re = @@outside
    @entering_literal = true
  end  # do_blank
  
  
  def do_table(buffer)
    #~ $stderr.puts "table"
    check(buffer)
  end  # do_table
  
    
end  # RESTSpellChecker


if __FILE__ == $0 then
  
  $error_file = nil
  $error_out = nil
  $fn = nil
  $found = false

  if ARGV.length < 1 then
    $stderr.puts "rest-spell-chk.rb <file or directory> ... [--edit]"
    exit
  end
  
  puts "========================================="
  puts "REST Spell Checker  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "========================================="
  
  if i = ARGV.index("--edit") then
    $error_file = "#{ENV["HOME"]}/.rest_spell_checker.err.txt"
  end
  
  x = RESTSpellChecker.new
  ARGV.each do |arg|
    next if arg[0,1] == "-"
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{rst}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $found = false
      $fn = fn
      File.open($fn, "r") {|input|  x.parse(input)  }
    end
  end
  
  if $error_out then
    $error_out.close
    exec "vim -q #{$error_file}" 
  end
  
end
