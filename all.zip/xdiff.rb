#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'diff_base.rb'
  
  
if __FILE__ == $0 then
  
  #~ flavor = "ZONBOOK"
  do_structure = false
  
  file1 = nil
  file2 = nil
  ARGV.each do |arg|
    if arg[0,1] == "-" then
      #~ flavor = case arg.downcase
        #~ when "-zonbook" then "ZONBOOK"
        #~ when "-html" then "HTML"
        #~ else
          #~ flavor
        #~ end
      do_structure = true if arg[0,2].downcase == "-s"
    else
      if file1 then
        file2 = arg unless file2
      else
        file1 = arg
      end
    end
  end
  
  if !file1 || !file2 then
    $stderr.puts "xdiff.rb <file1> <file2> [-s]"  #[-zonbook|-html]"
    exit
  else
    line1 = "XDIFF  #{file1} vs. #{file2}  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    $stderr.puts line1
    $stderr.puts "=" * line1.length
    $stderr.puts
  end
  
  x = y = nil
  #~ File.open(file1, "r:UTF-8") {|input| x = XML.parse_p(input, (flavor == "HTML")) }
  #~ File.open(file2, "r:UTF-8") {|input| y = XML.parse_p(input, (flavor == "HTML")) }
  x = XML.parse_link(file1)
  y = XML.parse_link(file2)
  
  xlines = x.to_lines.split("\n")
  ylines = y.to_lines.split("\n")
  puts diff(xlines, ylines)
  
  if do_structure then
    xlines = x.to_tags.split("\n")
    ylines = y.to_tags.split("\n")
    $stderr.puts "======== structure ========"
    puts diff(xlines, ylines)
  end
  
end
