#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'

if __FILE__ == $0 then
  
  get_args(min: 2, nmin: 1, syntax: "fnr.rb <file-or-directory-name>... -f <find-re> -r <replace-str> -ext <file-extensions> --ow ")
  files = []
  changed_files = []
  extensions = $args["-ext"] || "html,xml"

  if $nargs.empty? then
    files += Dir.glob("./**/*.{#{extensions}}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{#{extensions}}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{#{extensions}}")
       else
         files << narg
       end
     end  # $nargs.each
  end

  findRE = Regexp.new($args["-f"])
  replace = $args["-r"]
  count = 0

  files.each do |f|
    buffer = String.new
    changed = false
    $stderr.puts ">>> " + f
    File.open(f, "r") do |input|
      while line = input.gets do
        if line.gsub!(findRE, replace) then
          changed = true
          $stderr.print "*"
          count += 1
        else
          $stderr.print "."
        end
        buffer << line
      end
    end
    $stderr.puts
    if changed then
      changed_files << f
      File.open(f + ".new", "w") do |output|
        output.print buffer
      end
    end
  end

  if $args["--ow"] then
    changed_files.each do |f|
      File.delete(f)
      File.rename(f + ".new", f)
    end
  end

  $stderr.puts "#{count.to_s} instances replaced"
end

