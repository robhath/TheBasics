#!ruby

if $0 == __FILE__ then
  $LOAD_PATH.unshift File.join(File.dirname($0), './lib')
end

require 'XML'


if __FILE__ == $0 then
  x = nil
  do_docbook = false
  if ARGV.length < 1 || ARGV.find_index {|arg| arg =~ /^-h/i } then
    $stderr.puts "syntax:  lazy.rb  <input-filename>... [-db] "
    exit
  end
  if i = ARGV.index("-db") then
    do_docbook = true
  end
  
  ARGV.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
  
    ofn = File.dirname(arg) + "/" + File.basename(arg, ".*")
    if do_docbook then
      File.open(arg, "r") do |input|  
        x = XML.parse_lazy_text(input, 
            delimiters: XML::DELIMITERS, 
            tags: XML::DOCBOOK_TAGS, 
            table_tags: XML::DOCBOOK_TABLE_TAGS, 
            para_tags: XML::DOCBOOK_PARA_TAGS) 
      end
      File.open(ofn + ".xml", "w") do |output| 
        output.puts XML::DOCBOOK_pre
        output.puts x.to_s(0, true, XML::DOCBOOK_LITERAL_TAGS)
        output.puts XML::DOCBOOK_post
      end
    else
      File.open(arg, "r") do |input|  
        x = XML.parse_lazy_text(input, 
            delimiters: XML::DELIMITERS, 
            tags: XML::HTML_TAGS, 
            table_tags: XML::HTML_TABLE_TAGS, 
            para_tags: XML::HTML_PARA_TAGS) 
      end
      found_html = x.any? {|y| y.tag == "html" }
      File.open(ofn + ".html", "w") do |output| 
        output.puts XML::HTML_pre unless found_html
        output.puts x.to_s(0, true, XML::HTML_LITERAL_TAGS)
        output.puts XML::HTML_post
      end
    end
  end
end
