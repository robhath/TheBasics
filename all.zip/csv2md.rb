#!ruby

require 'csv'

no_header = (ARGV[0] == "--nh")

a = CSV.read("foo.csv")

max_entry_len = []
a.each_index do |i|
  a[i].each_index do |j|
    max_entry_len[j] = 0 unless max_entry_len[j]
    max_entry_len[j] = a[i][j].length if max_entry_len[j] <= a[i][j].length 
  end
end

a.each_index do |i|
  if i == 1 then
    unless no_header then
      # separator between header and body rows...
      a[i].each_index do |j|
        print "| "
        print "#{"-" * max_entry_len[j]} "
      end
      puts "|"
    end
  end
  a[i].each_index do |j|
    print "| "
    print a[i][j] 
    print (" " * (max_entry_len[j] - a[i][j].length + 1))
  end
  puts "|"
end


