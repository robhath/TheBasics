#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'XML.rb'

def type_to_s(type, item_type, name, what = "type")
  return case type
    when "String" then "&#{what}-string;" 
    when "Integer" then "&#{what}-integer;"
    when "Boolean" then "&#{what}-boolean;"
    when "Array" then
      case item_type
        when "String" then "&#{what}-stringlist;" 
        when "Integer" then "&#{what}-integerlist;"
        when "Boolean" then "&#{what}-booleanlist;"
        when "Array" then "???"  # TBD
        when "Object" then "???"  # TBD
        when "Map" then "???"  # TBD
        when "Lambda" then "???"  # TBD
        when "Exponential" then "???"  # TBD
        when "Number" then "???"  # TBD
        else 
          "???"
        end
      
    when "Object" then name
    when "Map" then "Map"
    when "Lambda" then "Lambda"
    when "Exponential" then "Exponential"
    when "Number" then "Number"
    else 
      "???"
    end
end  # type_to_s


JX = XML.parse_text('  &quot;<xref linkend="cfn-???-identitypool-cognitoidentityprovider"/>&quot; : <replaceable>CognitoIdentityProvider</replaceable>,
'
)

  YX = XML.parse_text('  <xref linkend="cfn-#{service_name.downcase}-#{resource_name.downcase}-#{name.downcase}"/>#{ (is_array ? ": \n    - " : ": ")}<replaceable>#{type_to_s(stuff_type, stuff_item_type, name, "param")}</replaceable>
')

  VL = XML.parse_text('    <variablelist>
      <varlistentry id="cfn-identitypool-cognitoidentityprovider">
        <term>
          <literal>CognitoIdentityProvider</literal></term>
        <listitem>
          <para> </para>
          <para>
            <emphasis>Type</emphasis>: <xref linkend="aws-properties-identitypool-cognitoidentityprovider" endterm="aws-properties-identitypool-cognitoidentityprovider.title"/></para>
        </listitem>
      </varlistentry>
    </variablelist>')


def stuff2zonbook(resource_name, props, service_name)
  $stderr.puts "stuff2zonbook(#{resource_name}, ..., #{service_name}"
  results = XML.new
  properties = XML.new("variablelist")
  
  jxrefs = []
  yxrefs = []


  
  props.each do |key, stuff|
    name = key.to_s
    entry = XML.new("varlistentry", {"id" => ("cfn-" + service_name.downcase + "-" + resource_name.downcase + "-" + name.downcase)})
    properties.child << entry
    entry.child << XML.new("term", {}, "", [XML.new("code", {}, "", [XML.new("", {}, name)])])
    
    entry.child << XML.new("listitem")
    entry.child.last.child << XML.new("para", {}, "", [XML.new("", {}, " ")])  # description goes here
    
    # Required...
    if stuff.has_key?("Required") then
      stuff_required = stuff["Required"].to_s 
      #~ $stderr.puts "stuff_required= #{stuff_required}"
      temp = case stuff_required
        when "true" then "&required-yes;" 
        when "false" then "&required-no;"
        else 
          "???"
        end
      entry.child.last.child << XML.new("para", {}, "", [XML.new("", {}, temp)])
    end
      
    # Type and ItemType...
    if stuff.has_key?("Type") then
      stuff_type = stuff["Type"].to_s
      stuff_item_type = stuff.has_key?("ItemType") ? stuff["ItemType"]["Type"] : nil
      #~ $stderr.puts "stuff_type= #{stuff_type}"
      #~ $stderr.puts "stuff_item_type= #{stuff_item_type}"
      is_array = (stuff_type == "Array")
      is_object = (stuff_type == "Object")
      
      if is_object then
        p = XML.new("para")
        p.child << XML.new("emphasis", {}, "", [XML.new("", {}, "Type")])
        p.child << XML.new("", {}, ": ")
        p.child << XML.new("xref", 
            {"linkend" => ("aws-properties-" + resource_name.downcase + "-" + name.downcase), 
              "endterm" => ("aws-properties-" + resource_name.downcase + "-" + name.downcase + ".title")})
        entry.child.last.child << p
      else
        entry.child.last.child << XML.new("para", {}, "", [XML.new("", {}, type_to_s(stuff_type, stuff_item_type, name))])
      end
  
      #~ jxrefs << XML.new("", {}, "  \"")
      #~ jxrefs << XML.new("xref", {"linkend" => "cfn-" + service_name.downcase + "-" + resource_name.downcase + "-" + name.downcase})
      #~ jxrefs << XML.new("", {}, (is_array ? "\" : [ " : "\" : "))
      #~ jxrefs << XML.new("replaceable", {}, "", 
          #~ [XML.new("", {}, type_to_s(stuff_type, stuff_item_type, name, "param"))])
      #~ jxrefs << XML.new("", {}, (is_array ? ", ... ],\n" : ",\n"))
      
      jxrefs += JX.copy.evaluate!(binding)
      
      #~ yxrefs << XML.new("", {}, "  ")
      #~ yxrefs << XML.new("xref", {"linkend" => "cfn-" + service_name.downcase + "-" + resource_name.downcase + "-" + name.downcase})
      #~ yxrefs << XML.new("", {}, (is_array ? ": \n    - " : ": "))
      #~ yxrefs << XML.new("replaceable", {}, "", 
          #~ [XML.new("", {}, type_to_s(stuff_type, stuff_item_type, name, "param"))])
      #~ yxrefs << XML.new("", {}, "\n")
    
      yxrefs += YX.copy.evaluate!(binding)
      
    end
    
    # UpdateType...
    if stuff.has_key?("UpdateType") then
      stuff_update_type = stuff["UpdateType"]
      #~ $stderr.puts "stuff_update_type= #{stuff_update_type}"
      temp = case stuff_update_type.to_s 
        when "Immutable" then "&update-replacement;" 
        when "Mutable" then "&update-no-interrupt;"
        when "Conditional" then "&update-some-interrupt;"
        else
          "???"
        end
      entry.child.last.child << XML.new("para", {}, "", [XML.new("", {}, temp)])
    end
        
    # MinLength...
    if stuff.has_key?("MinLength") then
      stuff_min_length = stuff["MinLength"].to_s
      #~ $stderr.puts "stuff_min_length= #{stuff_min_length}"
      entry.child.last.child << XML.new("para", {}, "", [XML.new("", {}, "MinLength: " + stuff_min_length)])
    end
        
    # MaxLength...
    if stuff.has_key?("MaxLength") then
      stuff_max_length = stuff["MaxLength"].to_s
      #~ $stderr.puts "stuff_max_length= #{stuff_max_length}"
      entry.child.last.child << XML.new("para", {}, "", [XML.new("", {}, "MaxLength: " + stuff_max_length)])
    end
    
    if stuff.has_key?("Properties") then
      results.child += stuff2zonbook(name, stuff["Properties"], service_name).child
    end

  end  # props.each
  
  z = XML.new("section", 
      {"id" => ("aws-properties-" + resource_name.downcase), "role" => "topic", "revision" => "release"})
  si = XML.new("sectioninfo")
  si.child << XML.new("abstract", {}, "", [XML.new("para", {}, "", [XML.new("", {}, "Describes...???")])])
  z.child << si
  
  z.child << XML.new("title", {"id" => ("aws-properties-" + resource_name.downcase + ".title")}, "", 
      [XML.new("", {}, resource_name)])
  z.child << XML.new("para", {}, "", [XML.new("", {}, "???")])
  
  # Syntax section...
  ss = XML.new("section")
  ss.child << XML.new("title", {}, "", [XML.new("", {}, "Syntax")])
  
  jxrefs.last.pcdata = ""
  json = XML.new("section", 
      {"role" => "languagefilter", "id" => ("aws-properties-" + resource_name.downcase + "-syntax.json")}, "",
      [XML.new("title", {}, "", [XML.new("", {}, "JSON")])])
  plj = XML.new("programlisting")
  json.child << plj
  plj.child << XML.new("", {}, "{\n")
  plj.child += jxrefs
  plj.child << XML.new("", {}, "\n}")
  ss.child << json
    
  yxrefs.last.pcdata = ""
  yml = XML.new("section", 
      {"role" => "languagefilter", "id" => ("aws-properties-" + resource_name.downcase + "-syntax.yaml")}, "",
      [XML.new("title", {}, "", [XML.new("", {}, "YAML")])])
  ply = XML.new("programlisting")
  yml.child << ply
  ply.child << XML.new("", {}, "{\n")
  ply.child += yxrefs
  ply.child << XML.new("", {}, "\n}")
  ss.child << yml
    
  z.child << ss
  
  
  p = XML.new("section")
  p.child << XML.new("title", {}, "", [XML.new("", {}, "Properties")])
  p.child << properties
  
  z.child << p
  results.child.unshift z
  
  return results
end  # stuff2zonbook


def handler2zonbook(handler)
  results = []
  
  handler_type = handler["Type"]
  #~ $stderr.puts "handler_type= #{handler_type}"
  
  handler_execute = handler["Execute"]
  
  execute_fn = handler_execute["Function"]
  #~ $stderr.puts "execute_fn= #{execute_fn}"
  
  execute_retry = handler_execute["Retry"]
  retry_type = execute_retry["Type"]
  #~ $stderr.puts "retry_type= #{retry_type}"
  retry_timeout = execute_retry["Timeout"]
  #~ $stderr.puts "retry_timeout= #{retry_timeout}"
  retry_initial_retry_interval = execute_retry["InitialRetryInterval"]
  #~ $stderr.puts "retry_initial_retry_interval= #{retry_initial_retry_interval}"
  retry_max_retry_interval = execute_retry["MaxRetryInterval"]
  #~ $stderr.puts "retry_max_retry_interval= #{retry_max_retry_interval}"
  
  execute_timeout = handler_execute["Timeout"]
  #~ $stderr.puts "execute_timeout= #{execute_timeout}"
  
  return results
end  # handler2zonbook


if __FILE__ == $0 then
  
  service_name = "???"
  is_json = false
  
  if ARGV.length < 1 then
    $stderr.puts "y2z.rb <path, file or directory> ...  [-svc <service-name>]"
    exit
  else
    line1 = "Y2Z  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    puts line1
    puts "=" * line1.length
    puts
  end
  
  if i = ARGV.index("-svc") then
    service_name = ARGV[i+1]
    ARGV[i+1] = nil
  end

  ARGV.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{json,txt,yaml,yml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $stderr.puts fn
  
      y = YAML.load_file(fn)
      if y.nil? || !y || y.empty? then
        $stderr.puts "    something's wrong... skipping file!"
        next
      end
      outputfn = fn.sub(/\.[^.]+$/, ".xml")
      output = File.open(outputfn, "w:UTF-8")
      $stderr.puts "  --> #{outputfn}"

      description = y["Description"]
      #~ $stderr.puts "description: #{description}"
      parameters = y["Parameters"]
      #~ $stderr.puts "parameters: #{parameters}"
      
      resources = y["Resources"]
      #~ $stderr.puts "resources: #{resources}"
      
      #~ stuff = stuff2zonbook("???", resources, service_name)
      #~ stuff.child.each {|p| output.puts p.to_s(0, true, ["programlisting"]) }
        
      resources.each do |key, value|
        resource_name = key.to_s.sub(/ResourceTypeVersion$/i, "")
        #~ $stderr.puts "resource_name: #{resource_name}"
        resource = value
        
        resource_type = resource["Type"]
        #~ $stderr.puts "resource_type: #{resource_type}"
        
        resource_properties = resource["Properties"]
        
        # Resource Properties...
        resource_type_id = resource_properties["ResourceTypeId"]
        #~ $stderr.puts "ResourceTypeId: #{resource_type_id}"
        resource_type_version_name = resource_properties["ResourceTypeVersionName"]
        #~ $stderr.puts "ResourceTypeVersionName: #{resource_type_version_name}"
        resource_configuration = resource_properties["ResourceConfiguration"]
        #~ $stderr.puts "ResourceConfiguration: #{resource_configuration}"
        
        if resource_configuration then
          $stderr.puts "      converting section: #{resource_name}"
        else
          $stderr.puts "      unsupported section: #{resource_name}"
          next
        end
        # ResourceConfiguration...
        schema = resource_configuration["Schema"]
        
        # Schema...
        schema_identifier_paths = schema["IdentifierPaths"]
        #~ $stderr.puts "schema_identifier_paths= #{schema_identifier_paths}"
        
        # Schema Definitions...
        if schema.has_key?("Definitions") then
          schema_definitions = schema["Definitions"]
          defs = stuff2zonbook(resource_name, schema_definitions, service_name) 
          defs.child.each {|d| output.puts d.to_s(0, true, ["programlisting", "xref"]) }
        end
        
        # Schema Properties...
        if schema.has_key?("Properties") then
          schema_properties = schema["Properties"]
          props = stuff2zonbook(resource_name, schema_properties, service_name) 
          props.child.each {|p| output.puts p.to_s(0, true, ["programlisting"]) }
        end
        
        # Schema Attributes...
        if schema.has_key?("Attributes") then
          schema_attributes = schema["Attributes"]
          attrs = stuff2zonbook(resource_name, schema_attributes, service_name)  
          attrs.child.each {|a| output.puts a.to_s(0, true, ["programlisting"]) }
        end
        
        # CreateHandler...
        if resource_configuration.has_key?("CreateHandler") then
          create_handler = resource_configuration["CreateHandler"]
          #~ handler2zonbook(create_handler)
          # TBD
        end
        
        # UpdateHandler...
        if resource_configuration.has_key?("UpdateHandler") then
          update_handler = resource_configuration["UpdateHandler"]
          #~ handler2zonbook(update_handler)
          # TBD
        end
        
        # DeleteHandler...
        if resource_configuration.has_key?("DeleteHandler") then
          delete_handler = resource_configuration["DeleteHandler"]
          #~ handler2zonbook(delete_handler)
          # TBD
        end
        
        # ReadHandler...
        if resource_configuration.has_key?("ReadHandler") then
          read_handler = resource_configuration["ReadHandler"]
          #~ handler2zonbook(read_handler)
          # TBD
        end
        
        #~ w = XML.new("section", {"id" => "???"})
        #~ si = XML.new("sectioninfo")
        #~ si.child << XML.new("abstract", {}, "" [XML.new("para", {}, "", [XML.new("", {}, "Describes...")])])
        #~ w.child << si
        
        #~ w.child << XML.new("title", {"id" => "???"}, "", [XML.new("", {}, "???")])
        #~ w.child << XML.new("para", {"id" => "???"}, "", [XML.new("", {}, "???")])
        
        #~ # Syntax section...
        #~ ss = XML.new("section")
        #~ ss.child << XML.new("title", {}, "", [XML.new("", {}, "Syntax")])
        #~ json = XML.new("section", {"role" => "languagefilter", "id" => "???"}, "",
            #~ [XML.new("", {}, "JSON")])
        #~ pl = XML.new("programlisting")
        #~ json.child << pl
        #~ pl.child << 
      end if resources
      
      output.close
    end  # a.each
  end

end

