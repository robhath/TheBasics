#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'Stringx'

  
if __FILE__ == $0 then
  
  output_dir = ""
  recursive_depth = 1
  stay_in_domain = false
  current_domain = nil
  links_visited = 0
  add_whitespace = false
  
  if i = ARGV.index("-o") then
    output_dir = ARGV[i+1].gsub("\\", "/")
    output_dir << "/" unless output_dir[-1] == "/"
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-depth") then
    rd = ARGV[i+1].to_i(0)
    recursive_depth = rd if rd > -1 && rd < 2048
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-stay") then
    stay_in_domain = true
  end

  if i = ARGV.index("-ws") then
    add_whtespace = true
  end

  if ARGV.length < 1 then
    $stderr.puts "xml2txt.rb <path, file or directory> ...   [-ws] [-o <output-directory>] [-depth <integer>] [-stay]"
    exit
  else
    line1 = "XML to TXT  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    puts line1
    puts "=" * line1.length
  end
  
  x = nil
  indexfn = ""
  ARGV.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
    current_depth = 0
  
    links = []
    if arg =~ /^\s*http/ then
      links << arg
    elsif File.directory?(arg) then
      links += Dir.glob("#{arg}/**/*.{html,xml}")
    else
      links << arg
    end
    
    output_is_relative = (output_dir[0..1] == "..")
    recursion_cutoff = links.length
    i = 0
    current_domain = links[i].get_link_parts()["domain"] unless current_domain
    while i < links.length do
      $stderr.puts "#{links[i]} not in same domain, skipping..." if stay_in_domain && links[i].get_link_parts()["domain"] != current_domain
      if stay_in_domain && links[i].get_link_parts()["domain"] != current_domain then
        i += 1
        next 
      end
      $stderr.puts links[i]
      x = XML.parse_link(links[i])
      buffer = x.to_txt(add_whitespace, ["head"]).xml2txt
      links_visited += 1
      
      cur_path = File.dirname(links[i])
      if cur_path == "." then
        cur_path = ""
      else
        cur_path << "/"
      end
      
      if current_depth < recursive_depth then
        more_links = x.get_links
        more_links.each do |link|
          if link =~ /\.html\?/ then
            # ignore it
          elsif link =~ /^\s*http/ then
            links << link unless links.index {|obj| obj.downcase == link.downcase }
            #~ $stderr.puts "!!!circular:#{link}" if links.index {|obj| obj.downcase == link.downcase }
          else
            links << (cur_path + link) unless links.index {|obj| obj.downcase == (cur_path + link).downcase }
            #~ $stderr.puts "!!!circular:#{link}" if links.index {|obj| obj.downcase == (cur_path + link).downcase }
          end
        end
        if i >= recursion_cutoff then
          current_depth += 1 
          recursion_cutoff = links.length
        end
      end
      
      fbn = File.basename(links[i], ".*")
      od = String.new(output_dir)
      od.prepend(File.dirname(links[i]) + "/") if links[i] !~ /^\s*http/
      File.open(od + fbn + ".txt", "w") {|output| output.puts buffer }
      $stderr.puts "  -->#{od}#{fbn}.txt"
      
      i += 1
    end
  end
  
  puts "links visited = #{links_visited.to_s}"
end
