#!ruby

if $0 == __FILE__ then
  $LOAD_PATH.unshift File.join(File.dirname($0), './lib')
end

require 'XML.rb'

  def count_words(x, word_counts = {})
    x.each do |y|
      if y.tag.empty? then
        str = y.pcdata.force_encoding("utf-8")
        #~ while pos = (str =~ /(?<=\b)([A-Za-z][-.0-9_A-Za-z]+)('d|'s|'ll|'t|'ve|'re)*(?=\b)/) do
        while pos = (str =~ /(?<=\b)([\p{alpha}][-.\p{word}]+)('d|'s|'ll|'t|'ve|'re)*(?=\b)/) do
          pre = $`
          w = $&
          str = $'
          if pre[-1,1] == "&" && str =~ /^\S*;/ then
            word_counts["&" + w + ";"] = 0 unless word_counts.has_key?("&" + w + ";")
            word_counts["&" + w + ";"] += 1
          else
            w.downcase! if w =~ /^[A-Z][a-z]+$/
            word_counts[w] = 0 unless word_counts.has_key?(w)
            word_counts[w] += 1
          end
        end
      end
    end
  end  # count_words
  

  

if __FILE__ == $0 then
  
  buffer = ""
  links = []
  
  ARGV.each do |arg|
    links << arg
  end
  
  i = 0
  while i < links.length do
    x = XML.parse_link(links[i])
    buffer << x.get_pcdata("", true)
    
    # add more links...
    i += 1
  end
  
  puts buffer.gsub(/\n{2,}/, "\n")
  
end
