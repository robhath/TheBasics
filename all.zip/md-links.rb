#!ruby

  if RUBY_VERSION =~ /^1.8/ then
    class String
      def force_encoding(enc)
        self
      end
      def clear()
        ""
      end
    end
  end
  

if __FILE__ == $0 then

  dir = "."  # by default the current directory
  error_file = nil
  error_out = nil
  edit_files = false
  use_filename_for_links = true

  output_file = "#{ENV["HOME"]}/.srch.links.txt"
  output_out = nil
  count = 0
  broken_count = 0
  pre_context_count = 0
  post_context_count = 0

  da_links = []
  
  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^--help$/i then
        $stderr.puts "syntax:\n  md-links.rb  -d <directory>  --edit  -o <file-name> ..."
        $stderr.puts "    -d <directory>         : directory to search (recursive)"
        $stderr.puts "    -c <line-count>        : include line-count lines as context"
        $stderr.puts "    -A <line-count>        : include line-count lines as pre-context"
        $stderr.puts "    -B <line-count>        : include line-count lines as post-context"
        $stderr.puts "    -o <file-name>         : generate link targets file"
        $stderr.puts "    --nofn                 : don't add filename to links in link targets file"
        $stderr.puts "    --edit                 : edit broken links using vim"
        $stderr.puts "\n\nsimplified syntax:\n  md-links.rb"
        $stderr.puts "    defaults to: md-links.rb  -d . -o ~/.srch.links.txt"
        exit
      when /^-d/i then
        i += 1
        dir = ARGV[i] if ARGV.length > i
      when /^-o$/i then
        i += 1
        output_file = ARGV[i] if ARGV.length > i
      when /^-c/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          pre_context_count = cc
          post_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: context count (-c) must be 1-9"
        end 
      when /^-A/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          pre_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: pre-context count (-A) must be 1-9"
        end 
      when /^-B/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          post_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: post-context count (-B) must be 1-9"
        end 
      when /^--nofn$/i then
        use_filename_for_links = false
      when /^--edit$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
      end
      i += 1
  end

  title = "Markdown links (local) dir=#{dir}  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts title
  puts "=" * title.length
  
  
  files = []
  found_files = []

  extensions = "md,MD"
  files += Dir.glob("#{dir}/**/*.{#{extensions}}")
  tabs = 2  # tabs count as two spaces

  # look for titles; collect the whole set...
  #
  title_targetRE = Regexp.new(/(^\s{0,3}(\#{1,4})\s+([^\[].+))|(<a\s+([^>]+)>)/)
  figlinkRE = Regexp.new(/name=["']([^"']+)/)
  figtitleRE= Regexp.new(/title=["']([^"']+)/)
  count = 0

  section_buffer = ""
  figure_buffer = ""
  listing_buffer = ""
  table_buffer = ""
  example_buffer = ""

  files.each do |fn|

    File.open(fn, "r") do |input|
      optfn = use_filename_for_links ? fn.delete_prefix("./") : ""

      da_links << fn.delete_prefix("./")
      while line = input.gets do
        begin
          if line =~ title_targetRE then
            title = $3 ? String.new($3) : nil
            level = $2 ? $2.length : 0
            target = $5 ? String.new($5) : nil

            if !title.nil? then
              link = title.rstrip              # make a new string without ending whitespace
              link.delete!("^-_A-Za-z0-9 \t")  # delete all except alpha-numeric, -, _, space, tab
              link.gsub!("\t", "-" * tabs)     # convert tabs to 'tabs' spaces
              link.tr!(" ", "-")               # convert spaces to dashes
              link.downcase!                   # all alpha to lower-case
              da_links << "#{fn.delete_prefix("./")}\##{link}" 

              if level == 1 then
                if use_filename_for_links then
                  section_buffer << "\n\#\# [#{title}](#{optfn}\##{link})\n"
                else
                  section_buffer << "\n\+ [**#{title}**](\##{link})\n"
                end
              else
                section_buffer << "#{"  " * (level - 1)}+ [#{title}](#{optfn}\##{link})\n"
              end
              
              foundit = true
              count += 1

            elsif !target.nil? then
              link = (target =~ figlinkRE) ? String.new($1) : "???"
              title = (target =~ figtitleRE) ? String.new($1) : "???"
              da_links << "#{fn.delete_prefix("./")}\##{link}" 

              if title =~ /^\s*figure\s*\d/i || link[0..2] == "fig" then
                figure_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              elsif title =~ /^\s*listing\s*\d/i || link[0..2] == "lis" then
                listing_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              elsif title =~ /^\s*table\s*\d/i || link[0..2] == "tab" then
                table_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              elsif title =~ /^\s*example\s*\d/i || link[0..2] == "exa" then
                example_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              else
                $stderr.puts "possible ill-formed target: #{fn}:#{$.}"
              end 
              foundit = true
              count += 1

            else
              $stderr.puts "possible ill-formed target: #{fn}:#{$.}"
            end
          end
        rescue
          if line.force_encoding("ISO-8859-1") =~ title_targetRE then
            title = $3 ? String.new($3) : nil
            level = $2 ? $2.length : 0
            target = $5 ? String.new($5) : nil

            if !title.nil? then
              link = title.rstrip              # make a new string without ending whitespace
              link.delete!("^-_A-Za-z0-9 \t")  # delete all except alpha-numeric, -, _, space, tab
              link.gsub!("\t", "-" * tabs)     # convert tabs to 'tabs' spaces
              link.tr!(" ", "-")               # convert spaces to dashes
              link.downcase!                   # all alpha to lower-case
              da_links << "#{fn.delete_prefix("./")}\##{link}" 

              if level == 1 then
                if use_filename_for_links then
                  section_buffer << "\n\#\# [#{title}](#{optfn}\##{link})\n"
                else
                  section_buffer << "\n\+ [**#{title}**](\##{link})\n"
                end
                section_buffer << "\n#{optfn.blank? ? "+" : "\#\#"} [**#{title}**](#{optfn}\##{link})\n"
              else
                section_buffer << "#{"  " * (level - 1)}+ [#{title}](#{optfn}\##{link})\n"
              end
              
              foundit = true
              count += 1

            elsif !target.nil? then
              link = (target =~ figlinkRE) ? String.new($1) : "???"
              title = (target =~ figtitleRE) ? String.new($1) : "???"
              da_links << "#{fn.delete_prefix("./")}\##{link}" 

              if title =~ /^\s*figure\s*\d/i || link[0..2] == "fig"  then
                figure_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              elsif title =~ /^\s*listing\s*\d/i || link[0..2] == "lis"  then
                listing_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              elsif title =~ /^\s*table\s*\d/i || link[0..2] == "tab"  then
                table_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              elsif title =~ /^\s*example\s*\d/i || link[0..2] == "exa"  then
                example_buffer << "+ [#{title}](#{optfn}\##{link})\n"
              else
                $stderr.puts "possible ill-formed target: #{fn}:#{$.}"
              end 
              foundit = true
              count += 1

            else
              $stderr.puts "possible ill-formed target: #{fn}:#{$.}"
            end
          end
        end
      end
    end
  end

  if output_file then
    output_out = File.open(output_file, "w") unless output_out
    output_out.puts "\# Table of Contents\n"
    unless section_buffer.empty? then
      output_out.puts section_buffer
    end
    unless example_buffer.empty? then
      if use_filename_for_links then
        output_out.puts "\n## Examples:\n"
      else
        output_out.puts "\n**Examples:**\n"
      end
      output_out.puts example_buffer
    end
    unless figure_buffer.empty? then
      if use_filename_for_links then
        output_out.puts "\n## Figures:\n"
      else
        output_out.puts "\n**Figures:**\n"
      end
      output_out.puts figure_buffer
    end
    unless listing_buffer.empty? then
      if use_filename_for_links then
        output_out.puts "\n## Listings:\n"
      else
        output_out.puts "\n**Listings:**\n"
      end
      output_out.puts listing_buffer
    end
    unless table_buffer.empty? then
      if use_filename_for_links then
        output_out.puts "\n## Tables:\n"
      else
        output_out.puts "\n**Tables:**\n"
      end
      output_out.puts table_buffer
    end
    output_out.puts 
    output_out.close 
  end
  puts "#{count.to_s} titles found"


  # Look for links...
  #
  linkRE = Regexp.new(/\[([^\[\]]+)\]\(([^\(\)]*)\)/)
  count = 0

  files.each do |fn|
    
    found_in_file = false
    File.open(fn, "r") do |input| # :ISO-8859-1:UTF-8
      if pre_context_count > 0 || post_context_count > 0 then
        # with context...
        context = [] 
        remaining_context = 0
        while line = input.gets do
          offset = 0
          first_instance = true
          found_in_line = false
          begin
            while pos = (line =~ linkRE) do
              remainder = $'
              link_text = String.new($1)
              link_url = String.new($2)

              if link_url !~ /^([^:]+:((\/\/)|(\d{4})))|([^@]+@)/ then
                count += 1
                link_url.prepend(fn.delete_prefix("./")) if link_url[0] == "\#"
                if da_links.include?(link_url) || File.exist?(link_url) then
                  # well that's just dandy!
                else
                  puts "\n>>>File: #{fn}" unless found_in_file
                  if first_instance then
                    context.each do |ll|
                      puts "#{' ' * ($.).to_s.length} #{ll}"
                    end
                    context.clear
                    puts "#{$.} #{line.chomp}" 
                  end
                  if post_context_count > 0 then
                    remaining_context = post_context_count
                  else
                    puts "---"
                  end
                  first_instance = false
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.}:#{offset+pos+1}:broken link"
                  end
                  found_in_file = true
                  found_in_line = true
                  broken_count += 1
                end
              end
              offset = line.length - remainder.length
              line = remainder
            end
          rescue
            # try it this way to avoid encoding error...
            while pos = (line.force_encoding("ISO-8859-1") =~ linkRE) do
              remainder = $'
              link_text = String.new($1)
              link_url = String.new($2)

              if link_url !~ /^([^:]+:((\/\/)|(\d{4})))|([^@]+@)/ then
                count += 1
                link_url.prepend(fn.delete_prefix("./")) if link_url[0] == "\#"
                if da_links.include?(link_url) || File.exist?(link_url) then
                  # well that's just dandy!
                else
                  puts "\n>>>File: #{fn}" unless found_in_file
                  if first_instance then
                    context.each do |ll|
                      puts "#{' ' * ($.).to_s.length} #{ll}"
                    end
                    context.clear
                    puts "#{$.} #{line.chomp}"
                  end
                  if post_context_count > 0 then
                    remaining_context = post_context_count
                  else
                    puts "---"
                  end
                  first_instance = false
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.}:#{offset+pos+1}:broken link"
                  end
                  found_in_file = true
                  found_in_line = true
                  broken_count += 1
                end
              end
              offset = line.length - remainder.length
              line = remainder
            end
          end  # rescue

          unless found_in_line then
            if remaining_context > 0 then
              puts "#{' ' * ($.).to_s.length} #{line.chomp}"
              remaining_context -= 1
              puts "---" if remaining_context < 1
            else
              context << line.chomp
              context.shift if context.length > pre_context_count
            end
          end
        end
      else
        while line = input.gets do
          offset = 0
          begin
            while pos = (line =~ linkRE) do
              remainder = $'
              link_text = String.new($1)
              link_url = String.new($2)

              if link_url =~ /^([^:]+:((\/\/)|(\d{4})))|([^@]+@)/ then
                # full url, not interested
              else
                count += 1
                link_url.prepend(fn.delete_prefix("./")) if link_url[0] == "\#"
                if da_links.include?(link_url) || File.exist?(link_url) then
                  # well that's just dandy!
                else
                  puts "\n>>>File: #{fn}" unless found_in_file
                  puts "#{$.} #{line.chomp}" 
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.}:#{offset+pos+1}:broken link"
                  end
                  found_in_file = true
                  broken_count += 1
                end
              end
              offset = line.length - remainder.length
              line = remainder
            end
          rescue
            # try it this way to avoid encoding error...
            while pos = (line.force_encoding("ISO-8859-1") =~ linkRE) do
              remainder = $'
              link_text = String.new($1)
              link_url = String.new($2)

              if link_url !~ /^([^:]+:((\/\/)|(\d{4})))|([^@]+@)/ then
                # full url, not interested
              else
                count += 1
                link_url.prepend(fn.delete_prefix("./")) if link_url[0] == "\#"
                if da_links.include?(link_url) || File.exist?(link_url) then
                  # well that's just dandy!
                else
                  puts "\n>>>File: #{fn}" unless found_in_file
                  puts "#{$.} #{line.chomp}"
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.}:#{offset+pos+1}:broken link"
                  end
                  found_in_file = true
                  broken_count += 1
                end
              end
              offset = line.length - remainder.length
              line = remainder
            end
          end  # rescue
        end
      end  # if pre_context_count > 0 || post_context_count > 0
    end
  end

  puts "...search completed. #{count} local link#{count != 1 ? "s" : ""} found in all files; #{broken_count} link#{ broken_count != 1 ? "s" : ""} broken."
  error_out.close if error_out
  if edit_files && count > 0 then
    exec "vim -q #{error_file}" 
  end
  
end

