#!ruby

  if RUBY_VERSION =~ /^1.8/ then
    class String
      def force_encoding(enc)
        self
      end
      def clear()
        ""
      end
    end
  end
  
  if ARGV.length < 1 then
    $stderr.puts "syntax:\n  srchm.rb -p <pattern> -d <directory> --i --m --x --edit -e <file-name> -ext <file-extension>..."
    $stderr.puts "    -p <pattern>          : regular expression to match"
    $stderr.puts "    -d <directory>        : directory to search (recursive)"
    $stderr.puts "    -c <line-count>       : include line-count lines as context"
    $stderr.puts "    -A <line-count>       : include line-count lines as pre-context"
    $stderr.puts "    -B <line-count>       : include line-count lines as post-context"
    $stderr.puts "    --i                   : case-insensitive regular expression"
    $stderr.puts "    --m                   : multi-line regular expression"
    $stderr.puts "    --x                   : extended syntax regular expression"
    $stderr.puts "    --edit                : edit what is found using vim"
    $stderr.puts "    --fno                 : show file names and counts only"
    $stderr.puts "    -e <file-name>        : generate results file"
    $stderr.puts "    -ext <file-extension> : look in files with this extension, e.g. --xml"
    $stderr.puts "\n\nsimplified syntax:\n  srchm.rb <pattern>"
    $stderr.puts "    defaults to: srchm.rb <pattern> -d . -e html rst txt xml md"
    exit
  end
  re_str = ARGV[0]  # by default the first parameter
  re_options = 0
  dir = "."  # by default the current directory
  extensions = ["md", "html", "rst", "txt", "xml", "ent", "rb", "c", "h"]  # by default
  new_extensions = false
  do_fno = false
  error_file = nil
  error_out = nil
  edit_files = false
  count = 0
  pre_context_count = 0
  post_context_count = 0
  
  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^-ext/ then
        extensions.clear unless new_extensions
        new_extensions = true
        while i < (ARGV.length - 1) && ARGV[i+1][0] != "-" do
          i += 1
          extensions << ARGV[i] 
          extensions[-1] = "*" if extensions[-1] == "all"
        end
        # extensions << $'  # following match
        # extensions[-1] = "*" if extensions[-1] == "all"
      when /^-p/i then
        i += 1
        re_str = ARGV[i] if ARGV.length > i
      when /^-d/i then
        i += 1
        dir = ARGV[i] if ARGV.length > i
      when /^-e$/i then
        i += 1
        error_file = ARGV[i] if ARGV.length > i
      when /^-c/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          pre_context_count = cc
          post_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: context count (-c) must be 1-9"
        end 
      when /^-A/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          pre_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: pre-context count (-A) must be 1-9"
        end 
      when /^-B/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          post_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: post-context count (-B) must be 1-9"
        end 
      when /^--fno$/i then
        do_fno = true
      when /^--edit$/i then
        error_file = "#{ENV["HOME"]}/.srchm.err.txt"
        edit_files = true
      when /^--i$/i then
        re_options += Regexp::IGNORECASE
      when /^--m$/i then
        re_options += Regexp::MULTILINE
      when /^--x$/i then
        re_options += Regexp::EXTENDED
      when /^[^\-]/ then
        re_str = ARGV[i]
      end
      i += 1
  end
  
  re = Regexp.new(re_str.gsub(" ", "\\s+"), re_options)  # in case phrases occupy more than one line
  re_file = Regexp.new("#{re_str}[^/]*$", re_options)

  a = Dir.glob("#{dir}/**/#{(extensions.empty? || extensions.index("*")) ? "*" : "*.{#{extensions.join(",")}}"}")

  title = "Search Multiline re=#{re} dir=#{dir} ext=[#{extensions.join(" ")}]  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts title
  puts "=" * title.length

  a.each do |fn|
    is_directory = File.directory?(fn)
    if fn =~ re_file then
      puts "\n>>>Matched filename: #{fn}#{is_directory ? "  (directory)" : ""}"
    end
    next if is_directory

    found_in_file = false
    File.open(fn, "r") do |input| # :ISO-8859-1:UTF-8
      if pre_context_count > 0 || post_context_count > 0 then
        context = [] 
        remaining_context = 0

        prev_line = ""
        while line = input.gets do
          offset = 0
          first_instance = true
          found_in_line = false
          begin
            while pos = ((prev_line + line) =~ re) do
              remainder = $'
              puts "\n>>>File: #{fn}" unless found_in_file
              found_in_file = true
              found_in_line = true
              if first_instance && !do_fno then
                if pos >= prev_line.length then
                  context.each do |ll|
                    puts "#{' ' * ($.).to_s.length} #{ll}"
                  end
                  context.clear
                  puts "#{$.} #{line.chomp}"
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.}:#{offset+pos+1-prev_line.length}:#{re_str}"
                  end
                else
                  context[0..-2].each do |ll|
                    puts "#{' ' * ($.).to_s.length} #{ll}"
                  end
                  context.clear
                  puts "#{$.-1} #{prev_line.chomp}"
                  puts "#{$.} #{line.chomp}"
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.-1}:#{offset+pos+1}:#{re_str}"
                  end
                end
                if post_context_count > 0 then
                  remaining_context = post_context_count
                else
                  puts "---"
                end
                first_instance = false
                count += 1
                offset = line.length - remainder.length
                line = remainder
              end
            end
          rescue
            # try it this way to avoid encoding error...
            while pos = ((prev_line + line).force_encoding("ISO-8859-1") =~ re) do
              remainder = $'
              puts "\n>>>File: #{fn}" unless found_in_file
              found_in_file = true
              found_in_line = true
              if first_instance && !do_fno then
                if pos >= prev_line.length then
                  context.each do |ll|
                    puts "#{' ' * ($.).to_s.length} #{ll}"
                  end
                  puts "#{$.} #{line.chomp}"
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.}:#{offset+pos+1-prev_line.length}:#{re_str}"
                  end
                else
                  context[0..-2].each do |ll|
                    puts "#{' ' * ($.).to_s.length} #{ll}"
                  end
                  puts "#{$.-1} #{prev_line.chomp}"
                  puts "#{$.} #{line.chomp}"
                  if error_file then
                    error_out = File.open(error_file, "w") unless error_out
                    error_out.puts "#{fn}:#{$.-1}:#{offset+pos+1}:#{re_str}"
                  end
                end
                if post_context_count > 0 then
                  remaining_context = post_context_count
                else
                  puts "---"
                end
                first_instance = false
                count += 1
                offset = line.length - remainder.length
                line = remainder
              end
            end
          end  # rescue
 
          unless found_in_line then
            if remaining_context > 0 then
              puts "#{' ' * ($.).to_s.length} #{line.chomp}"
              remaining_context -= 1
              puts "---" if remaining_context < 1
            else
              context << line.chomp
              context.shift if context.length > pre_context_count
            end
          end
          prev_line = line
        end  # while line = input.gets
      else
        prev_line = ""
        while line = input.gets do
          offset = 0
          begin
            while pos = ((prev_line + line) =~ re) do
              remainder = $'
              puts "\n>>>File: #{fn}" unless found_in_file
              if pos >= prev_line.length then
                puts "#{$.} #{line.chomp}"
                found_in_file = true
                count += 1
                if error_file then
                  error_out = File.open(error_file, "w") unless error_out
                  error_out.puts "#{fn}:#{$.}:#{offset+pos+1-prev_line.length}:#{re_str}"
                end
              else
                puts "#{$.-1} #{prev_line.chomp}"
                puts "#{$.} #{line.chomp}"
                found_in_file = true
                count += 1
                if error_file then
                  error_out = File.open(error_file, "w") unless error_out
                  error_out.puts "#{fn}:#{$.-1}:#{offset+pos+1}:#{re_str}"
                end
              end
              offset = line.length - remainder.length
              line = remainder
            end
          rescue
            # try it this way to avoid encoding error...
            while line.force_encoding("ISO-8859-1") =~ re do
              puts "\n>>>File: #{fn}" unless found_in_file
              if pos >= prev_line.length then
                puts "#{$.} #{line.chomp}"
                found_in_file = true
                count += 1
                if error_file then
                  error_out = File.open(error_file, "w") unless error_out
                  error_out.puts "#{fn}:#{$.}:#{offset+pos+1-prev_line.length}:#{re_str}"
                end
                #line.clear
              else
                puts "#{$.-1} #{prev_line.chomp}"
                puts "#{$.} #{line.chomp}"
                found_in_file = true
                count += 1
                if error_file then
                  error_out = File.open(error_file, "w") unless error_out
                  error_out.puts "#{fn}:#{$.-1}:#{offset+pos+1}:#{re_str}"
                end
              end
              offset = line.length - remainder.length
              line = remainder
            end
          end  # rescue
          prev_line = line
        end  # while line = input.gets
      end  # if pre_context_count > 0 || post_context_count > 0
    end
  end

  puts "...search completed. #{count} found in all files."
  error_out.close if error_out
  exec "vim -q #{error_file}" if edit_files && count > 0
