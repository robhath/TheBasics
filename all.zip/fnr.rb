#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'

if __FILE__ == $0 then
  
  get_args(min: 2, nmin: 0, syntax: "fnr.rb <file-or-directory-name>... -f <find-re> -r <replace-str> -ext <file-extensions> --ow --i --m --x")
  files = []
  changed_files = []
  extensions = $args["-ext"] || "html,xml"

  if $nargs.empty? then
    files += Dir.glob("./**/*.{#{extensions}}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{#{extensions}}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{#{extensions}}")
       else
         files << narg
       end
     end  # $nargs.each
  end

  options = nil
  options = (options ? options | Regexp::MULTILINE : Regexp::MULTILINE) if $args["--m"] 
  options = (options ? options | Regexp::IGNORECASE : Regexp::IGNORECASE) if $args["--i"] 
  options = (options ? options | Regexp::EXTENDED : Regexp::EXTENDED) if $args["--x"] 
  if options then
    findRE = Regexp.new($args["-f"], options)
  else
    findRE = Regexp.new($args["-f"])
  end
  replace = $args["-r"]
  count = 0

  show_it = "Find and Replace: find=[#{findRE}] replace=[#{replace}]"
  puts show_it
  puts ("-" * show_it.length)

  files.each do |f|
    buffer = String.new
    changed = false
    $stderr.puts ">>> " + f
    buffer = ""
    File.open(f, "r") do |input|

      buffer = input.read
      buffer.gsub!(findRE) do |str|
        changed = true
        count += 1
        $stderr.print "*"
        replace
      end

    end
    $stderr.puts
    if changed then
      changed_files << f
      File.open(f + ".new", "w") do |output|
        output.print buffer
      end
    end
  end

  if $args["--ow"] then
    changed_files.each do |f|
      File.delete(f)
      File.rename(f + ".new", f)
    end
  end

  $stderr.puts "#{count.to_s} instances replaced"
end

