#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'
require 'diff.rb'

if __FILE__ == $0 then
  
  get_args(min: 2, nmin: 0, syntax: "fnr.rb <file-or-directory-name>... -f <find-re> (-r <replace-str> | -rr <ruby-expression>) -ext <file-extensions> --chgs --diff --ow --i --m --x")
  files = []
  changed_files = []
  extensions = $args["-ext"] || "html,xml"
  diff_file = nil
  diff_out = nil
  the_changes = ($args["--chgs"] ? Array.new : nil)

  if $nargs.empty? then
    files += Dir.glob("./**/*.{#{extensions}}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{#{extensions}}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{#{extensions}}")
       else
         files << narg
       end
     end  # $nargs.each
  end

  options = nil
  options = (options ? options | Regexp::MULTILINE : Regexp::MULTILINE) if $args["--m"] 
  options = (options ? options | Regexp::IGNORECASE : Regexp::IGNORECASE) if $args["--i"] 
  options = (options ? options | Regexp::EXTENDED : Regexp::EXTENDED) if $args["--x"] 
  if options then
    findRE = Regexp.new($args["-f"], options)
  else
    findRE = Regexp.new($args["-f"])
  end
  replace = $args["-r"]
  eval_replace = $args["-rr"]
  if $args["--diff"] then
    diff_file = "diff.fnr.txt"
  end

  count = 0

  show_it = "Find and Replace: find=[#{findRE}] replace=[#{replace}]"
  puts show_it
  puts ("-" * show_it.length)

  files.each do |f|
    buffer = String.new
    old_buffer_array = Array.new
    changed = false
    $stderr.puts ">>> " + f
    buffer = ""
    File.open(f, "r") do |input|

      buffer = input.read
      old_buffer_array = buffer.split("\n") if diff_file
      if eval_replace then
        buffer.gsub!(findRE) do |str|
          changed = true
          count += 1
          $stderr.print "*"
          change_to = String.new(eval(eval_replace))
          the_changes << "#{$&} => #{change_to}" if the_changes
          change_to
        end
      else
        buffer.gsub!(findRE) do |str|
          changed = true
          count += 1
          $stderr.print "*"
          the_changes << "#{$&} => #{replace}" if the_changes
          replace
        end
      end

    end  # File.open

    $stderr.puts
    if changed then
      changed_files << f
      File.open(f + ".new", "w") do |output|
        output.print buffer
      end

      if diff_file then
        diff_out = File.open(diff_file, "w") unless diff_out
        diff_out.puts "file: #{f}"
        diff_out.puts diff(old_buffer_array, buffer.split("\n"))
        diff_out.puts "\n\n"
      end
    end

  end  # files.each

  if $args["--ow"] then
    changed_files.each do |f|
      File.delete(f)
      File.rename(f + ".new", f)
    end
  end

  if the_changes then
    puts "\nThe following changes were made:"
    the_changes.uniq!
    puts the_changes.join("\n")
  end

  puts "\n#{count.to_s} instances replaced"
end

