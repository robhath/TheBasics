#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'Stringx'

  
if __FILE__ == $0 then
  
  start_time = Time.new
  output_dir = ""
  pattern = ""
  patternRE = nil
  just_pattern = nil
  just_tags = false
  indices = []
  ignore_case = false
  include_toc = false
  context_size = 48
  recursive_depth = 1
  max_visits = 1024
  stay_in_domain = false
  current_domain = nil
  links_visited = 0
  
  if i = ARGV.index("-o") then
    output_dir = ARGV[i+1].gsub("\\", "/")
    output_dir << "/" unless output_dir[-1] == "/"
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-x") then
    cs = ARGV[i+1].to_i(0)
    context_size = cs if cs > -1 && cs < 2048
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-depth") then
    rd = ARGV[i+1].to_i(0)
    recursive_depth = rd if rd > -1 && rd < 2048
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-visits") then
    vv = ARGV[i+1].to_i(0)
    max_visits = vv if vv > -1 && vv < 4096
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-i") then
    ignore_case = true
  end

  if i = ARGV.index("-tags") then
    just_tags = true
  end

  if i = ARGV.index("-toc") then
    include_toc = true
  end

  if i = ARGV.index("-stay") then
    stay_in_domain = true
  end

  if i = ARGV.index("-p") then
    pattern = ARGV[i+1].gsub("\\", "/")
    patternRE = Regexp.new("((^|\\n):id:(.+?):(.*?):)|(#{pattern.gsub(/\s+/, "\\s+")})", 
        (ignore_case ? Regexp::IGNORECASE : 0) || Regexp::MULTILINE)
    just_pattern = Regexp.new(pattern, 
        (ignore_case ? Regexp::IGNORECASE : 0) || Regexp::MULTILINE)
    ARGV[i+1] = nil
  end

  if !patternRE || ARGV.length < 3 then
    $stderr.puts "wormy.rb <path, file or directory> ...  -p <pattern> 
      [-i] [-o <output-directory>] [-depth <integer>] [-visits <integer>] [-toc] [-stay] [-tags]"
    exit
  else
    line1 = "XML Wormy  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    puts line1
    line2 = "#{patternRE} depth=#{recursive_depth.to_s}"
    puts line2
    max = (line1.length > line2.length ? line1.length : line2.length)
    puts "=" * max
  end
  
  x = nil
  indexfn = ""
  ARGV.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
    current_depth = 0
  
    links = []
    if arg =~ /^\s*http/ then
      links << arg
    elsif File.directory?(arg) then
      links += Dir.glob("#{arg}/**/*.{html,xml}")
    else
      links << arg
    end
    $stderr.puts links.join(";")
    
    output_is_relative = (output_dir[0..1] == "..")
    recursion_cutoff = links.length
    i = 0
    current_domain = links[i].get_link_parts()["domain"] unless current_domain
    while i < links.length && links_visited <= max_visits do
      $stderr.puts "#{links[i]} not in same domain, skipping..." if stay_in_domain && links[i].get_link_parts()["domain"] != current_domain
      if stay_in_domain && links[i].get_link_parts()["domain"] != current_domain then
        i += 1
        next 
      end
      x = XML.parse_link(links[i])
      
      buffer = x.to_txt(false, ["head"]).xml2txt
      links_visited += 1
      
      cur_path = File.dirname(links[i])
      if cur_path == "." then
        cur_path = ""
      else
        cur_path << "/"
      end
      
      if current_depth < recursive_depth then
        more_links = x.get_links
        more_links.each do |link|
          da_link = link.sub(/(?<=\.html).+/, "")
          if link =~ /\.html\?/ then
            # ignore it
          elsif link =~ /^\s*http/ then
            links << da_link unless links.index {|obj| obj.downcase == da_link.downcase }
            #~ $stderr.puts "!!!circular:#{link}" if links.index {|obj| obj.downcase == da_link.downcase }
          else
            links << (cur_path + da_link) unless links.index {|obj| obj.downcase == (cur_path + da_link).downcase }
            #~ $stderr.puts "!!!circular:#{link}" if links.index {|obj| obj.downcase == (cur_path + da_link).downcase }
          end
        end
        if i >= recursion_cutoff then
          current_depth += 1 
          recursion_cutoff = links.length
        end
      end
      
      current_id = ""
      current_title = ""
      prev_id = "yoicks"
      if just_tags then
        x.each do |y|
          if y.attributes["id"] then
            current_id = y.attributes["id"]
            current_title = ""
          end
          if (index = XML::TITLE_TAGS.find_index {|main_tag, sub_tag| y.tag == main_tag }) then
            current_title = y.get_pcdata( XML::TITLE_TAGS[index][1]).gsub(/\s+/, " ")
          end
          if y.tag =~ just_pattern then
            what = y
            if current_id != prev_id then
              indices << "<p><a href=\"#{links[i] + "#" + current_id.to_xml}\">#{current_title.to_xml}</a></p>"
            end
            indices << "<p>...#{what}...</p>"
            prev_id = current_id
          end
        end
      else
        while buffer =~ patternRE do
          if $3 then
            current_id = $3 unless $3.empty?
            current_title = $4 unless $4.empty?
            current_title = "Table of Contents" if current_id == "toc"
            buffer = $'
          else
            found = $&
            before = $`
            after = $'
            buffer = $'
            next if current_id == "toc" && !include_toc
            before.slice!(0..-context_size) if before.length > context_size
            after.slice!(context_size..-1) if after.length > context_size
            what = "#{before.to_xml}<span style=\"color:red\">#{found.to_xml}</span>#{after.to_xml}".gsub(/\s{2,}/, " ")
            if current_id != prev_id then
              indices << "<p><a href=\"#{links[i] + "#" + current_id.to_xml}\">#{current_title.to_xml}</a></p>"
            end
            indices << "<p>...#{what}...</p>"
            prev_id = current_id
          end
        end
      end
      
      #~ ofbn = File.basename(fn, ".*")
      if indexfn.empty? then
        od = String.new(output_dir)
        if (output_is_relative || output_dir.empty?) && 
            links[i] !~ /^\s*http/ && File.directory?(links[i]) then
          od.prepend(File.dirname(links[i]) + "/")
        end
        indexfn = od + "index.html" 
        #~ File.open(od + ofbn + ".txt", "w") {|output| output.puts buffer }
      end
      
      i += 1
    end
  end
  
  #~ $indices.uniq! {|a| (a[0].downcase + a[1] + a[2]) } 
  #~ $indices.sort! {|a, b| a[0].downcase <=> b[0].downcase }
  File.open(indexfn, "w") do |output| 
    #~ output.puts "term,filename,title,id"
    #~ $indices.each {|w, fn, title, id| output.puts ("#{w.to_csv},#{fn.to_csv},#{title.to_csv},#{id.to_csv}") }
    output.puts XML::HTML_pre
    indices.each {|index| output.puts index }
    output.puts XML::HTML_post
  end
  
  puts "links visited = #{links_visited.to_s}, elapsed time = #{Time.new - start_time} seconds"
  
  if RUBY_PLATFORM =~ /mingw/ then
    puts `start #{indexfn}`
  else
    puts `xdg-open #{indexfn}`
  end
  
end
