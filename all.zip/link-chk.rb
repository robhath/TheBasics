#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'Stringx.rb'
require 'args'


if __FILE__ == $0 then
  
  error_file = nil
  files = []
  error_out = nil
  fn = nil
  found = false
  verbose = false

  get_args(syntax: 
    "syntax:\n  link-chk.rb  <HTMLfile|directory>...  
    --edit    edit problem files with vim
    --verbose list okay references")

  puts "========================================"
  puts "HTML Link Checker  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "========================================"
  
  dir = "."  # by default the current directory
  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^--edit/ then
        error_file = "#{ENV["HOME"]}/.html.err.txt"
      when /^-d/ then
        i += 1
        dir = ARGV[i] if ARGV.length > i
      when /^--verbose/ then
        verbose = true
      end
      i += 1
  end
  
  a = Dir.glob("#{dir}/**/*.{html}")
  x = nil
   
    a.each do |fn|
      next if File.directory?(fn)
      puts "\n>>>#{fn}<<<" if verbose
      found = false
      File.open(fn, "r") do |input|  
        x = XML.parse_p(input, (fn =~ /\.html?$/)) do |line, start_column, context, buffer| 
          # deal with any basic HTML syntax errors here; link check will be done later
          if buffer[0..5] == "ERROR:" then
            puts "\n>>>File: #{fn}" unless found
            puts buffer[6..-1]
            found = true
            if error_file then
              error_out = File.open(error_file, "w") unless error_out
              error_out.puts "#{fn}:#{buffer[6..-1]}"
            end
          end
        end

        x.each do |y|
          if y.attributes.has_key?("href") then
            href = y.attributes["href"]
            if href =~ /^https?:/ && href !~ /topic_url/ then 
              # $stderr.puts href
              report = `curl --head #{href} 2> /dev/null`
              # $stderr.puts report
              if report =~ /^HTTP\S*\s+(\d{3})/ then
                res = $1
                case res[0]
                  when '1'
                    if verbose then
                      puts "informational: #{fn}:#{y.pos}[#{href}:#{res}]"
                      if error_file then
                        error_out = File.open(error_file, "w") unless error_out
                        error_out.puts "#{fn}:#{y.pos}:informational[#{href}:#{res}]"
                      end
                    end
                  when '2'
                    if verbose then
                      puts "OK (successful): #{fn}:#{y.pos}[#{href}:#{res}]"
                      if error_file then
                        error_out = File.open(error_file, "w") unless error_out
                        error_out.puts "#{fn}:#{y.pos}:OK (successful)[#{href}:#{res}]"
                      end
                    end
                  when '3'
                    puts "redirection: #{fn}:#{y.pos}[#{href}:#{res}]"
                    if error_file then
                      error_out = File.open(error_file, "w") unless error_out
                      error_out.puts "#{fn}:#{y.pos}:redirection[#{href}:#{res}]"
                    end
                  when '4'
                    puts "broken link (client error): #{fn}:#{y.pos}[#{href}:#{res}]"
                    if error_file then
                      error_out = File.open(error_file, "w") unless error_out
                      error_out.puts "#{fn}:#{y.pos}:broken link[#{href}:#{res}]"
                    end
                  when '5'
                    if verbose then
                      puts "server error: #{fn}:#{y.pos}[#{href}:#{res}]"
                      if error_file then
                        error_out = File.open(error_file, "w") unless error_out
                        error_out.puts "#{fn}:#{y.pos}:server error[#{href}:#{res}]"
                      end
                    end
                  else
                end

              else
                puts "invalid response: #{fn}:#{y.pos}[#{href}:#{res}]"
                if error_file then
                  error_out = File.open(error_file, "w") unless error_out
                  error_out.puts "#{fn}:#{y.pos}:invalid response[#{href}:#{res}]"
                end
              end
            end 
          end
        end
      end 
    end
  
  if error_out then
    error_out.close
    exec "vim -q #{error_file}" 
  end

end

