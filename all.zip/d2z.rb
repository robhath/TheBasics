#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'args.rb'


  $list_type = {
    "1" => "itemizedlist",
    "2" => "orderedlist",
    "23" => "orderedlist",
    "24" => "orderedlist",
    "32" => "orderedlist",
    "38" => "orderedlist",
    "55" => "itemizedlist",
    "63" => "itemizedlist",
    "64" => "orderedlist"
  }
  
  $numbering = Hash.new(Hash.new("itemizedlist"))
  $numbering["bullet"] = Hash.new("itemizedlist")
  $numbering["number"] = Hash.new("orderedlist") 
  
  $list_type.default = "foobarlist"
  
  $references = {}
  $latest_id = nil
  $counter = "00000"
  
  
class Array
  
  def do_body()
    results = []
    
    sections = []
    lists = []
    programlisting = nil
    
    self.each do |c|
      
      case c.tag
        when /Heading(\d)/i
          new_level = $1.to_i
          c.tag = "title";  c.attributes.clear
          newid =  "id#{$counter.succ!}"
          $latest_id = newid
          c.attributes["id"] = newid + ".title"
          new_section = XML.new((new_level < 2 ? "chapter" : "section"), {"id" => newid}, "", [c])
          while !sections.empty? && new_level <= sections.last[1] do
            sections.pop
          end
          results << new_section if sections.empty?
          sections.last[0].child << new_section if sections.last
          sections << [new_section, new_level]
          c.fix_ws
          
          
        when /ListParagraph/i
          new_level = c.attributes["ilvl"].to_i + 1
          #~ list_type = $list_type[c.attributes["numId"]]
          $stderr.puts "looking up numId=#{c.attributes["numId"]} ilvl=#{c.attributes["ilvl"]}"
          list_type = $numbering[c.attributes["numId"]][c.attributes["ilvl"]]
          inheritnum = c.attributes["inheritnum"]
          c.tag = "para"
          c.attributes.clear
          new_li = XML.new("listitem", {}, "", [c])
          while !lists.empty? && new_level < lists.last[1] do
            lists.pop
          end
          if lists.empty? || new_level > lists.last[1] then
            lists << [XML.new(list_type), new_level]
            lists.last[0].attributes["inheritnum"] = "inherit" if inheritnum
            if lists[-2] then
              lists[-2][0].child.last.child << lists.last[0]
            else
              if sections.last then
                sections.last[0].child << lists.last[0]
              else
                results << lists.last[0]
              end
            end
          end
          lists.last[0].child << new_li
          c.fix_ws
          
          
        when /blockquote/i
          c.tag = "para";  c.attributes.clear
          c.fix_ws
          if lists.empty? || lists.last[0].child.empty? then
            if sections.last then
              sections.last[0].child << c
            else
              results << c
            end
          else
            lists.last[0].child.last.child << c
          end
          
          
        when /programlisting/i
          c.fix_ws
          if programlisting then
            programlisting.child += c.child
            programlisting.child << XML.new("", {}, "\n")
          else
            programlisting = c
            if sections.last then
              sections.last[0].child << c
            else
              results << c
            end
          end
          
        when /(para|title)/i
          lists.clear
          programlisting = nil
          c.fix_ws
          if sections.last then
            sections.last[0].child << c
          else
            results << c
          end
          
          
        else
          lists.clear
          programlisting = nil
          if sections.last then
            sections.last[0].child << c
          else
            results << c
          end
            
            
      end
    end 
    
    
    return results
  end  # do_body
  
end  # Array


class XML
    
  @@col_index = 0
  
  def fix_ws()
    last_one = nil
    self.each do |t|
        if t.tag.empty? then
          t.pcdata.gsub!(/^\n+|\n+$/, "")
          last_one = t
        end
    end
    #~ last_one.pcdata << "\n" if last_one
  end  # fix_ws
  
  
  $cur_link = nil

  def d2z()
    results = []
    
    temp = []
    @child.each {|c| temp += c.d2z }
    
    case @tag
      when "w:b"
        results << XML.new("emphasis", {"role" => "bold"})
        
        
      when "w:body"
        results << XML.new("", {}, "", temp.do_body)
        
        
      when "w:bookmarkStart"
        results << XML.new("anchor", {"id" => @attributes["w:name"]})
        
        
      when "w:fldChar"
        results << self
      
      
      when "w:gridCol"
        @@col_index += 1
        results << XML.new("colspec", {"colnum" => "#{@@col_index}", "colname" => "c#{@@col_index}"})
        
        
      when "w:gridSpan"
        results << self
        
        
      when "w:i"
        results << XML.new("emphasis", {"role" => "italic"})
        
        
      when "w:instrText"
        pcd = self.get_pcdata
        if pcd =~ /REF\s(\S+)/ then
          results << XML.new("w:instrText", {"linkend" => $1})
        end
        
        
      when "w:p"
        r = XML.new("para")
        r2 = nil
        here = nil
        temp.each do |t|
          if t.tag.empty? then
            r.child << t
          elsif t.tag == "embolden" then
            here = XML.new("emphasis", {"role" => "bold"})
            r2.child << here if r2 
            r2 = here unless r2
            r.attributes.merge!(t.attributes)
          elsif t.tag == "anchor" then
            r.child << t
          else
            r.tag = String.new(t.tag)
            r.attributes.merge!(t.attributes)
          end
        end
        if here then
          here.child = r.child
          r.child = [here]
        end
        results << r
        
        
      when "w:pPr"
        newx = XML.new
        self.each do |s|
          case s.tag
            when "w:pStyle"
            
              $stderr.puts "style=#{s.attributes["w:val"]} [[[#{self}]]]"
              
            
              case s.attributes["w:val"]
                when "BodyText"
                  self.each do |b| 
                    if b.tag == "w:numId" then
                      newx.tag = "ListParagraph" 
                      newx.attributes["ilvl"] = "0"
                      newx.attributes["numId"] = "bullet"
                    end
                    newx.tag = "blockquote" if newx.tag.empty? && b.tag == "w:ind"
                  end
                  
                when "BodyTextIndent", "BlockText", "ListContinue2"
                  newx.tag = "blockquote"
                  
                when "Bulletmultiline", "Bulletsingleline"
                  newx.tag = "ListParagraph"
                  newx.attributes["ilvl"] = "0"
                  newx.attributes["numId"] = "bullet"
                  
                when /ListBullet(\d)/
                  newx.tag = "ListParagraph"
                  newx.attributes["ilvl"] = ($1.to_i - 1).to_s
                  newx.attributes["numId"] = "bullet"
                  
                when /List ?Number ?(\d)?/
                  newx.tag = "ListParagraph"
                  newx.attributes["ilvl"] = (($1 || "1").to_i - 1).to_s
                  newx.attributes["numId"] = "number"
                  
                when "ListParagraph"
                  newx.tag = "ListParagraph"
                  newx.attributes["ilvl"] = "0"
                  newx.attributes["numId"] = "number"
                  
                when /TOC(\d)?/
                  newx.tag = "ListParagraph"
                  newx.attributes["ilvl"] = (($1 || "1").to_i - 1).to_s
                  newx.attributes["numId"] = "number"
                  newx.attributes["inheritnum"] = "inherit"
                  
                when "Numberedlistmultiline"
                  newx.tag = "ListParagraph"
                  newx.attributes["ilvl"] = "0"
                  newx.attributes["numId"] = "number"
                  
                when "HTMLPreformatted", "Code"
                  newx.tag = "programlisting"
                  
                when /TableCell/
                  newx.tag = "para"
                  
                when /Caption|TableHead/
                  newx.tag = "embolden"
                  newx.attributes["remap"] = s.attributes["w:val"]
                  
                when /TableofFigures/
                  newx.tag = "para"
                  newx.attributes["remap"] = s.attributes["w:val"]
                  
                else
                  newx.tag = s.attributes["w:val"]
                end
              
            when "w:ilvl"
              newx.attributes["ilvl"] = s.attributes["w:val"]
              
            when "w:numId"
              newx.attributes["numId"] = s.attributes["w:val"] #unless newx.attributes.has_key?("numId")
            
          end
        end
        results << newx
        
        
      when "w:r"
        wrt = XML.new
        wrx = nil
        temp.each do |t|
          if t.tag.empty? then
            if $cur_link then
              $cur_link.child << t
            else
              wrt.child << t
            end
          elsif t.tag == "w:fldChar" then
            if t.attributes["w:fldCharType"] == "begin" then
            elsif t.attributes["w:fldCharType"] == "end" then
              $cur_link = nil
            end
          elsif t.tag == "w:instrText" then
            $cur_link = XML.new("link")
            $cur_link.child << (wrx || wrt)
            wrx = $cur_link
            $cur_link.attributes["linkend"] = t.attributes["linkend"]
          else
            t.child << (wrx || wrt)
            wrx = t
          end
        end
        results << (wrx ? XML.new("", {}, "", [wrx]) : wrt)
      
      
      when "w:strike"
        results << XML.new("emphasis", {"role" => "strike"})
        
        
      when "w:t"
        results <<  XML.new("", {}, self.get_pcdata)
        
        
      when "w:tbl"
        colspecs = []
        tbody = []
        thead = []
        tfoot = []
        caption = nil
        temp.each do |t|
          if t.tag == "colspec" then
            colspecs << t
          elsif t.tag == "row" then
            if t.attributes["type"] == "header" then
              thead << t
              t.attributes.delete("type")
            else
              tbody << t
            end
          end
        end
        tgroup = XML.new("tgroup", {"cols" => colspecs.length.to_s}, "", colspecs)
        tgroup.child << XML.new("thead", {}, "", thead) unless thead.empty?
        tgroup.child << XML.new("tbody", {}, "", tbody) unless tbody.empty?
        results << XML.new("table", {}, "", [XML.new("title"), tgroup])
        #~ results.last.child.insert(0, caption) if caption
        @@col_index = 0
        
        
      when "w:tblGrid"
        results += temp
        @@col_index = 0
        
      
      when "w:tblHeader"
        results << self
        
        
      when "w:tc"
        @@col_index += 1
        entry = XML.new("entry")
        temp.delete_if do |t|
          if t.tag == "w:gridSpan" then
            entry.attributes["namest"] = "c#{@@col_index}"
            entry.attributes["nameend"] = "c#{@@col_index + (t.attributes["w:val"].to_i - 1)}"
            true
          else
            false
          end
        end
        entry.child = temp.do_body
        results << entry
        
        
      when "w:tr"
        type = nil
        temp.delete_if do |t|
          if t.tag == "w:tblHeader" then
            type = "header"
            true
          else
            false
          end
        end
        results << XML.new("row", {}, "", temp)
        results.last.attributes["type"] = type if type
        @@col_index = 0
        
        
      when "w:u"
        results << XML.new("emphasis", {"role" => "underline"})
        
        
      when "w:vertAlign"
        if @attributes["w:val"] == "subscript" then
          results << XML.new("subscript")
        elsif @attributes["w:val"] == "superscript" then
          results << XML.new("superscript")
        end
      
      
      else 
        results += temp
    end
    
    return results
  end  # d2z
  
end  # XML


class Style
  
  attr_accessor :lvl
  attr_accessor :numFmt
  
  def initialize(lvl = 0, numFmt = "")
    @lvl = lvl
    @numFmt = numFmt
  end  # initialize
  
  def to_s
    return "lvl=#{@lvl}, numFmt=#{@numFmt}"
  end  # to_s
  
end  # Style


if __FILE__ == $0 then
  
  get_args(nmin: 1, nsyntax: "d2z.rb <filename>...  [-dir <dirname>]  [-html]")
  $styles = {}
  
  $nargs.each do |arg|
    
    #~ fn = arg.gsub(" ", "\\ ")
    
    `unzip "#{arg}" -d "#{arg}.unzipped"`
    
    document_file = "#{arg}.unzipped/word/document.xml"
    
    #~ $styles.clear
    #~ style_file = document_file.sub(/document\.xml$/, "styles.xml")
    #~ $stderr.puts style_file
    #~ s = nil
    #~ File.open(style_file, "r:UTF-8") {|input| s = XML.parse(input) }
    
    #~ s.child.each do |c|
      #~ if c.tag == "w:styles" then
        #~ c.child.each do |ss|
          #~ if ss.tag == "w:style" then
            #~ $stderr.puts "--> #{ss.attributes["w:styleId"]}"
            #~ $styles[ss.attributes["w:styleId"]] = Style.new
          #~ end
        #~ end
      #~ end
    #~ end
    
    
    num_file = document_file.sub(/document\.xml$/, "numbering.xml")
    $stderr.puts num_file
    n = nil
    File.open(num_file, "r:UTF-8") {|input| n = XML.parse(input) }
    abnum = {}
    n.child.each do |c|
      if c.tag == "w:numbering" then
        c.child.each do |nn|
          if nn.tag == "w:abstractNum" then
            $stderr.puts "abstractNum--> #{nn.attributes["w:abstractNumId"]}"
            abnum[nn.attributes["w:abstractNumId"]] = {}
            nn.child.each do |nnn|
              if nnn.tag == "w:lvl" then
                lvl = nnn.attributes["w:ilvl"]
                #~ abnum[nn.attributes["w:abstractNumId"]] << Style.new(nnn.attributes["w:ilvl"].to_i)
                nnn.child.each do |n4|
                  if n4.tag == "w:numFmt" then
                    #~ abnum[nn.attributes["w:abstractNumId"]].last.numFmt = n4.attributes["w:val"]
                    abnum[nn.attributes["w:abstractNumId"]][lvl] = (n4.attributes["w:val"] == "bullet" ? "itemizedlist" : "orderedlist")
                  end
                end
              end
            end
            $stderr.puts abnum[nn.attributes["w:abstractNumId"]]
          end
        end
        c.child.each do |nn|
          if nn.tag == "w:num" then
            $stderr.puts "num--> #{nn.attributes["w:numId"]}"
            $numbering[nn.attributes["w:numId"]] = {}
            nn.child.each do |nnn|
              if nnn.tag == "w:abstractNumId" then
                $numbering[nn.attributes["w:numId"]].merge!(abnum[nnn.attributes["w:val"]])
              end
            end
            $stderr.puts $numbering[nn.attributes["w:numId"]]
          end
        end
      end
    end
    
    
    
    buffer = ""
    x = nil
    File.open(document_file, "r:UTF-8") {|input| x = XML.parse(input) }
    
    y = XML.new("", {}, "", x.d2z)
    y.space_out!
    
    basename = File.basename(arg, ".*")
    dirname = File.dirname(arg)
    chapter_name = "ch000"
    y.each {|yy| yy.attributes["filename"] = "#{dirname}/#{($args["-dir"] ? ($args["-dir"] + "/") : "")}#{basename}.#{chapter_name.succ!}.xml" if yy.tag == "chapter" }
    
    #~ puts y.to_s(0, true, XML::DOCBOOK_LITERAL_TAGS + ["para", "title"])
    y.to_file(".", ($args["-html"] ? XML::HTML_pre : XML::DOCBOOK_pre).to_s, 0, true, 
          ($args["-html"] ? XML::HTML_LITERAL_TAGS : XML::DOCBOOK_LITERAL_TAGS) + %w( para title ) )
  end
  
end
