
def doit(commands: ["whoami <re>^robhath$"])
  result = true
  commands.each do |str|
    command, checkit = str.split("<re>") 
    re = Regexp.new(checkit) unless checkit.nil? 
    if !command.nil? && !command.empty? then
      msg = `#{command}`
      if $?.exitstatus == 0 then
        unless checkit.nil? then
          unless msg =~ re then
            if block_given? then
              yield msg
            else
              $stderr.puts msg
            end
            result = false
            break
          end
        end
      else
        if block_given? then
          yield msg
        else
          $stderr.puts msg
        end
        result = false
        break
      end
    end
  end
  return result
end  # doit

