#!ruby


class String
  
  def similarity(b)
    # calculate how similar this string is to another
    #   parameters:
    #     b - (string) to be compared with this one
    #   returns: 
    #     score/revScore - (int) the greater of the comparison done forward or reversed
    #  side effects:
    #     n/a
    #     
    
    def rSimilarity(b)
      # perform actual calculation, do it recursively for parts of the strings as necessary
      #   parameters:
      #     b - (string) to be compared with this one
      #   returns: 
      #     score - (int) how similar
      #  side effects:
      #     n/a
      #     
      score = 0.0
      if self == b
        score = 1.0
      else
        case
          when self.index(" ")
            sep = /\W+/
          when self.index(",")
            sep = ","
          when self.index("\t")
            sep = "\t"
          #when self.index("_")
            #sep = "_"
          when self.index("/")
            sep = "/"
          when self.index("\\")
            sep = "\\"
          when self.index("|")
            sep = "|"
          when self.index(":")
            sep = ":"
          else
            sep = //
        end 
        selfList = self.split(sep)
        bList = b.split(sep)
        if selfList.length < bList.length
          listA = selfList
          listB = bList
        else
          listA = bList
          listB = selfList
        end
        cardinality = (listA.length >= listB.length ? listA.length : listA.length + (0.1*listB.length))
        divisors = []
        factors = []
        lastDiff = -1
        listA.each_index {|i|
          diff = -1
          factor = 0
          listB.each_index{|j|
            if listA[i].length > 1
              likeness = listA[i].rSimilarity(listB[j])
            else
              likeness = (listA[i] == listB[j] ? 1 : 0)
            end
            if likeness > 0.45  # arbitrary threshold - tune for greater effectiveness
              newDiff = (i - j).abs
              if newDiff < diff || diff < 0
                diff = newDiff 
                factor = likeness
              end
            end
          }
          if diff >= 0  # matched element i
            if diff == lastDiff
              divisors.pop
              divisors << 1.05
              divisors << 1.05
            else
              divisors << (diff + 1.4)  # was 1.0
            end
            #delta = (diff == lastDiff ? 0.05 : diff)
            #score += (1.0/cardinality)/(delta+1.0)
            lastDiff = diff
            factors << factor
            #$stderr.puts "factor: #{factor}"  #debug
          end
        }
        divisors.each_index {|i| 
          score += factors[i]*((1.0/cardinality)/divisors[i]) 
        }
      end
      return score
    end  # rSimilarity
  
    #begin main part of similarity
    score = 0.0
    if self == b
      score = 1.0
    else
      score = self.rSimilarity(b)
      #through the looking glass...
      revScore = self.reverse.rSimilarity(b.reverse)
      return (score > revScore ? score : revScore)
    end
  
  end  # similarity
  
end  # String


# === main ========
if $0 == __FILE__ then
  puts ARGV[0].similarity(ARGV[1])
end
