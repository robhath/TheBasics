
$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'


class XSD < Validator

# TBD:
#    default attribute?
#    type attribute (element, attribute
#    built-in data types:
    #~ xs:string
    #~ xs:decimal
    #~ xs:integer
    #~ xs:boolean
    #~ xs:date
    #~ xs:time
# element restriction
# restriction + pattern
# restriction + length, etc. etc.

  $groupGroups = {}
  $complexTypes = []
  $aGroups = []

  # Parse the XSD file, returning element, attribute group and complex type definitions found therein.
  #     further processing will be needed to incorporate the attribute groups and complex types into the
  #     elements to complete the validation engine (Array<Validator>).
  # 
  # @param  x  [XML]    the XSD as an XML structure
  # @param  elements  [Array<Validator>]    the incipient validation engine
  # @return  [Array<String, Hash<key=String, value=Array<Regexp, String>>>]    used in recursive 
  #     calls to percolate up XSD definitions in hierarchy below
  def self.parse(x, elements)
    #~ puts "parseXSD tag=#{x.tag}"
    results = [[], {}]
    
    x.child.each do |c|
      r = parse(c, elements)
      results[0] += r[0]
      results[-1].merge!(r[-1])
    end
      
    repeat = "{#{(x.attributes["minOccurs"] || "1")},#{(x.attributes["maxOccurs"] || "1")}}"
    repeat.sub!("unbounded", "")
    repeat = "" if repeat == "{1,1}"
    
    case x.tag
      when "xs:element"
        if ref = x.attributes["ref"] then
          results[0] << "(#{ref[/(xi:)?[^:]+$/]})#{repeat}"
        elsif n = x.attributes["name"] then
          elements << XSD.new(n, results[-1], Regexp.new("^#{results[0].join}$"), 
              (x.attributes["type"] || ""))
          results[0] << "(#{n})#{repeat}"
        end
        
      when "xs:enumeration" then
        if v = x.attributes["value"] then
          results[0] << "(#{v})#{repeat}"
        end
        
      when "xs:restriction" then
        results[0] = ["(#{results[0].join("|")})#{repeat}"]
        
      when "xs:pattern" then
        if v = x.attributes["value"] then
          results[0] << "(#{v})"
        end
      
      when "xs:choice" then
        results[0] = ["(#{results[0].join("|")})#{repeat}"]
        
      when "xs:sequence" then
        results[0] = ["(#{results[0].join("")})#{repeat}"]
      
      when "xs:all" then
        len = results[0].inject(0) {|n, r| n + r[/[^(){}]+/].length }
        results[0] = ["((?<=.*#{results[0].join(")(?=.*")}).{#{len}})"]
      
      when "xs:attribute" then
        # TBD: type attribute
        if x.attributes["fixed"] then
          requisite = "#FIXED" 
          regex = Regexp.new("^#{x.attributes["fixed"]}$")
        else
          requisite = (x.attributes["use"] ? (x.attributes["use"] =~ /required/i ? "#REQUIRED" : "#IMPLIED") : "#IMPLIED")
          regex = Regexp.new("^#{(results[0].empty? ? ["(.+)"] : results[0] ).join("|")}$")
        end
        if ref = x.attributes["ref"] then
          results[-1][ref[/(xi:)?[^:]+$/]] = [regex, requisite]
        elsif n = x.attributes["name"] then
          results[-1][n] = [regex, requisite]
        end
        results[0] = []
        
      when "xs:attributeGroup"
        if ref = x.attributes["ref"] then
          if i = $aGroups.index {|ag| ag[0] == ref } then
            results[-1] = $aGroups[i][-1]
          else
            results[-1]["group:" + ref[/(xi:)?[^:]+$/]] = ""
          end
          results[0] = []
        elsif n = x.attributes["name"] then
          $aGroups << [n, results[-1]]
        end
        
      when "xs:complexType" then
        if x.attributes["mixed"] == "true" then
          # pass it along/up in the attributes we're collecting,
          #   we'll change the XSD in post-processing
          results[-1]["<mixed>"] = "<mixed>"
        end
        if n = x.attributes["name"] then
          $complexTypes << XSD.new(n, results[-1], Regexp.new("^#{results[0].join}$"))
          $groupGroups[n] = results[0]
        end
        
      when "xs:simpleType" then
      
      when "xs:union" then
      when "xs:list" then
      
      when "xs:extension" then
        if base = x.attributes["base"] then
          if $groupGroups.has_key?(base)
              results[0] << $groupGroups[base] 
          end
        elsif n = x.attributes["name"] then
          elements << XSD.new(n, results[-1], Regexp.new("^#{results[0].join}$"), 
              (x.attributes["type"] || ""))
          results[0] << "(#{n})#{repeat}"
        end
        
      when "xs:group" then
        if x.attributes["mixed"] == "true" then
          results[-1]["<mixed>"] = "<mixed>"
        end
        if ref = x.attributes["ref"] then
          results[0] << $groupGroups[ref] 
        elsif n = x.attributes["name"] then
          $complexTypes << XSD.new(n, results[-1], Regexp.new("^#{results[0].join}$"))
          $groupGroups[n] = results[0]
        end
        
      when "xs:any" then
        results[0] << "(.+)#{repeat}"  # !!!
        
      when "xs:anyAttribute" then
        # TBD: ???
        
      when "xs:annotation" then
        if x.attributes["recommend"] == "false" then
          # pass it along/up in the attributes we're collecting,
          #   we'll change the XSD in post-processing
          explain = ""
          x.each do |y| 
            if y.tag.empty? then
              explain << " " unless explain.empty?
              explain << y.pcdata.strip.xml2txt
            end
          end
          results[-1]["<recommend>"] = explain
        end
      
    end
      
    return results
  end  # parse


  # Build a validation engine (Array of Validation elements) based on the XSD embodied in the given XML.
  #
  # @param  xsd  [XML]    
  # @param  elements  [Array<Validator>]    will be filled with XSD Validators
  # @return  void
  def self.buildValidationEngine(xsd, elements)
    r = parse(xsd, elements)
    
    elements.each do |e|
      if !e.type.empty? then
        if i = $complexTypes.index {|ct| ct.name == e.type } then
          e.attributes.merge!($complexTypes[i].attributes)  # can't just assign here because we are going to delete below!!!
          e.childREn = $complexTypes[i].childREn.dup
        end
      end
      
      add_me = []
      delete_me = []
      e.attributes.each_key do |key|
        if key[0..5] == "group:" then
          $aGroups.each_index do |i|
            if key[6..-1] == $aGroups[i][0] then
              add_me << i
              delete_me << key
              break
            end
          end
        elsif key == "<mixed>" then
          e.mixed = true
          delete_me << key
        elsif key == "<recommend>" then
          e.recommend = e.attributes[key]
          delete_me << key
        end
      end
      add_me.each {|index| e.attributes.merge!($aGroups[index][1]) }
      delete_me.each {|key| e.attributes.delete(key) }
      #~ $stderr.puts "element name=#{e.name} attributes=#{e.attributes} childREn=#{e.childREn} type=#{e.type} mixed=#{e.mixed}"
    end
  end  # buildValidationEngine
  
end  # class XSD
