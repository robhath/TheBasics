#!ruby

if __FILE__ == $0 then
  $LOAD_PATH << File.dirname($0)
end

require 'Stringx.rb'
require 'yamlx.rb'
require 'net/http'
require 'stringio'


# An XML node.
# 
# @member  tag  [String] 
# @member  attributes  [Hash]  
# @member  pcdata  [String]
# @member  child  [Array<XML>]
# @member  pos  [String]    position of start of element in original file ("line:column")
class XML
  
  include Enumerable
  
  attr_accessor :tag             
  attr_accessor :attributes    
  attr_accessor :pcdata        
  attr_accessor :child           
  attr_accessor :pos             
  
  $line = 0
  $column = 0
  $context = []
  
  def initialize(tag = "", attributes = {}, pcdata = "", child = [])
    @tag = tag
    @attributes = attributes
    @pcdata = pcdata
    @child = child
  end  # initiailize
  
  
  def copy()
    result = XML.new()
    result.tag << self.tag
    result.attributes.merge!(self.attributes)
    result.pcdata << self.pcdata
    result.pos = String.new(self.pos) if self.pos
    self.child.each do |c|
      result.child << c.copy
    end
    return result
  end  # copy
  
  
  # Convert this node to a string representation.
  #
  # @param  level  [Integer]  current level in hierarchy for use in automatic indent
  # @param  do_indent  [Boolean]  true = do the automatic indent
  # @param  literal_tags  [Array of String]  the tags to treat as containers of literal content
  #        (i.e. don't add/delete whitespace)
  # @return  [String]  the string representation
  def to_s(level = 0, do_indent = false, literal_tags = [])
    literal = literal_tags.index(@tag)
    tag1 = @tag.empty? ? "" : "<#{@tag}"
    closeit = (@tag[0] == "?" ? "?" : (@tag[0] == "!" ? "" : "/"))
    a = []
    @attributes.each do |key, value| 
      a << "#{key}=\"#{value}\"" 
    end
    attrs = a.join(" ")
    attrs.prepend(" ") unless attrs.empty?
    children = ""
    @child.each {|x| children << x.to_s(level+1, do_indent && !literal, literal_tags) }
    #~ children.chomp! if literal
    tag2 = @tag.empty? ? "" : (children.empty? ? "#{closeit}>" : ">")
    close_tag = children.empty? ? "" : (@tag.empty? ? "" : "</#{@tag}>")
    if do_indent then
      indent = (@tag.empty? || children.empty?) ? "" : ("\n" + "  " * level)
      return "#{indent}#{tag1}#{attrs}#{@pcdata.chomp}#{tag2}#{children.chomp}#{(children.count("\n") > 1 && !literal) ? indent : ""}#{close_tag}"
    else
      return "#{indent}#{tag1}#{attrs}#{@pcdata}#{tag2}#{children}#{close_tag}"
    end
  end  # to_s
  
  
  # Output this node to the file(s) specified by its (or its sub-node's) "filename" attribute.
  #
  # @param  dir  [String]  prepend this to each filename
  # @param  header  [String]  prepend this to contents of each file 
  # @param  level  [Integer]  current level in hierarchy for use in automatic indent
  # @param  do_indent  [Boolean]  true = do the automatic indent
  # @param  literal_tags  [Array of String]  the tags to treat as containers of literal content
  #        (i.e. don't add/delete whitespace)
  # @return  [String]  pass up contents or empty string if file written at this node
  def to_file(dir, header = "", level = 0, do_indent = false, literal_tags = [])
    filename = nil
    literal = literal_tags.index(@tag)
    tag1 = @tag.empty? ? "" : "<#{@tag}"
    closeit = (@tag[0] == "?" ? "?" : (@tag[0] == "!" ? "" : "/"))
    a = []
    @attributes.each do |key, value| 
      if key == "filename" then
        filename = value
      else
        a << "#{key}=\"#{value}\"" 
      end
    end
    attrs = a.join(" ")
    attrs.prepend(" ") unless attrs.empty?
    children = ""
    @child.each {|x| children << x.to_file(dir, header, level+1, do_indent && !literal, literal_tags) }
    #~ children.chomp! if literal
    tag2 = @tag.empty? ? "" : (children.empty? ? "#{closeit}>" : ">")
    close_tag = children.empty? ? "" : (@tag.empty? ? "" : "</#{@tag}>")
    buffer = ""
    if do_indent then
      indent = (@tag.empty? || children.empty?) ? "" : ("\n" + "  " * level)
      buffer << "#{indent}#{tag1}#{attrs}#{@pcdata.chomp}#{tag2}#{children.chomp}#{(children.count("\n") > 1 && !literal) ? indent : ""}#{close_tag}"
    else
      buffer << "#{indent}#{tag1}#{attrs}#{@pcdata}#{tag2}#{children}#{close_tag}"
    end
    if filename then
      File.open(dir + (dir[-1] == "/" ? "" : "/") + filename, "w:UTF-8") {|output| output.puts(header + buffer) }
      return ""
    else
      return buffer
    end
  end  # to_file
  
  
  # Perform the specified action in a breadth-first traversal beginning at this node.
  #
  # @block  [XML]    action performed on each XML node
  # @return  void
  def each()
    yield self
    child.each do |c|
      c.each {|d| yield d }
    end
  end  # each
  
  
  # Perform the specified action in a depth-first traversal beginning at this node.
  #
  # @block  [XML]    action performed on each XML node
  # @return  void
  def dfeach()
    child.each do |c|
      c.dfeach {|d| yield d }
    end
    yield self
  end  # dfeach
  
  
  
  # Perform the specified action in a breadth-first traversal beginning at this node,
  #        keeping track of the "context", i.e. of the tags encountered as parents.
  #
  # @param  context  [Array of String]
  # @block  [XML]    action performed on each XML node
  # @return  void
  def ceach(context)
    context << self.tag
    yield self, context
    child.each do |c|
      c.ceach(context) {|d, context| yield d, context }
    end
    context.pop
  end  # each
  
  
  #########################################################
  # process inline if, elsif, else, each, expandomatic, addthis, etc. tags as commands...
  #########################################################
  
  $_xml_eval = [{}]
  $_xml_eval_iftests = [false]
  $_xml_eval_subtemplates = {}
  $_xml_eval_subtemplate_origins = {}
  $_xml_eval_locations = {}
  $_xml_eval_metatags = %w( addthis dothis each else elsif expandomatic if location nochange subdo subtemplate )
  $the_header = nil
  
  def evaluate!(b = binding)
    #~ $stderr.puts "evaluate! tag=#{@tag}"
    if @tag == "if" then
      $_xml_eval_iftests[-1] = false
      begin
        eval('$_xml_eval_iftests[-1] = (' + @attributes["test"].xml2txt + ') ? true : false', b) if @attributes.has_key?("test")
        @child = [] unless $_xml_eval_iftests.last
      rescue
        $stderr.puts "Error occured in if (@#{self.pos})::
    eval($_xml_eval_iftests[-1] = (#{@attributes["test"].xml2txt}) ? true : false)\n#{$!}"
        #~ $stderr.puts "if:: #{$_xml_eval_iftests.length}, #{$_xml_eval_iftests.last}:#{$_xml_eval_iftests.last.class}"
      end
      
    elsif @tag == "elsif" then
      #~ $stderr.puts "elsif:: #{$_xml_eval_iftests.length}, #{$_xml_eval_iftests.last}:#{$_xml_eval_iftests.last.class}"
      if $_xml_eval_iftests.last then
        @child = []
      else
        $_xml_eval_iftests[-1] = false
        begin
          eval('$_xml_eval_iftests[-1] = ' + @attributes["test"].xml2txt, b) if @attributes.has_key?("test")
          @child = [] unless $_xml_eval_iftests.last
        rescue
          $stderr.puts "Error occured in elsif (@#{self.pos})::
    eval($_xml_eval_iftests[-1] = #{@attributes["test"].xml2txt})\n#{$!}"
        end
      end
      
    elsif @tag == "else" then
      #~ $stderr.puts "else:: #{$_xml_eval_iftests.length}, #{$_xml_eval_iftests.last}:#{$_xml_eval_iftests.last.class}"
      @child = [] if $_xml_eval_iftests.last
      
    elsif @tag == "each" then
      $_xml_eval << {}
      $_xml_eval.last[:values] = []
      is_list = @attributes["varlist"].include?(",")
      begin
        #~ $stderr.puts "eval(#{@attributes["iterator"]}.each {|#{@attributes["varlist"]}| $_xml_eval.last[:values] << #{is_list ? "[" : ""}#{@attributes["varlist"]}#{is_list ? "]" : ""} })"
        eval(@attributes["iterator"] + '.each {|' + @attributes["varlist"] + '| $_xml_eval.last[:values] << ' + (is_list ? '[' : '') +
            @attributes["varlist"] + (is_list ? ']' : '') + '} if ' + @attributes["iterator"], b)
      rescue
        $stderr.puts "Error occured in each (@#{self.pos})::
    eval(#{@attributes["iterator"]}.each {|#{@attributes["varlist"]}| $_xml_eval.last[:values] << #{is_list ? "[" : ""}#{@attributes["varlist"]}#{is_list ? "]" : ""} } if #{@attributes["iterator"]}\n#{$!}"
      end
      new_children = []
      $_xml_eval.last[:temp1] = XML.new("", {}, "", @child)
      $_xml_eval.last[:values].each do |_xml_eval_val|
        $_xml_eval.last[:tempx] = $_xml_eval.last[:temp1].copy
        begin
          eval(@attributes["varlist"] + ' = ' + (_xml_eval_val.respond_to?(:chars) ? ('"' + _xml_eval_val + '"') : _xml_eval_val.to_s) + '
          $_xml_eval.last[:tempx].evaluate!(binding)', b)
          new_children << $_xml_eval.last[:tempx]
        rescue
          $stderr.puts "Error occured in each/iteration (@#{self.pos})::
    eval(#{@attributes["varlist"]} = #{(_xml_eval_val.respond_to?(:chars) ? ('"' + _xml_eval_val + '"') : _xml_eval_val.to_s)}
    $_xml_eval.last[:tempx].evaluate!(binding)\n#{$!}"
        end
      end
      @child = new_children
      $_xml_eval.pop
      return  # because we already called evaluate! recursively
      
    elsif @tag == "dothis" then
      begin
        eval(self.get_pcdata.xml2txt, b)
      rescue
        $stderr.puts "Error occured in dothis (@#{self.pos})::
    eval(#{self.get_pcdata.xml2txt})\n#{$!}"
      end
      @child = []
      
    elsif @tag == "expandomatic" then
      $_xml_eval_expand = []
      begin
        eval('$_xml_eval_expand += struct_to_xml(' + @attributes["what"] + 
                (@attributes.has_key?("parent") ? (', ' + @attributes["parent"]) : '') + 
                (@attributes.has_key?("html") ? ',  tags: HTML_STRUCT_TAGS' : '') + 
                ((@attributes.has_key?("follow") && @attributes["follow"] != "true") ? ',  follow_link: false' : '') + 
                ')', b)
      rescue
        $stderr.puts "Error occured in expandomatic (@#{self.pos})::
    eval('$_xml_eval_expand += struct_to_xml(#{@attributes["what"]}#{(@attributes.has_key?("parent") ? (', ' + @attributes["parent"]) : '')} 
      #{(@attributes.has_key?("html") ? ',  tags: HTML_STRUCT_TAGS' : '')}
      #{((@attributes.has_key?("follow") && @attributes["follow"] != "true") ? ',  follow_link: false' : '')})', b)\n#{$!}"
      end
      @child += $_xml_eval_expand
      
    elsif @tag == "addthis" then
      if @attributes.has_key?("process") then
        $_xml_eval_include_buffer = `#{@attributes["process"]}` 
        $_xml_eval_x = XML.parse_text($_xml_eval_include_buffer)
        $_xml_eval_x.evaluate!(b)
        @child += $_xml_eval_x.child
      elsif @attributes.has_key?("href") then
        $stderr.puts @attributes["href"]
        $_xml_eval_x = XML.parse_link(@attributes["href"])
        $_xml_eval_x.evaluate!(b)
        @child += $_xml_eval_x.child
      end
      
    elsif @tag == "subtemplate" then
      if @attributes.has_key?("key") then
        $_xml_eval_subtemplates[@attributes["key"]] = self.copy
        $_xml_eval_subtemplates[@attributes["key"]].tag = ""
        $_xml_eval_subtemplates[@attributes["key"]].attributes = {}
        $_xml_eval_subtemplate_origins[@attributes["key"]] = self
         if @attributes["key"] == "header" then
          $the_header = self.copy
          $the_header.tag = ""
          $the_header.attributes = {}
          $the_header.evaluate!(b)
        end
        @tag = ""
        @attributes = {}
        @child = []
      end
      
    elsif @tag == "subdo" then
      if @attributes.has_key?("key") then
        temps = $_xml_eval_subtemplates[@attributes["key"]].copy
        temps.evaluate!(b)
        if @attributes.has_key?("origin") then
          $_xml_eval_subtemplate_origins[@attributes["key"]].child << temps
        elsif @attributes.has_key?("location") then
          $_xml_eval_locations[@attributes["location"]].child << temps
        else
          @tag = temps.tag
          @attributes = temps.attributes
          @pcdata = temps.pcdata
          @child = temps.child
          @pos = temps.pos
        end
      end
      
    elsif @tag == "location" then
      if @attributes.has_key?("id") then
        $_xml_eval_locations[@attributes["id"]] = self
        @tag = ""
        @attributes = {}
        @child = []
      end
      
    elsif @tag == "nochange" then
      @child.each do |c|
        begin
          $_xml_eval_y = c
          eval('$_xml_eval_y.pcdata = String.new(%Q^' + c.pcdata.xml2txt + '^)', b)
        rescue
          $stderr.puts "Error occured in <pcdata> (@#{self.pos})
  eval($_xml_eval_y.pcdata = String.new(%Q^#{c.pcdata.xml2txt}^), b)\n#{$!}"
        end
      end
      @tag = (@attributes["type"] || "")
      @attributes = {}
      return  # because we don't wish to change anything below this point
      
    else
      $_xml_eval_y = self
      begin
        eval('$_xml_eval_y.tag = String.new(%Q^' + @tag + '^)', b)
      rescue
        $stderr.puts "Error occured in <tag> (@#{self.pos})::
    eval($_xml_eval_y.tag = String.new(%Q^#{@tag}^, b)\n#{$!}"
      end
      @attributes.each do |key, value|
        $_xml_eval_key = key
        $_xml_eval_value = value
        begin
          eval('$_xml_eval_y.attributes[$_xml_eval_key.to_s] = String.new(%Q^' + $_xml_eval_value.to_s + '^)', b)
        rescue
          $stderr.puts "Error occured in <attributes> (@#{self.pos})::
    eval('$_xml_eval_y.attributes[$_xml_eval_key.to_s] = String.new(%Q^#{$_xml_eval_value.to_s}^), b)'\n#{$!}"
        end
      end
      begin
        eval('$_xml_eval_y.pcdata = String.new(%Q^' + @pcdata.xml2txt + '^).to_xml(false)', b)
      rescue
        $stderr.puts "Error occured in <pcdata> (@#{self.pos})
    eval($_xml_eval_y.pcdata = String.new(%Q^#{@pcdata.xml2txt}^).to_xml(false), b)\n#{$!}"
      end
    end
      
    $_xml_eval_iftests << false
    @child.each do |y|
      y.evaluate!(b)
    end
    $_xml_eval_iftests.pop
    
    # eliminate meta-tags...
    self.each do |y|
        new_children = []
        y.child.each do |z|
          if $_xml_eval_metatags.index(z.tag) then
            new_children += z.child
          else
            new_children << z
          end
        end
        y.child = new_children
      end
  end  # evaluate!


  # Return all the pcdata in this node and all this node's children nodes.
  #     But if a target is specified, collect pcdata only from a direct child node with
  #     the specified (target) tag.
  #
  # @param  target  [String]    tag of children nodes from which we will gather pcdata, 
  #        use all tags if target empty
  # @param  add_whitespace  [Boolean]    add a space for nodes whose tags are not the empty string
  # @return  [String]    the pcdata
  def get_pcdata(target = "", add_whitespace = false)
    return "" if self.tag[0] == "!" || self.tag[0] == "?"
    result = String.new(self.pcdata)
    child.each do |c|
      if target.empty? || c.tag == target then
        result << " " if add_whitespace && !result.empty? && !(" \n\t\f\v".index(result[-1]))
        result << c.get_pcdata("", add_whitespace)
      end
    end
    return result
  end  # get_pcdata
  
  
  TITLE_TAGS = [ ["chapter", "title"], ["section", "title"], ["h1", ""], ["h2", ""], ["h3", ""], ["h4", ""], ["h5", ""], ["h6", ""] ]
  @to_txt_current_title = ""
  
  def to_txt(add_whitespace = false, skip_tags = [], title_tags = TITLE_TAGS)
    result = ""
    return result if @tag[0] == "!" || @tag[0] == "?" || @tag == "script" || skip_tags.index(@tag)
    if (i = title_tags.find_index {|main_tag, sub_tag| @tag == main_tag }) then
      @to_txt_cur_title = get_pcdata(title_tags[i][1]).gsub(/\s+/, " ")
    end
    result << "\n:id:#{@attributes["id"]}:#{@to_txt_cur_title}:\n" if @attributes.has_key?("id")
    result << pcdata
    @child.each do |c|
      result << " " if add_whitespace && !result.empty? && !(" \n\t\f\v".index(result[-1]))
      result << c.to_txt(add_whitespace, skip_tags, title_tags)
    end
    return result
  end  # to_txt


  XML_BLOCK_TAGS = %w( attribution caption glossterm indexterm para 
      seglistitem segtitle simpara subtitle tabname term textobject title ) 
  XML_PRE_TAGS = %w( literallayout programlisting )
  XML_SKIP_TAGS = %w( abstract titleabbrev )

  HTML_BLOCK_TAGS = %w( blockquote caption dt figcaption h1 h2 h3 h4 h5 h6 p ) 
  HTML_PRE_TAGS = %w( pre )
  HTML_SKIP_TAGS = %w( head )

  def to_txt_canonical(give_pos: true, 
        block_tags: XML_BLOCK_TAGS,
        pre_tags: XML_PRE_TAGS,
        skip_tags: XML_SKIP_TAGS)
     result = ""
     return result if @tag[0] == "!" || @tag[0] == "?" || @tag == "script" || skip_tags.index(@tag) 
     result << @pcdata
     @child.each do |c|
       result << c.to_txt_canonical(give_pos: give_pos, block_tags: block_tags, pre_tags: pre_tags, skip_tags: skip_tags)
     end
     if (i = block_tags.find_index(@tag)) then
       result.gsub!(/\s+/, " ")
       result << "\t#{@pos[/\d+/]}" if give_pos && @pos 
       result << "\n"
     elsif (i = pre_tags.find_index(@tag)) then
       result.gsub!(/\t/, "    ")
       result << "\t#{@pos[/\d+/]}" if give_pos && @pos 
       result << "\n"
     elsif result !~ /\S/ then
       result = ""
    end
    return result
  end  # to_txt_canonical


  def to_tags_canonical(give_pos: true, level: 0)
     result = ""
     return result if @tag[0] == "!" || @tag[0] == "?" || @tag == "script"
     result << ("  " * level) + @tag + (give_pos && @pos ? ("\t" + @pos[/\d+/]) : "") + "\n" unless @tag.empty?
     @child.each do |c|
       result << c.to_tags_canonical(give_pos: give_pos, level: level + 1)
     end
    return result
  end  # to_tags_canonical


  def to_lines(context = [], skip_tags = ["!", "?", "script"])
    result = ""
    context << @tag
    temp = String.new(@pcdata)
    temp.delete!("^\n") if skip_tags.any? {|tag| context.find_index(tag) } || (!LITERAL_TAGS.any? {|tag| context.find_index(tag) } && temp !~ /\S/)
    temp.gsub!(/(?<=\n)[ \t\v\f]+|[ \t\v\f]+(?=\n)/, "") unless LITERAL_TAGS.any? {|tag| context.find_index(tag) }
    result << temp
    @child.each do |c|
      result << c.to_lines(context, skip_tags)
    end
    context.pop
    return result
  end  # to_lines
  
  
  def to_tags(level = 0, do_indent = false, literal_tags = LITERAL_TAGS)
    literal = literal_tags.index(@tag)
    tag1 = @tag.empty? ? "" : "<#{@tag}"
    closeit = (@tag[0] == "?" ? "?" : (@tag[0] == "!" ? "" : "/"))
    a = []
    @attributes.each do |key, value| 
      a << "#{key}=\"#{value}\"" 
    end
    attrs = a.join(" ")
    attrs.prepend(" ") unless attrs.empty?
    children = ""
    @child.each {|x| children << x.to_tags(level+1, do_indent && !literal, literal_tags) }
    tag2 = @tag.empty? ? "" : (children.empty? ? "#{closeit}>" : ">")
    close_tag = children.empty? ? "" : (@tag.empty? ? "" : "</#{@tag}>")
    if do_indent then
      indent = (@tag.empty? || children.empty?) ? "" : ("\n" + "  " * level)
      return "#{indent}#{tag1}#{attrs}#{@pcdata.delete("^\n")}#{tag2}#{children.chomp}#{(children.count("\n") > 1 && !literal) ? indent : ""}#{close_tag}"
    else
      return "#{indent}#{tag1}#{attrs}#{@pcdata.delete("^\n")}#{tag2}#{children}#{close_tag}"
    end
  end  # to_tags


  # Return a hash embodying the attributes given in the string.
  #
  # @param  attributes  [String]    the string representing the attributes to be parsed
  # @return  [Hash]    the attributes in Hash form
  def self.parse_attributes(attributes)
    results = {}
    while attributes =~ /([^\s=]+)\s*=\s*(('|")([^\3]*?)(\3)|\S+)/ do
      #~ $stderr.puts "parse_attributes 1[#{$1}]  2[#{$2}] 3[#{$3}] 4[#{$4}]"
      results[$1] = ($4 || $2 )
      attributes = $'
    end
    return results
  end  # parse_attributes
  
  
  # Place XML nodes as children of others based on their indentation level,
  #   then place all the top-most level nodes as children of a new XML node.
  #
  # @param  a  [Array<Array<String, XML>>]    the XML nodes with their indentation levels
  # @return  [XML]    an XML node with the input nodes as children built into a hierarchy 
  #     according to their indentation levels
  def self.build_hierarchy(a)
    buffer = [["", XML.new]]  # array of array of String (indent), XML
    while !a.empty? do
      buffer << a.pop
      while buffer[-2][0].length > buffer[-1][0].length do
        temp = buffer.slice!(-2)
        buffer[-1][1].child << temp[1]
      end
    end
    buffer.unshift  # get rid of dummy at beginning
    result = XML.new
    while x = buffer.shift do
      result.child.unshift x[1]
    end
    return result
  end  # build_hierarchy
  
  
  # Some standard HTML fragments to use when constructing our own HTML file.
  HTML_pre = <<EOS
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content=""/>
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/standard.css"/>
  </head>
  <body id="top">
EOS


  HTML_post = <<EOS
  </body>
</html>
EOS


# Some standard DOCBOOK fragments to use when constructing our own DOCBOOK file.
  DOCBOOK_pre = <<EOS
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE chapter PUBLIC "-//OASIS//DTD DocBook XML V4.5//EN" "file://zonbook/docbookx.dtd"
[
    <!ENTITY % xinclude SYSTEM "file://AWSShared/common/xinclude.mod">
    %xinclude;
    <!ENTITY % phrases-shared SYSTEM "file://AWSShared/common/phrases-shared.ent"> 
    %phrases-shared;           
]>
EOS


  DOCBOOK_post = <<EOS
EOS

$stupid_html_tags = %w( area base br col embed img input link meta param )



  TAG = "<"
  CTAG = ">"
  ATTRIB = "="
  DQUOTE = '"'
  SQUOTE = "'"
  PCD = "d"
  COMMENT = "!--"
  END_COMMENT = "-->"
  CDATA = "![CDATA["
  END_CDATA = "]]>"
  BANG_TAG = "!"
  END_BANG_TAG = ">"
  DTD = "!DOCTYPE"
  INTERNAL_DTD = "["
  END_INTERNAL_DTD = "]>"
  
  $old_ruby = (RUBY_VERSION =~ /^1\.8/ ? true : false)


  # Parse the XML contained in the file.
  # 
  # @param  f  [File]    the file to parse
  # @return  [XML]    a node with all the parsed XML nodes as its children
  # @block  [String]    (optional) action performed at significant junctures in parsing
  def self.parse(f, do_html = false)
    ptr = [XML.new]
    where = PCD
    where_last = PCD
    line = 1; column = 0; start_column = 0
    context = []
    
    buffer = ""
    dashes_in_comment = 0
    
    while c = f.getc do
      if c == "\n" then
        line += 1; column = 1;
      else
        column += 1
      end
      buffer << c
      
      if where == COMMENT then
        if buffer.end_with?(END_COMMENT) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(COMMENT, {}, buffer[(COMMENT.length + 1)..-2])
          where = PCD
          buffer = ""
          start_column = column
          dashes_in_comment = 0
        elsif c == "-" then
          dashes_in_comment += 1
        else
          if dashes_in_comment > 1 then 
            yield(line, start_column, context, 
                "ERROR:#{line}:#{column}: dashes in comment") if defined?(yield)
          end
          dashes_in_comment = 0
        end
        
      elsif where == CDATA then
        if buffer.end_with?(END_CDATA) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(CDATA, {}, buffer[(CDATA.length + 1)..-2])
          where = PCD
          buffer = ""
          start_column = column
        end
        
      elsif where == BANG_TAG then
        if buffer.end_with?(TAG + CDATA) then
          where = CDATA
        elsif buffer.end_with?(TAG + COMMENT) then
          where = COMMENT
        elsif buffer.end_with?(DTD) && !buffer[1..-2].include?(TAG) then
          where = DTD
        elsif buffer.end_with?(END_BANG_TAG) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(BANG_TAG, {}, buffer[(BANG_TAG.length + 1)..(-1 - END_BANG_TAG.length)])
          where = PCD
          buffer = ""
          start_column = column
        end
        
      elsif where == DTD then
        if buffer.end_with?(INTERNAL_DTD) then 
          where_last = where
          where = INTERNAL_DTD
        elsif buffer.end_with?(END_BANG_TAG) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(DTD, {}, buffer[(DTD.length + 1)..(-1 - END_BANG_TAG.length)])
          # $stderr.puts "EXTERNAL DTD: #{ptr.last.child[-1].to_s}"  # debug
          where = PCD
          buffer = ""
          start_column = column
        end 
       
      elsif where == INTERNAL_DTD then
        if buffer.end_with?(END_INTERNAL_DTD) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(DTD, {}, buffer[(DTD.length + 1)..(-1 - (END_INTERNAL_DTD.length - 1))])
          # $stderr.puts "INTERNAL DTD: #{ptr.last.child[-1].to_s}"  # debug
          where = PCD
          buffer = ""
          start_column = column
        end
 
      elsif where == DQUOTE then
        if buffer.end_with?(DQUOTE) then
          where = where_last
        end
        
      elsif where == SQUOTE then
        if buffer.end_with?(SQUOTE) then
          where = where_last
        end
        
      elsif buffer.end_with?(TAG + BANG_TAG) then
        where = BANG_TAG
      
      elsif buffer.end_with?(TAG) then
        if where == PCD && buffer.length > 1 then
          yield(line, start_column, context, buffer[0..(-1 - TAG.length)]) if defined?(yield)
          ptr.last.child << XML.new("", {}, buffer[0..(-1 - TAG.length)])  #  add pcdata
          buffer = ""
          buffer << TAG
          start_column = column - 1
        end
        where = TAG
      
      elsif buffer.end_with?(CTAG) then
        if where == TAG then
          close = (buffer =~ /(\?|\/)\s*>/ ? $1 : nil)
          
          if buffer =~ /<(\?|\/)?([^>\s\/]+)([^>]*)/ then
            typ = $1
            tag = $2
            attr = $3
            if typ == "/" then
              # closing tag, no attributes
              if ptr.last.tag == tag then
                ptr.pop
                context.pop
              else
                while ptr.length > 1 && ptr.last.tag != tag do
                  $stderr.puts "ERROR: mis-matched closing tag: found #{tag} but expecting #{ptr.last.tag} @ #{line}:#{column}"
                  ptr.pop
                  context.pop
                end
                if ptr.length > 1 && ptr.last.tag == tag then
                  ptr.pop
                  context.pop
                end
              end
            else
              attributes = {}
              while attr =~ /(\S+)\s*#{ATTRIB}\s*(#{SQUOTE}|#{DQUOTE})([^\2]*?)\2/ ||
                  attr =~ /(\S+)\s*#{ATTRIB}\s*((\S+))/ do
                key = $1
                value = $3
                attr = $'
                attributes[key] = value
              end
              yield(line, start_column, context, buffer) if defined?(yield)
              ptr.last.child << XML.new((typ || "") + tag, attributes)
              if !close then
                ptr << ptr.last.child.last unless do_html && $stupid_html_tags.find_index(tag)
                context << ((typ || "") + tag) unless do_html && $stupid_html_tags.find_index(tag)
              end
            end
          else
            $stderr.puts "ERROR: invalid tag: found #{buffer} @ #{line}:#{column}"
          end
          
          where = PCD
          buffer = ""
          start_column = column
        else
          $stderr.puts "ERROR: invalid #{CTAG} @ #{line}:#{column}"
        end
        
      end
    end  # while
    
    if where == PCD && buffer.length > 1 then
      yield(line, start_column, context, buffer) if defined?(yield)
      ptr.last.child << XML.new("", {}, buffer)  #  add pcdata
    end
    ptr[1..-1].each {|p| $stderr.puts "ERROR: closing tag not found for: #{p.tag}" } if ptr.length > 1
    return ptr[0]
  end  # parse


  # Parse the XML contained in the file.
  # 
  # @param  f  [File]    the file to look at
  # @block  [Integer, Integer, Array<String>, String]    (optional) action performed at significant junctures in parsing
  # @return  void
  def self.look(f, do_html = false)
    where = PCD
    where_last = PCD
    line = 1; column = 0; start_column = 0
    context = []
    
    buffer = ""
    
    while c = f.getc do
      if c == "\n" then
        line += 1; column = 1;
      else
        column += 1
      end
      buffer << c
      
      if where == COMMENT then
        if buffer.end_with?(END_COMMENT) then
          yield(line, start_column, context, buffer) if defined?(yield)
          where = PCD
          buffer = ""
          start_column = column
        end
        
      elsif where == CDATA then
        if buffer.end_with?(END_CDATA) then
          yield(line, start_column, context, buffer) if defined?(yield)
          where = PCD
          buffer = ""
          start_column = column
        end
        
      elsif where == BANG_TAG then
        if buffer.end_with?(TAG + CDATA) then
          where = CDATA
        elsif buffer.end_with?(TAG + COMMENT) then
          where = COMMENT
        elsif buffer.end_with?(DTD) && !buffer[(start + 1)..(index - 1)].include?(TAG) then
          where = DTD
        elsif buffer.end_with?(END_BANG_TAG) then
          yield(line, start_column, context, buffer) if defined?(yield)
          where = PCD
          buffer = ""
          start_column = column
        end
        
      elsif where == DTD then
        if buffer.end_with?(INTERNAL_DTD) then 
          where_last = where
          where = INTERNAL_DTD
        elsif buffer.end_with?(END_BANG_TAG) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(DTD, {}, buffer[(DTD.length + 1)..(-1 - END_BANG_TAG.length)])
          # $stderr.puts "EXTERNAL DTD: #{ptr.last.child[-1].to_s}"  # debug
          where = PCD
          buffer = ""
          start_column = column
        end 
       
      elsif where == INTERNAL_DTD then
        if buffer.end_with?(END_INTERNAL_DTD) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(DTD, {}, buffer[(DTD.length + 1)..(-1 - (END_INTERNAL_DTD.length - 1))])
          # $stderr.puts "INTERNAL DTD: #{ptr.last.child[-1].to_s}"  # debug
          where = PCD
          buffer = ""
          start_column = column
        end
 
      elsif where == DQUOTE then
        if buffer.end_with?(DQUOTE) then
          where = where_last
        end
        
      elsif where == SQUOTE then
        if buffer.end_with?(SQUOTE) then
          where = where_last
        end
        
      elsif buffer.end_with?(TAG + BANG_TAG) then
        where = BANG_TAG
      
      elsif buffer.end_with?(TAG) then
        if where == PCD && buffer.length > 1 then
          yield(line, start_column, context, buffer[0..(-1 - TAG.length)]) if defined?(yield)
          buffer = ""
          buffer << TAG
          start_column = column - 1
        end
        where = TAG
      
      elsif buffer.end_with?(CTAG) then
        if where == TAG then
          close = (buffer =~ /(\?|\/)\s*>/ ? $1 : nil)
          
          if buffer =~ /<(\?|\/)?([^>\s\/]+)([^>]*)/ then
            typ = $1
            tag = $2
            attr = $3
            if typ == "/" then
              # closing tag, no attributes
              if context.last == tag then
                context.pop
              else
                $stderr.puts "ERROR: mis-matched closing tag: found #{tag} but expecting #{context.last} @ #{line}:#{column}"
              end
            else
              attributes = {}
              while attr =~ /(\S+)\s*#{ATTRIB}\s*(#{SQUOTE}|#{DQUOTE})([^\2]*?)\2/ ||
                  attr =~ /(\S+)\s*#{ATTRIB}\s*((\S+))/ do
                key = $1
                value = $3
                attr = $'
                attributes[key] = value
              end
              yield(line, start_column, context, buffer) if defined?(yield)
              if !close then
                context << ((typ || "") + tag) unless do_html && $stupid_html_tags.find_index(tag)
              end
            end
          else
            $stderr.puts "ERROR: invalid tag: found #{buffer} @ #{line}:#{column}"
          end
          
          where = PCD
          buffer = ""
          start_column = column
        else
          $stderr.puts "ERROR: invalid #{CTAG} @ #{line}:#{column}"
        end
        
      end
    end  # while
    if where == PCD && buffer.length > 1 then
      yield(line, start_column, context, buffer) if defined?(yield)
    end
    context.each {|c| $stderr.puts "ERROR: closing tag not found for: #{c}" } if context.length > 1
  end  # look


  # Parse the XML contained in the file and add source file location info to each node.
  # 
  # @param  f  [File]    the file to parse
  # @block  [Integer, Integer, Array<String>, String]    (optional) action performed at significant junctures in parsing
  # @return  [XML]    a node with all the parsed XML nodes as its children
  def self.parse_p(f, do_html = false)
    ptr = [XML.new]
    where = PCD
    where_last = PCD
    line = 1; start_line = 1
    column = 0; start_column = 1
    context = []
    
    buffer = ""
    dashes_in_comment = 0
    
    while c = f.getc do
      if c == "\n" then
        line += 1; column = 0;
      else
        column += 1
      end
      buffer << c
      
      if where == COMMENT then
        if buffer.end_with?(END_COMMENT) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(COMMENT, {}, buffer[(COMMENT.length + 1)..-2])
          ptr.last.child.last.pos = "#{start_line}:#{start_column}"
          where = PCD
          buffer = ""
          start_column = column + 1
          start_line = line
          dashes_in_comment = 0
        elsif c == "-" then
          dashes_in_comment += 1
        else
          if dashes_in_comment > 1 then 
            yield(line, start_column, context, 
                "ERROR:#{line}:#{column}: dashes in comment") if defined?(yield)
          end
          dashes_in_comment = 0
        end
        
      elsif where == CDATA then
        if buffer.end_with?(END_CDATA) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(CDATA, {}, buffer[(CDATA.length + 1)..-2])
          ptr.last.child.last.pos = "#{start_line}:#{start_column}"
          where = PCD
          buffer = ""
          start_column = column + 1
          start_line = line
        end
        
      elsif where == BANG_TAG then
        if buffer.end_with?(TAG + CDATA) then
          where = CDATA
        elsif buffer.end_with?(TAG + COMMENT) then
          where = COMMENT
        elsif buffer.end_with?(DTD) && !buffer[1..-2].include?(TAG) then
          where = DTD
        elsif buffer.end_with?(END_BANG_TAG) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(BANG_TAG, {}, buffer[(BANG_TAG.length + 1)..(-1 - END_BANG_TAG.length)])
          ptr.last.child.last.pos = "#{start_line}:#{start_column}"
          where = PCD
          buffer = ""
          start_column = column + 1
          start_line = line
        end
        
      elsif where == DTD then
        if buffer.end_with?(INTERNAL_DTD) then 
          where_last = where
          where = INTERNAL_DTD
        elsif buffer.end_with?(END_BANG_TAG) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(DTD, {}, buffer[(DTD.length + 1)..(-1 - END_BANG_TAG.length)])
          ptr.last.child.last.pos = "#{start_line}:#{start_column}"
          # $stderr.puts "EXTERNAL DTD: #{ptr.last.child[-1].to_s}"  # debug
          where = PCD
          buffer = ""
          start_column = column + 1
          start_line = line
        end 
       
      elsif where == INTERNAL_DTD then
        if buffer.end_with?(END_INTERNAL_DTD) then
          yield(line, start_column, context, buffer) if defined?(yield)
          ptr.last.child << XML.new(DTD, {}, buffer[(DTD.length + 1)..(-1 - (END_INTERNAL_DTD.length - 1))])
          ptr.last.child.last.pos = "#{start_line}:#{start_column}"
          # $stderr.puts "INTERNAL DTD: #{ptr.last.child[-1].to_s}"  # debug
          where = PCD
          buffer = ""
          start_column = column + 1
          start_line = line
        end
 
      elsif where == DQUOTE then
        if buffer.end_with?(DQUOTE) then
          where = where_last
        end
        
      elsif where == SQUOTE then
        if buffer.end_with?(SQUOTE) then
          where = where_last
        end
        
      elsif buffer.end_with?(TAG + BANG_TAG) then
        where = BANG_TAG
      
      elsif buffer.end_with?(TAG) then
        if where == PCD && buffer.length > 1 then
          yield(line, start_column, context, buffer[0..(-1 - TAG.length)]) if defined?(yield)
          ptr.last.child << XML.new("", {}, buffer[0..(-1 - TAG.length)])  #  add pcdata
          # buffer[0..(-1 - TAG.length)].scan(/&\W|</) {|str|
          begin
          buffer[0..(-1 - TAG.length)].scan(/&[^#\w]|</) {|str|
            yield(line, start_column, context, "ERROR:#{line}:#{start_column}: invalid #{str[0]}") if defined?(yield)
          }
          rescue
            $stderr.puts "***#{line}[#{buffer}]"  # debug
          end
          ptr.last.child.last.pos = "#{start_line}:#{start_column}"
          buffer = ""
          buffer << TAG
          start_column = column
          start_line = line
        end
        where = TAG
      
      elsif buffer.end_with?(CTAG) then
        if where == TAG then
          close = (buffer =~ /(\?|\/)\s*>/ ? $1 : nil)
          
          if buffer =~ /<(\?|\/)?([^>\s\/]+)([^>]*)/ then
            typ = $1
            tag = $2
            attr = $3
            if typ == "/" then
              # closing tag, no attributes
              if ptr.last.tag == tag then
                ptr.pop
                context.pop
              else
                while ptr.length > 1 && ptr.last.tag != tag do
                  yield(line, start_column, context, 
                      "ERROR:#{start_line}:#{start_column}: mis-matched closing tag: found #{tag} but expecting #{ptr.last.tag}") if defined?(yield)
                  ptr.pop
                  context.pop
                end
                if ptr.length > 1 && ptr.last.tag == tag then
                  ptr.pop
                  context.pop
                end
              end
            else
              attributes = {}
              while attr =~ /(\S+)\s*#{ATTRIB}\s*(#{SQUOTE}|#{DQUOTE})([^\2]*?)\2/ ||
                  attr =~ /(\S+)\s*#{ATTRIB}\s*((\S+))/ do
                key = $1
                value = $3
                attr = $'
                attributes[key] = value
              end
              yield(line, start_column, context, buffer) if defined?(yield)
              ptr.last.child << XML.new((typ || "") + tag, attributes)
              ptr.last.child.last.pos = "#{start_line}:#{start_column}"
              if !close then
                ptr << ptr.last.child.last unless do_html && $stupid_html_tags.find_index(tag)
                if tag == "chapter" || tag == "section" then
                  context << ((typ || "") + tag + ",#{attributes.to_a.join(",")}") unless do_html && $stupid_html_tags.find_index(tag)
                else
                  context << ((typ || "") + tag) unless do_html && $stupid_html_tags.find_index(tag)
                end
              end
            end
          else
            yield(line, start_column, context, "ERROR:#{start_line}:#{start_column}: invalid tag: found #{buffer}") if defined?(yield)
          end
          
          where = PCD
          buffer = ""
          start_column = column + 1
          start_line = line
        else
          yield(line, start_column, context, "ERROR:#{start_line}:#{start_column}: invalid #{CTAG}") if defined?(yield)
        end
        
      end
    end  # while
    if where == PCD && buffer.length > 1 then
      yield(line, start_column, context, buffer) if defined?(yield)
      ptr.last.child << XML.new("", {}, buffer)  #  add pcdata
      ptr.last.child.last.pos = "#{start_line}:#{start_column}"
    end
    ptr[1..-1].each do |p| 
      yield(line, start_column, context, "ERROR:#{p.pos}: closing tag not found for: #{p.tag}") if defined?(yield)
    end if ptr.length > 1
    return ptr[0]
  end  # parse_p


  def self.parse_link(link, rel_path = "")
    result = XML.new
    message = ""
    
    if link =~ /^([^:\/]*:(?:\/\/)*)*([^\/]+)(.*)/ then
      protocol = $1 || ""
      domain = $2 || ""
      path = $3 || ""
       if path.empty? then
        path = domain
        domain = ""
      end
      #~ $stderr.puts "protocol=#{protocol}, domain=#{domain}, path=#{path}"  # debug
      
      # "mailto:" is a valid protocol, but not one we can follow...
      if protocol =~ /^mailto:/ then
        $stderr.puts "ERROR: can't parse protocol 'mailto:'"
        return result
      end
      
      # if protocol is empty, is it a local file, perhaps?
      if protocol.empty? then
        fn = File.expand_path((domain + path)[/[^\#]+/], rel_path)
        if File.exist?(fn) then
          File.open(fn, "r:UTF-8") {|input| result = XML.parse(input, (fn =~ /\.html?$/)) }
          return result
        end
      end
      
      # o/w if not "http:" and not empty, then it is an invalid protocol, don't bother trying...
      unless protocol.empty? || protocol.downcase.include?("http") then
        $stderr.puts "ERROR: invalid protocol '#{protocol}'"
        return result
      end
      
      begin
        response = Net::HTTP.get_response(domain, path)
        case response.code
          when /^1/ then
            $stderr.puts   "ERROR: link responds-- (informational) #{response.code}::#{response.message}"
          when /^2/ then
            #~ $stderr.puts  "Success : #{response.code}::#{response.message}"
            result = parse(StringIO.new(response.body), true)
          when /^3/ then
            $stderr.puts  "ERROR: link responds-- (redirection) #{response.code}::#{response.message}->#{response.location}"
            
          when /^4/ then
            $stderr.puts  "ERROR: link responds-- (client error) #{response.code}::#{response.message}"
          when /^5/ then
            $stderr.puts  "ERROR: link responds-- (server error) #{response.code}::#{response.message}"
          else
            $stderr.puts  "ERROR: link responds-- (unknown error) #{response.code}::#{response.message}"
          end
      rescue
        $stderr.puts "ERROR: invalid domain/path or file not found-- '#{domain}#{path}'"
      end
    else
      $stderr.puts "ERROR: '#{link}' not a valid link"
    end
    
    return result
  end  # parse_link
  
  
  def self.parse_text(str, do_html = false)
    return parse(StringIO.new(str), do_html)
  end  # parse_text

  
  # Validate that this XML node has the correct children and attributes.
  # 
  # @param  elements  [Array<Validator>]  containing info on valid/required children and attributes
  # @param  verbose  [Boolean]  if true, give details of children found and expected
  # @return  [Array<String>]  details of any violations found, including position in source file
  def validate(elements:, verbose: false, xi: false, suggest: false, ignore: [], do_json: false, strict: false)
    results = []
    if self.tag.empty? || ignore.include?(self.tag) then
      # move along, nothing to see here...
    elsif i = elements.index {|dtd| self.tag == dtd.name } then
      e = elements[i]
      pcd_is_entity = false
      # test for having pcdata when it should not...
      pcd = ""
      self.child.each {|c| pcd << c.pcdata.strip if c.tag.empty? }
      pcd_is_entity = (pcd =~ /^&[-._\w]+;$/)  # true if pcdata consists solely of an entity (after whitespace discarded)
      if !e.mixed && !pcd.empty? && !pcd_is_entity then
        results << "#{self.pos}: pcdata not allowed in '#{self.tag}' element"
      end
      # test for valid child elements...
      if xi then
        children = self.child.inject("") {|n, c| n << ((c.tag[0] == "!" || c.tag[0] == "?") ? "" : c.tag) }
      else
        children = self.child.inject("") {|n, c| n << ((c.tag[0] == "!" || c.tag[0] == "?" || c.tag[0..2] == "xi:") ? "" : c.tag) }
      end
      if children !~ e.childREn then
        if children.empty? && pcd_is_entity then
          # assume the entity will contain the required children
        else
          results << "#{self.pos}: invalid children for '#{self.tag}' element"
          results << "  (#{e.childREn.source})\n[#{children}]" if verbose
        end
      end
      # test for valid attributes...
      self.attributes.each do |key, value|
        if e.attributes[key] && are = e.attributes[key][0] then
          if value !~ are then
            results << "#{self.pos}: invalid value '#{value}' for attribute '#{key}' in '#{self.tag}' element"
          end
        else
          results << "#{self.pos}: invalid attribute '#{key}' in '#{self.tag}' element"
        end
      end
      # test for required attributes...
      e.attributes.each do |key, value|
        if value[1] =~ /#REQUIRED/i then
          if !self.attributes.has_key?(key) then
            results << "#{self.pos}: '#{self.tag}' element does not have required attribute '#{key}'"
          end
        end
      end
      # test for a recommendation to pass to user...
      if suggest && e.recommend then
        results << "#{self.pos}: '#{self.tag}' element #{e.recommend}"
      end
      if do_json then
          if self.tag == "programlisting" then
            #if self.attributes.has_key?("language") && self.attributes["language"] =~ /json/i then
            if self.attributes["language"] =~ /json/i && self.attributes["condition"] != "unchecked" then
              pcd = self.get_pcdata
              unless strict then
                pcd.gsub!(/\A *\$.*\n/, "")  # rm commands: $ yada ...
                pcd.gsub!(/(^|\s)\.\.\.(\s|$)/, "")  # rm ellipsis: <sp>...<sp> 
                #pcd.gsub!(/([^"])&lt;([^&]+)&gt;([^"])/) {|str| "#{$1}\"#{$2}\"#{$3}" }  # &lt; ... &gt; enclose in quotes
                #pcd.gsub!(/([^"]|^)(boolean|integer|long|number|timestamp)([^"]|$)/i) {|str| "#{$1}\"#{$2}\"#{$3}"} # enclose in quotes
              end
              j = pcd.json_parse(strict: false) do |line, column, r, msg|
                if msg[0..5] == "ERROR:" then
                  results << "#{self.pos}: '#{self.tag}' contains invalid JSON (#{msg[6..-1]})"
                end
              end
            end
          end
      end
      
    else
      results << "#{self.pos}: invalid element '#{self.tag}'"
    end
    return results
  end  # validate
  
  
  def remove(tags = ["?"])
    new_children = []
    prev_child = nil
    self.child.each_index do |i|
      if (self.child[i].tag[0] == "?" && tags.index("?")) || (tags.index(self.child[i].tag)) then
        if prev_child && prev_child.tag.empty? && self.child[i].child[0] && self.child[i].child[0].tag.empty? then
          prev_child.pcdata << self.child[i].child[0].pcdata
          new_children += self.child[i].child[1..-1] if self.child[i].child.length > 1
        else
          new_children += self.child[i].child
        end
      else
        if prev_child && prev_child.tag.empty? && self.child[i].tag.empty? then
          prev_child.pcdata << self.child[i].pcdata
        else
          new_children << self.child[i]
        end
      end
      prev_child = new_children.last
    end
    self.child = new_children
    self.child.each {|c| c.remove(tags) }
  end  #remove
  
  
  def get_links(type = /\.html(\?|#|$)/i, att = "href")
    results = []
    return results if tag[0] == "!" || tag[0] == "?" || tag == "script"
    if attributes.has_key?(att) && attributes[att] =~ type then
      results << attributes[att]
    end
    child.each do |c|
      results += c.get_links(type, att)
    end
    return results
  end  # get_links
  
  
  ################################
  # parse lazy formatted text into real XML...
  ################################
  
  DELIMITERS = %w( ! # $ % & * + - / : ; = ? @ ^ ` ~ )
  HTML_TAGS = %w( abbr acronym address addthis applet area article aside audio a 
      basefont base bdi bdo big blockquote body br button b
      canvas caption center cite code colgroup col
      datalist dd del details dfn dialog dir div dl dothis dt
      each else elsif embed em expandomatic fieldset figcaption figure font footer form frameset frame
      h1 h2 h3 h4 h5 h6 header head hr html 
      iframe if img input ins i kbd keygen label legend link li location
      main map mark menuitem menu meta meter nav nochange noframes noscript
      object ol optgroup option output param pre progress p q rp rt ruby 
      samp script section select small source span strike strong style subdo subtemplate sub summary sup s
      table tbody td textarea tfoot thead th time title track tr tt
      ul u var video wbr )
      
  HTML_LITERAL_TAGS = %w( pre )
  DOCBOOK_LITERAL_TAGS = %w( code programlisting )
  LITERAL_TAGS = %w( code pre programlisting )
  
  HTML_TABLE_TAGS = { "table" => "table", "thead" => "thead", "tbody" => "tbody", "tfoot" => "tfoot", 
      "tr" =>  "tr", "th" => "th", "td" => "td", "p" => "p" } 
  DOCBOOK_TABLE_TAGS = { "table" => "table", "thead" => "thead", "tbody" => "tbody", "tfoot" => "tfoot", 
      "tr" => "row", "th" => "entry", "td" => "entry", "p" => "para", "tgroup" => "tgroup",  } 
      
  HTML_IMG_TAGS = [ "", "figure", "img", "figcaption" ]
  DOCBOOK_IMG_TAGS = [ "mediaobject", "imageobject", "imagedata", "" ]  #, "caption" ]
  
  HTML_PARA_TAGS = [ ]
  DOCBOOK_PARA_TAGS = [ "step" ]  # "listitem", 
      
  DOCBOOK_TAGS = %w( abstract acronym action addthis alt anchor answer appendix areaspec area arg authorinitials author
      blockquote bookinfo book bridgehead
      calloutlist callout caption caution chapterinfo chapter citation citetitle classname code collapsible colspec command computeroutput contractnum copyright coref corpauthor co
      date dothis each edition else elsif email emphasis entrytbl entry envar errorname example expandomatic figure filename firstterm formalpara function
      glossary glossdef glossdiv glossentry glossseealso glosssee glossterm graphic group guibutton guiicon guilabel guimenu
      highlights holder if imagedata imageobjectco imageobject img important indexterm index informalexample informalfigure informaltable info inlineequation inlinegraphic inlinemediaobject itemizedlist
      keycap keywordset keyword legalnotice link listitem literallayout literal location mediaobjectco mediaobject member methodname
      nochange note option orderedlist package parameter para phrase primary procedure productname programlisting property pubdate publisher
      qandaentry qandaset question remark replaceable revdescription revhistory revision revnumber revremark row
      secondary sectioninfor section seealso see seglistitem segmentedlist segtitle seg simpara simplelist simplesect spanspec state step subdo substeps subtemplate subtitle superscript
      tabcontent table tablistentry tablist tabname task tbody term tertiary textobject tgroup thead tip titleabbrev title tocchap tocentry toclevel1 toclevel2 toc token type
      ulink uri userinput variablelist varlistentry varname videodata videoobject warning
      xi:fallback xi:include xref year 
      )
  
  
  def self.parse_pcdata(pcdata, delimiters = DELIMITERS, tags = DOCBOOK_TAGS)
    #~ $stderr.puts "parse_pcdata(#{pcdata})"
    results = [XML.new]
    while pcdata =~ /([#{delimiters.join}])(#{tags.join("|")})(\([^)]*\))?(\1)/ do
    #~ while pcdata =~ /([#{delimiters.join}])(#{tags.join("|")})(\([^)]*\))?([#{delimiters.join}])/ do
      dlim1 = $1
      tag = $2
      attrs = $3
      dlim2 = $4
      remainder = $'
      results.last.pcdata << $`.to_xml  # before match
      p = remainder.partition(dlim2)
      if !p[1].empty? then
        #~ $stderr.puts "true: dlim1=#{dlim1}, tag=#{tag}, attrs=#{attrs}, dlim2=#{dlim2} p[#{p.join(",")}]"
        results.pop if results.last.pcdata.empty?  # no need to keep it
        x = XML.new("", {}, p[0].to_xml)  # pcdata goes in a blank tag XML...
        results << XML.new(tag, (attrs ? parse_attributes(attrs[1..-2]) : {}), "", [x])  # ... inside the found tag
        results << XML.new  # ready for the next bit
        pcdata = p[2]
      else
        # false alarm, no tag here...
        #~ $stderr.puts "false: dlim1=#{dlim1}, tag=#{tag}, attrs=#{attrs}, dlim2=#{dlim2} p[#{p.join(",")}]"
        results.last.pcdata << (dlim1 + tag + dlim2).to_xml
        pcdata = remainder
      end
    end
    results.last.pcdata << pcdata.to_xml  # what's left
    return results
  end  # parse_pcdata
  
  
  def self.process_previous_pcdata(results, pcdata, delimiters: DELIMITERS, tags: DOCBOOK_TAGS, table_tags: DOCBOOK_TABLE_TAGS,
        img_tags: DOCBOOK_IMG_TAGS, para_tags: DOCBOOK_PARA_TAGS, is_literal: false)
    #~ $stderr.puts "process_previous_pcdata(#{results.last.last.tag}, #{pcdata.chomp})"
    case results.last.last.tag 
      
      when "ruby" then
        this_indent = results.last.first
        results.pop
        eval(pcdata)
        r = $stdout.string
        unless r.empty? then
          x = parse_lazy_text(StringIO.new(r), delimiters: delimiters, tags: tags) 
          x.child.each {|c| results << [this_indent, c] }
        end
      
      when "if", "elsif", "else", "each"
        #~ $stderr.puts "#{results.last.last.tag}{#{results.last.last.attributes}}[#{pcdata}]"
        results.last.last.child = parse_pcdata(pcdata, delimiters, tags)
      
      when table_tags["table"]
        if pcdata =~ /^(\s*)([#{delimiters.join}]+)\s/ then
          base_indent = results.last.first
          titlestuff = ""
          tfoot = XML.new(table_tags["tfoot"], {}, "")
          tbody = XML.new(table_tags["tbody"], {}, "")
          thead = XML.new(table_tags["thead"], {}, "")
          column_count = 0
          prev_indent = ""
          pcdata.lines.each do |row|
            next unless row =~ /\S/
            if row =~ /^(\s*)(#\{(.+)\}\s+)?([#{delimiters.join}]+)\s/ then
              indent = $1
              new_cmd = $3
              dlim = $4
              actual_row = dlim + $'
              typ = dlim.length % 3
              where = [tfoot, tbody, thead][typ]
              here = XML.new(table_tags["tr"], {}, "")
              
              new_xmls = parse_lazy_text(StringIO.new(new_cmd), delimiters: delimiters, tags: tags, 
                  table_tags: table_tags, para_tags: para_tags) if new_cmd
              new_xml = new_xmls.child.detect {|obj| !obj.tag.empty? } if new_xmls && new_xmls.child.length > 0
              if new_xml then
                where.child << new_xml
                new_xml.child << here
              else
                where.child << here
              end
              
              cols = actual_row.split(dlim)
              column_count = (column_count < cols.length ? cols.length : column_count)
              cols.each_index do |index|  # first entry will be leading whitespace
                next if index == 0 && cols[index] !~ /\S/
                here.child << XML.new(table_tags[(typ == 1 ? "td" : "th")], {}, "")
                here.child.last.child << XML.new(table_tags["p"], {}, "")
                here.child.last.child.last.child = parse_pcdata(cols[index].strip, delimiters, tags)  #<< XML.new("", {}, entry.strip)
              end
            else
              titlestuff << row.strip
            end
          end
          if table_tags.has_key?("tgroup") then
            results.last.last.child << XML.new("title", {}, "", [XML.new("", {}, titlestuff)])
            results.last.last.child << XML.new("tgroup", {"cols" => (column_count - 1).to_s})
            (column_count - 1).times do |i| 
              results.last.last.child.last.child << XML.new("colspec", {"colname" => "c#{i+1}", "colnum" => (i+1).to_s, "colwidth" => "1.0*"})
            end
            results.last.last.child.last.child << thead unless thead.child.empty?
            results.last.last.child.last.child << tbody unless tbody.child.empty?
            results.last.last.child.last.child << tfoot unless tfoot.child.empty?
          else
            results.last.last.child << XML.new("caption", {}, "", [XML.new("", {}, titlestuff)]) unless titlestuff.empty?
            results.last.last.child << thead unless thead.child.empty?
            results.last.last.child << tbody unless tbody.child.empty?
            results.last.last.child << tfoot unless tfoot.child.empty?
          end
        else
          results.last.last.child = parse_pcdata(pcdata, delimiters, tags)
        end
        
      when "img"
        temp_ptr = nil
        temp_attrs = {}
        img_tags[0..-2].each do |tag_name|
          if  !tag_name.empty? then
            if temp_ptr then
              temp_ptr.child << XML.new(tag_name, {}, "")
              temp_ptr = temp_ptr.child.last
            else
              results.last.last.tag = tag_name
              temp_ptr = results.last.last
              temp_attrs, results.last.last.attributes = results.last.last.attributes, temp_attrs  # swap
            end
          end
        end
        # last entry in image tags is the caption which will collect the pcdata...
        results.last.last.child << XML.new(img_tags.last, {}, "", parse_pcdata(pcdata, delimiters, tags)) unless img_tags.last.empty?
        temp_ptr.attributes = temp_attrs
    
    else
      if is_literal then
        results.last.last.child << XML.new("", {}, pcdata)
      elsif para_tags.index(results.last.last.tag) then
        results.last.last.child << XML.new(table_tags["p"])
        results.last.last.child.last.child = parse_pcdata(pcdata, delimiters, tags) 
      else
        results.last.last.child = parse_pcdata(pcdata, delimiters, tags)
      end
    end
  end  # process_previous_pcdata
  

  # Public: read some text in lazy XML format and convert it to XML
  #    note: Class method
  #
  #   f                  - the file from which to read the text (default $stdin)
  #   delimiters - punctuation used in lazy XML format (default XML::DELIMITERS)
  #                            array of String, each containing one character
  #   tags            - tags used in the type of XML you are converting to
  #                             array of String
  #
  #    Returns an XML with its hierarchy (children)
  #
  def self.parse_lazy_text(f = $stdin, delimiters: DELIMITERS, tags: DOCBOOK_TAGS, table_tags: DOCBOOK_TABLE_TAGS, 
        para_tags: DOCBOOK_PARA_TAGS)
    results = [["", XML.new]]  # array of array of String (indent), XML
    in_literal = false
    pcdata = ""
    $what_she_wrote = StringIO.new("")
    save_stdout = $stdout
    $stdout = $what_she_wrote
    
    while line = f.gets do
      if in_literal then
        if line =~ /(^|[^\\])`\s*$/ then  #/^\s*\`\s*$/ then
          line = $`
          # but first, process pcdata for previous tag...
          process_previous_pcdata(results, pcdata, delimiters: delimiters, tags: tags, table_tags: table_tags, para_tags: para_tags, is_literal: true)
          results << [String.new(results.last.first), XML.new]
          pcdata = ""
          in_literal = false
          redo
        else
          pcdata << line
        end
        
      else
        if line =~ /^\s*##/ then
          # comment line, ignore!
        elsif line =~ /^(\s*)(:- )(.*)$/ then
          # but first, process pcdata for previous tag...
          indent = $1
          remainder = $3
          process_previous_pcdata(results, pcdata, delimiters: delimiters, tags: tags, table_tags: table_tags, para_tags: para_tags)
          pcdata = remainder
          x = XML.new #("", {}, remainder)
          results << [indent, x]
        elsif line =~ /^(\s*)([#{delimiters.join}])(#{tags.join("|")}|#\{.+\})(\([^)]*\)|\s|$)/ then
          # but first, process pcdata for previous tag...
          process_previous_pcdata(results, pcdata, delimiters: delimiters, tags: tags, table_tags: table_tags, para_tags: para_tags)
          pcdata = ""
          
          extra_indent = ""
          while line =~ /^(\s*)([#{delimiters.join}])(#{tags.join("|")}|#\{.+\})(\(([^)]*)\)|\s|$)/ do
            # new tag...
            indent = $1
            dlim = $2
            tag = $3
            attrs = $5 || ""
            remainder = $'
            
            # does a literal start here?...
            if remainder =~ /(^|[^\\])`\s*$/ then
              in_literal = true
              remainder = $`
            else
              in_literal = false
            end
          
            # are there attributes which are not in parentheses?...
            while remainder =~ /^\s*([^\s=]+\s*=\s*(("|')[^\3]+?\3|\S+))/ do
              attrs << (" " + $1)
              remainder = $'
            end if attrs.empty?
            
            if remainder =~ /\s+([#{delimiters.join}])(#{tags.join("|")}|#\{.+\})(\([^)]*\)([^#{delimiters.join}]|$)|\s|$)/ then
              pcdata << $`
              line = (indent + "  " + $& + $')
              #~ $stderr.puts "line[#{line.chomp}]"
            else
              pcdata << remainder.lstrip
              pcdata << "\n" if pcdata.empty?
              line = ""
              #~ $stderr.puts "pcdata[#{pcdata.rstrip}]"
            end

            x = XML.new(tag, (attrs ? parse_attributes(attrs) : {}), "")
            results << [indent + extra_indent, x]
            extra_indent += "  "
          end  
          
        elsif line =~ /^\s*$/ then
          # blank line, ignore!
        else
          # no tag specified at beginning of line, add it to the pcdata...
          pcdata << line
        end
      end
    end
    
    process_previous_pcdata(results, pcdata, delimiters: delimiters, tags: tags, table_tags: table_tags, para_tags: para_tags)
    $stdout = save_stdout
    return build_hierarchy(results)
  end  # parse_lazy_text


  DOCBOOK_INLINE_TAGS = %w( abbrev accel acronym alt code constant email emphasis errorcode errorname errortext errortype footnote 
      guibutton guiicon guilabel guimenu guimenuitem guisubmenu keycap keycode keycombo keysym literal markup menchoice mousebutton 
      phrase quote shortcut subscript superscript symbol tag token trademark )

  def space_out!(tags = DOCBOOK_INLINE_TAGS)
    self.each do |y|
      if !y.child.empty? && tags.index(y.tag)  then
        #~ $stderr.puts "before:#{y.tag}[#{y}]"
        blank = true
        y.each do |z| 
          if z.tag.empty? && z.pcdata =~ /\S/ then
            blank = false
            break
          end
        end
        #~ if && y.child.all? {|z| z.tag.empty? && z.pcdata !~ /\S/ } then
        if blank then
          #~ y.child.each {|z| $stderr.puts "    :#{z.tag}[#{z.pcdata}]" }
          y.tag = ""
          y.child.each {|z| y.pcdata << z.pcdata }
          y.child.clear
          y.attributes.clear
          #~ $stderr.puts "after[#{y}]"
        end
      end
    end
  end # space_out!
  
  
  SKIPSre = /^(!|xi:)/
  
  def parse_definitions()
    stuff = {}
    
    #$stderr.puts "Names:"
    self.child.each do |y|
      if y.tag = "definition" then
        assembly = y.attributes["assembly"] || ""
        y.child.each do |z|
          next if z.tag =~ SKIPSre
          name = z.attributes["name"]
          if name then
            stuff[z.tag] = {} unless stuff.has_key?(z.tag)
            temp = {}
            temp["assembly"] = assembly if assembly
            stuff[z.tag][assembly + (assembly.empty? ? "" : "#") + name] = temp
            z.child.each do |c|
              next if c.tag.empty? || c.tag =~ SKIPSre
              temp[c.tag] = [] unless temp.has_key?(c.tag)
              temp[c.tag] << {}.merge(c.attributes)
            end
          end
        end
      end
    end
    
    $stderr.puts ">>> compiling targets..."
    self.child.each do |y|
      if y.tag = "definition" then
        my_assembly = y.attributes["assembly"] || ""
        y.child.each do |z|
          next if z.tag =~ SKIPSre
          target = z.attributes["target"]
          if target then
            assembly = target.slice!(/^[^#]*#/)
            target_names = target.split("$")
            #~ $stderr.puts "    ?#{my_assembly}? #{assembly}::[#{target_names.join(", ")}]::#{z.to_s}"
            what = stuff
            target_names.each do |n|
              if what.respond_to?(:each_pair) then
                f = nil
                what.each_pair do |key, value|
                  if value.respond_to?(:each_pair) then
                    nn = "#{(assembly && !assembly.empty?) ? (assembly + n) : (my_assembly + "#" + n)}"
                    if value.has_key?(nn) then 
                      f = value[nn]  
                      break
                    elsif value.has_key?(n) then
                      f = value[n]  
                      break
                    end
                  elsif value.respond_to?(:each) then
                    value.each do |a|
                      if a.respond_to?(:each_pair) then
                        a.each_pair do |k, v|
                          if v == n then
                            f = a 
                            break
                          end
                        end
                      end
                    end
                  end
                end
                what = f
              else
                  $stderr.puts "  lost thread at #{n} in #{assembly}[#{target_names.join(",")}]"
                  what = nil
                  break
              end
            end
            
            if what then
              if z.child.empty? then
                #~ $stderr.puts "found what=#{what}"
                # add it as an attribute...
                what[z.tag] = true
              elsif z.tag == "documentation" then
                $stderr.puts "  \"#{target}\" is a duplicate" if what.has_key?(z.tag)
                what[z.tag] = XML.new("", {}, "", z.child).to_s.strip
              else
                #~ $stderr.puts "found what=#{what}"
                # add it as a hash...
                temp = {}
                what[z.tag] = temp
                z.child.each do |c|
                  next if c.tag.empty? || c.tag =~ SKIPSre
                  temp[c.tag] = [] unless temp.has_key?(c.tag)
                  temp[c.tag] << {}.merge(c.attributes)
                end
              end
            else
              $stderr.puts "  \"#{target}\" not found#{z.tag == "documentation" ? ", check documentation" : ""}"
            end
          end
        end
      end
    end
      
    return stuff
  end  # parse_definitions

end  # XML


# A Validator class element corresponds to an XML node. Each Validator shows allowed and required children 
#   and attributes, etc. for an XML node with the same name.
#
# @member  name  [String]    corresponding to the XML tag/name
# @member  attributes  [Hash<key=String, value=Regexp]    gives valid attribute names and their possible values
# @member  childREn  [Regexp]    gives valid/required child element names
# @member  type  [String]    for future expansion...
# @member  mixed  [Boolean]    true if XML node can have PCDATA (currently, PCDATA with non-whitespace)
# @member  recommend  [String]    text to be shown in validation output if this tag is encountered in XML source
#---
# It is expected that other classes will inherit from this one and provide functions to parse validator data and build
#   a "validator engine" i.e. an Array of Validator elements
class Validator
  
  attr_accessor :name
  attr_accessor :attributes
  attr_accessor :childREn
  attr_accessor :type
  attr_accessor :mixed
  attr_accessor :recommend
  
  def initialize(name = "", attributes = {}, childREn = "", type = "", mixed = false)
    @name = name
    @attributes = attributes
    @childREn = childREn
    @type = type
    @mixed = mixed
    @recommend = nil
  end  

  def to_s()
    return "name: #{@name}; attrs: #{@attributes}; childREn: #{@childREn} type: #{@type}; "
  end  # to_s

end  # Validator



  HTML_STRUCT_TAGS = { "variablelist" => "dl", "varlistentry" => "", "term" => "dt", 
      "listitem" => "dd", "para" => "p",  "itemizedlist" => "ul", "orderedlist" => "ol", "li" => "li" }
  DOCBOOK_STRUCT_TAGS = { "variablelist" => "variablelist", "varlistentry" => "varlistentry", "term" => "term", 
      "listitem" => "listitem", "para" => "para",  "itemizedlist" => "itemizedlist", "orderedlist" => "orderedlist", 
      "li" => "listitem", "title" => "title" }


  def struct_to_xml_old(what, parent = what, tags: DOCBOOK_STRUCT_TAGS, follow_link: true, level: 0)
    results = []
    
    if what.respond_to?(:each_pair) then
      
      # 1st pass: simple values...
      what.each_pair do |key, value|
        if $descriptors.index(key.to_s) then
          the_term = ""
        else
          the_term = key.to_s + ": "
        end
        if key != "$ref" && !$promotions.index(key.to_s) && !value.respond_to?(:each) then
          if $promotions.index(key.to_s) && value.respond_to?(:chars) then
            #~ $stderr.puts "skipping #{key}:#{value} because it should have been promoted."
            next
          end
          results << XML.new(tags["para"], {}, "", [XML.new("", {}, the_term + value.to_s)])
        elsif !value.respond_to?(:each_pair) && value.respond_to?(:each) && value.all? {|obj| obj.respond_to?(:chars) } then
          results << XML.new(tags["para"], {}, "", [XML.new("", {}, the_term + value.join("|"))])
        end
      end
      
      # 2nd pass: complex values...
      what.each_pair do |key, value|
        da_link = ""
        if key == "$ref" then
          da_link << value.sub('#/', '').sub('/', '-').downcase
          newh = parent.at(value)
          key = newh.keys[0]
          value = newh[key]
        end
        if !follow_link && value.respond_to?(:each_pair) && !da_link.empty? then
          new_para = XML.new(tags["para"]) 
          results << new_para
          the_term = key.to_s + ": "
          $promotions.each do |t|
            if (new_term = value.fetch(t, nil)) && new_term.respond_to?(:chars) && !new_term.empty? then
              #~ $stderr.puts "promoting #{new_term}"
              the_term = new_term.to_s
              break
            end
          end
          new_para.child << XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term + ": ")])
          results << new_para
        elsif value.respond_to?(:each) then
          next if da_link.empty? && !value.respond_to?(:each_pair) && value.all? {|obj| obj.respond_to?(:chars) }  # did that in 1st pass
          the_term = key.to_s + ": "
          $promotions.each do |t|
            if (new_term = value.fetch(t, nil)) && new_term.respond_to?(:chars) && !new_term.empty? then
              #~ $stderr.puts "promoting #{new_term}"
              the_term = new_term.to_s
              break
            end
          end if value.respond_to?(:each_pair)
          if $list_tags.index(key.to_s) && value.respond_to?(:each_pair) then
            if da_link.empty? then
              results << XML.new(tags["para"], {}, "", [XML.new("", {}, the_term)])
            else
              results << XML.new(tags["para"], {}, "", [XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term)])])
            end
            the_list = XML.new(tags["itemizedlist"])
            value.each_pair do |k, v|
              list_item = XML.new(tags["listitem"])
              list_item.child += struct_to_xml_old({k => v}, parent, tags: tags, follow_link: follow_link, level: level + 2)
              the_list.child << list_item
              #~ results << tempb.sub(/\A(\s*)/) {|str|  (" " * ($1.length - 2)) + "* " }
            end
            results.last.child << the_list
          else
            the_list = XML.new(tags["variablelist"])
            the_entry = XML.new(tags["varlistentry"])
            if da_link.empty? then
              the_term = XML.new(tags["term"], {}, "", [XML.new("", {}, the_term)])
            else
              the_term = XML.new(tags["term"], {}, "", [XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term)])])
            end
            the_item = XML.new(tags["listitem"])
            the_item.child += struct_to_xml_old(value, parent, tags: tags, follow_link: follow_link, level: level + 1)
            the_entry.child << the_term
            the_entry.child << the_item
            the_list.child << the_entry
            results << the_list
          end
        end
      end
      
    elsif what.respond_to?(:each) then
      
      if what.any? {|obj| obj.respond_to?(:each) } then
        what.each do |obj|
          results += struct_to_xml_old(obj, parent, tags: tags, follow_link: follow_link, level: level + 1)
        end
      else
        results << XML.new(tags["para"], {}, "", [XML.new("", {}, what.join("|"))])
      end
      
    else
      results << XML.new(tags["para"], {}, "", [XML.new("", {}, what.to_s)])
    end
    
    return results
  end  # struct_to_xml_old
  
  
  
  $promotions = %w( name title )
  $descriptors = %w( description )
  $list_tags = %w( properties )
  
  def struct_to_xml(what, parent = what, tags: DOCBOOK_STRUCT_TAGS, follow_link: true, level: 0)
    results = []
    the_term = ""
    
    if what.respond_to?(:each_pair) && what.has_key?("$ref") then
      the_term = what["name"].to_s if what.respond_to?(:each_pair) 
      newh = parent.at(what["$ref"])
      key = newh.keys[0]
      what = newh[key]
    end
    
    if what.respond_to?(:each_pair) then
      vle = XML.new("varlistentry")
      results << vle
      term = XML.new("term")
      vle.child << term
      li = XML.new("listitem")
      vle.child << li
      #~ the_term = ""
      remainders = []
      
      #~ what = parent.at(what["$ref"]) if what.has_key?("$ref")
      
      what.each_pair do |key, value|
        if $descriptors.index(key.to_s) then
          li.child << XML.new("para", {}, "", [XML.new("", {}, value.to_s)])
        elsif $promotions.index(key.to_s) then
          the_term = value.to_s if the_term.empty?
        elsif key.to_s == "schema" || key.to_s == "items" then
          what_it_is = XML.new("para")
          remainders << what_it_is
          if value.respond_to?(:each_pair) then
            value.each_pair do |k, v|
              if k.to_s == "$ref" then
                da_link = v.sub('#/', '').sub('/', '-')
                newh = parent.at(v)
                k = newh.keys[0]
                v = newh[k]
                what_it_is.child << XML.new("", {}, "#{key}: ")
                what_it_is.child << XML.new("link", {"linkend" => da_link.downcase}, "", [XML.new("", {}, da_link[/[^-]+$/])])
                results += struct_to_xml(v, parent, tags: tags, follow_link: follow_link, level: level + 1)
              elsif k.to_s == "properties" then
                if v.respond_to?(:each_pair) then
                  results += struct_to_xml({"name" => k}.merge(v), parent, tags: tags, follow_link: follow_link, level: level + 1)
                else
                  remainders << XML.new("para", {}, "", [XML.new("", {}, "#{k.to_s}: #{v.to_s}")])
                end
              end
            end
          end
        elsif key.to_s == "properties" then
          if value.respond_to?(:each_pair) then
            value.each_pair do |k, v|
              if v.respond_to?(:each_pair) then
                results += struct_to_xml({"name" => k}.merge(v), parent, tags: tags, follow_link: follow_link, level: level + 1)
              else
                remainders << XML.new("para", {}, "", [XML.new("", {}, "#{k.to_s}: #{v.to_s}")])
              end
            end
          else
            remainders << XML.new("para", {}, "", [XML.new("", {}, "#{key.to_s}: #{value.to_s}")])
          end
        else
          if key =~ /doc-type$/ then
              remainders << XML.new("para", {}, "", [XML.new("", {}, "NOTE: #{value.to_s}")])
          else
            remainders << XML.new("para", {}, "", [XML.new("", {}, "#{key.to_s}: #{value.to_s}")])
          end
        end
      end
      li.child += remainders
      term.child << XML.new("", {}, the_term)
      results.shift if li.child.empty?  # get rid of first, i.e. vle
      
    elsif what.respond_to?(:each) then
      if what.any? {|obj| obj.respond_to?(:each) } then
        what.each do |obj|
          results += struct_to_xml(obj, parent, tags: tags, follow_link: follow_link, level: level + 1)
        end
      else
        results << XML.new("para", {}, "", [XML.new("", {}, what.join("|"))])
      end
    else
      results << XML.new("para", {}, "", [XML.new("", {}, what.to_s)])
    end
    
    return results
  end  # struct_to_xml


  def struct_to_xml_second(what, parent = what, tags: DOCBOOK_STRUCT_TAGS, follow_link: true, level: 0)
    results = []
    
    if what.respond_to?(:each_pair) then
      
      # 1st pass: simple values...
      what.each_pair do |key, value|
        if $descriptors.index(key.to_s) then
          the_term = ""
        else
          the_term = key.to_s + ": "
        end
        if key != "$ref" && !$promotions.index(key.to_s) && !value.respond_to?(:each) then
          if $promotions.index(key.to_s) && value.respond_to?(:chars) then
            #~ $stderr.puts "skipping #{key}:#{value} because it should have been promoted."
            next
          end
          results << XML.new("para", {}, "", [XML.new("", {}, the_term + value.to_s)])
        elsif !value.respond_to?(:each_pair) && value.respond_to?(:each) && value.all? {|obj| obj.respond_to?(:chars) } then
          results << XML.new("para", {}, "", [XML.new("", {}, the_term + value.join("|"))])
        end
      end
      
      # 2nd pass: complex values...
      what.each_pair do |key, value|
        da_link = ""
        if key == "$ref" then
          da_link << value.sub('#/', '').sub('/', '-').downcase
          newh = parent.at(value)
          key = newh.keys[0]
          value = newh[key]
        end
        if !follow_link && value.respond_to?(:each_pair) && !da_link.empty? then
          new_para = XML.new("para") 
          results << new_para
          the_term = key.to_s + ": "
          $promotions.each do |t|
            if (new_term = value.fetch(t, nil)) && new_term.respond_to?(:chars) && !new_term.empty? then
              #~ $stderr.puts "promoting #{new_term}"
              the_term = new_term.to_s
              break
            end
          end
          new_para.child << XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term + ": ")])
          results << new_para
        elsif value.respond_to?(:each) then
          next if da_link.empty? && !value.respond_to?(:each_pair) && value.all? {|obj| obj.respond_to?(:chars) }  # did that in 1st pass
          the_term = key.to_s + ": "
          $promotions.each do |t|
            if (new_term = value.fetch(t, nil)) && new_term.respond_to?(:chars) && !new_term.empty? then
              #~ $stderr.puts "promoting #{new_term}"
              the_term = new_term.to_s
              break
            end
          end if value.respond_to?(:each_pair)
          if $list_tags.index(key.to_s) && value.respond_to?(:each_pair) then
            vl = XML.new("varlistentry")
            results << vl
            if da_link.empty? then
              vl.child << XML.new("term", {}, "", [XML.new("", {}, the_term)])
            else
              vl.child << XML.new("term", {}, "", [XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term)])])
            end
            
            
            #~ the_list = XML.new(tags["itemizedlist"])
            #~ value.each_pair do |k, v|
              #~ list_item = XML.new(tags["listitem"])
              #~ list_item.child += struct_to_xml({k => v}, parent, tags: tags, follow_link: follow_link, level: level + 2)
              #~ the_list.child << list_item
            #~ end
            #~ results.last.child << the_list
            
            li = XML.new("listitem")
            vl.child << li
            value.each_pair do |k, v|
              results += struct_to_xml({k => v}, parent, tags: tags, follow_link: follow_link, level: level + 2)
            end
            
            
          else
            
            #~ the_list = XML.new(tags["variablelist"])
            #~ the_entry = XML.new(tags["varlistentry"])
            #~ if da_link.empty? then
              #~ the_term = XML.new(tags["term"], {}, "", [XML.new("", {}, the_term)])
            #~ else
              #~ the_term = XML.new(tags["term"], {}, "", [XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term)])])
            #~ end
            #~ the_item = XML.new(tags["listitem"])
            #~ the_item.child += struct_to_xml(value, parent, tags: tags, follow_link: follow_link, level: level + 1)
            #~ the_entry.child << the_term
            #~ the_entry.child << the_item
            #~ the_list.child << the_entry
            #~ results << the_list
            
            if da_link.empty? then
              #~ vl = XML.new("varlistentry", {}, 
              results << XML.new("para", {}, "", [XML.new("", {}, the_term)])
            else
              results << XML.new("para", {}, "", [XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term)])])
            end
            results += struct_to_xml(value, parent, tags: tags, follow_link: follow_link, level: level + 1)
            
            
          end
        end
      end
      
    elsif what.respond_to?(:each) then
      
      if what.any? {|obj| obj.respond_to?(:each) } then
        what.each do |obj|
          results += struct_to_xml(obj, parent, tags: tags, follow_link: follow_link, level: level + 1)
        end
      else
        results << XML.new("para", {}, "", [XML.new("", {}, what.join("|"))])
      end
      
    else
      results << XML.new("para", {}, "", [XML.new("", {}, what.to_s)])
    end
    
    return results
  end  # struct_to_xml


  def struct_to_txt(what, parent = what, tags: DOCBOOK_STRUCT_TAGS, follow_link: true, level: 0)
    results = ""
    
    if what.respond_to?(:each_pair) then
      
      # 1st pass: simple values...
      what.each_pair do |key, value|
        if $descriptors.index(key.to_s) then
          the_term = ""
        else
          the_term = key.to_s + ": "
        end
        if key != "$ref" && !$promotions.index(key.to_s) && !value.respond_to?(:each) then
          if $promotions.index(key.to_s) && value.respond_to?(:chars) then
            #~ $stderr.puts "skipping #{key}:#{value} because it should have been promoted."
            next
          end
          results << ("  " * level) + the_term + value.to_s + "\n"
        elsif !value.respond_to?(:each_pair) && value.respond_to?(:each) && value.all? {|obj| obj.respond_to?(:chars) } then
          results << ("  " * level) + the_term + value.join("|") + "\n"
        end
      end
      
      # 2nd pass: complex values...
      what.each_pair do |key, value|
        da_link = ""
        if key == "$ref" then
          da_link << value.sub('#/', '').sub('/', '-').downcase
          newh = parent.at(value)
          key = newh.keys[0]
          value = newh[key]
        end
        if !follow_link && value.respond_to?(:each_pair) && !da_link.empty? then
          #~ new_para = XML.new(tags["para"]) 
          #~ results << new_para
          the_term = key.to_s
          $promotions.each do |t|
            if (new_term = value.fetch(t, nil)) && new_term.respond_to?(:chars) && !new_term.empty? then
              #~ $stderr.puts "promoting #{new_term}"
              the_term = new_term.to_s
              break
            end
          end
          results << ("  " * level) + the_term + ": <" + da_link + ">\n"
          #~ new_para.child << XML.new("link", {"linkend" => da_link}, "", [XML.new("", {}, the_term + ": ")])
        elsif value.respond_to?(:each) then
          next if da_link.empty? && !value.respond_to?(:each_pair) && value.all? {|obj| obj.respond_to?(:chars) }  # did that in 1st pass
          the_term = key.to_s
          $promotions.each do |t|
            if (new_term = value.fetch(t, nil)) && new_term.respond_to?(:chars) && !new_term.empty? then
              #~ $stderr.puts "promoting #{new_term}"
              the_term = new_term.to_s
              break
            end
          end if value.respond_to?(:each_pair)
          if $list_tags.index(key.to_s) && value.respond_to?(:each_pair) then
            results << ("  " * level) + the_term + ": \n"
            value.each_pair do |k, v|
              tempb = struct_to_txt({k => v}, parent, tags: tags, follow_link: follow_link, level: level + 2)
              results << tempb.sub(/\A(\s*)/) {|str|  (" " * ($1.length - 2)) + "* " }
            end
          else
            results << ("  " * level) + the_term + ": \n"
            results << struct_to_txt(value, parent, tags: tags, follow_link: follow_link, level: level + 1)
          end
        end
      end
      
    elsif what.respond_to?(:each) then
      
      if what.any? {|obj| obj.respond_to?(:each) } then
        what.each do |obj|
          results << struct_to_txt(obj, parent, tags: tags, follow_link: follow_link, level: level + 1)
        end
      else
        results << ("  " * level) + what.join("|") + "\n"
      end
      
    else
      results << ("  " * level) + what.to_s + "\n"
    end
    
    return results
  end  # struct_to_txt


if __FILE__ == $0 then
  x = nil
  if ARGV.length > 1 then
    File.open(ARGV[0], "r") do |input|  
      x = XML.parse(input)  # {|line, start_column, context, buffer| $stderr.puts "line=#{line} start_column=#{start_column} ctxt[#{context}] [#{buffer}]" }  #
    end
    File.open(ARGV[1], "w") do |output| 
      output.puts x.to_s(0, true)
    end
  else
    File.open(ARGV[0], "r") do |input|  
      x = XML.look(input, (ARGV[0] =~ /\.html?$/))   #{ $stderr.puts "line=#{line} start_column=#{start_column} ctxt[#{context}] [#{buffer}]" }  #
      #~ x = XML.look(input)   #{ $stderr.puts "line=#{line} start_column=#{start_column} ctxt[#{context}] [#{buffer}]" }  #
    end
  end
end
