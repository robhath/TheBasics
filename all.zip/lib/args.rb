
  $args = {}
  $nargs = []

  def get_args(args: $args, min: 0, syntax: "invalid arguments", nargs: $nargs, nmin: 0, nsyntax: "not enough arguments")
    if ARGV.length < min then
      $stderr.puts syntax
      exit
    end
    prev = nil
    ARGV.each do |a|
      if a[0,2] == "--" then
        args[a] = true
      elsif a[0,1] == "-" then
        prev = a
        args[a] = true  # for now...
      elsif prev then
        if a =~ /^file:/i && File.exist?($') && !File.directory?($') then
          args[prev] = IO.read($').chomp!
          $stderr.puts "warning: contents of file #{$'} used for #{prev}"
        elsif a[0] == "\"" && a[-1] == "\"" then
          args[prev] = a[1..-2]
        else
          args[prev] = a
        end
        prev = nil
      else
        nargs <<  a
      end
    end
    if args["-help"] || args["--help"] then
      $stderr.puts syntax
      exit
    end
    if nargs.length < nmin then
      $stderr.puts nsyntax
      exit
    end
  end  # get_args
  
  
if __FILE__ == $0 then
  
  get_args(min: 1, nmin: 1)
  
  $stderr.puts $args
  $stderr.puts $nargs
  
end
