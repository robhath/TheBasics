
$LOAD_PATH << File.dirname($0) + "/lib"

require 'stringio'
require 'XML.rb'

class String
  
  # Return a copy of this string with any entity references replaced by the entity's value.
  #     note: NON-recursive substitution--entity values may be entities in turn!
  #     note: keeps undefined entities intact (no substitution performed).
  # 
  # @param  entities  [Hash]    the entities which will be substituted
  # @return  [String]  
  def subst(entities)
    return self.gsub(/(%|&)(#?[-\w.]+?);/m) do |str|  # (<!--.*?-->)|
      (entities[$2] || str)
    end
  end  # subst
  
  
  # Return a regular expression derived from the DTD formatted string.
  #     Primarily, places grouping parantheses around names (e.g. "foo+" becomes
  #     "(foo)+") and removes "PCDATA" and "EMPTY".
  # 
  # @return  [Regexp]    
  def dtd_to_re()
    result = String.new(self)
    result.gsub!(/([^()?*+|\s]+)([?*+])/m, '(\1)\2')
    result.gsub!(/(\|?)\s*(\(?)\s*#PCDATA\s*(\)?)\s*(\|?)/) do |str|
      if !$1.empty? && !$2.empty? && !$3.empty? then
        "#{$4}"
      elsif !$2.empty? && !$3.empty? && !$4.empty? then
        "#{$1}"
      elsif !$1.empty? && !$3.empty? then
        "#{$2}#{$3}#{$4}"
      elsif !$2.empty? && !$4.empty? then
        "#{$1}#{$2}#{$3}"
      else
        ""
      end
    end
    result.sub!(/EMPTY/, "")
    # now clean up ill-formed expressions...
    result.gsub!(/\(([*+?])\)/, '(.\1)')
    return Regexp.new("^#{result.delete(", \t\n")}$")
  end  # dtd_to_re
  
end  # String


class DTD < Validator

  TAG = "<"
  CTAG = ">"
  ATTRIB = "="
  PCD = "d"
  COMMENT = "!--"
  END_COMMENT = "-->"
  DATA = "!["
  END_DATA = "]]>"
  BANG_TAG = "!"
  END_BANG_TAG = ">"
  
  $old_ruby = (RUBY_VERSION =~ /^1\.8/ ? true : false)
  
  # Parse the DTD file.
  # 
  # @param  f  [File]    the file to be parsed
  # @block  [Integer, Integer, String]   action to perform as each part of DTD is parsed, with
  #     parameters showing the line and column where the part was found and the string contents
  #     of the part
  # @return  void
  def self.parse(f)
    where = PCD
    where_last = PCD
    buffer = ""
    data_count = 0
    line = 1; column = 0; start_column = 0
    
    while c = f.getc do
      c = c.chr if $old_ruby
      buffer << c
      
      if c == "\n" then
        line += 1; column = 1;
      else
        column += 1
      end
      
      if where == COMMENT then
        if buffer.end_with?(END_COMMENT) then
          yield(line, start_column, buffer) if defined?(yield)
          where = PCD
          buffer = ""
          start_column = column
        end
        
      elsif where == DATA then
        if buffer.end_with?(TAG + DATA) then
          # nested data allowed!?!
          data_count += 1
        elsif buffer.end_with?(END_DATA) then
          if data_count > 0 then
            data_count -= 1
          else
            yield(line, start_column, buffer) if defined?(yield)
            where = PCD
            buffer = ""
            start_column = column
          end
        end
        
      elsif where == BANG_TAG then
        if buffer.end_with?(TAG + DATA) then
          where = DATA
        elsif buffer.end_with?(TAG + COMMENT) then
          where = COMMENT
        elsif buffer.end_with?(END_BANG_TAG) then
          yield(line, start_column, buffer) if defined?(yield)
          where = PCD
          buffer = ""
          start_column = column
        end
        
      elsif buffer.end_with?(TAG + BANG_TAG) then
        where = BANG_TAG
      
      elsif buffer.end_with?(TAG) then
        if where == PCD && !buffer.empty? then
          yield(line, start_column, buffer[0..-(TAG.length+1)]) if defined?(yield)
          buffer = "#{TAG}"
          start_column = column - 1
        end
        where = TAG
      
      elsif buffer.end_with?(CTAG) then
        if where == TAG then
          yield(line, start_column, buffer) if defined?(yield)
          where = PCD
          buffer = ""
          start_column = column
        else
          $stderr.puts "ERROR: invalid #{CTAG} @ #{line}:#{column}"
        end
        
      end
    end  # while
  end  # parse


  # The entities defined in the DTD
  $entities = {"notation.class" => "(PNG|JPG)"}


  # Build a validation engine (Array of Validation elements) based on the DTD embodied in the given file.
  #
  # @param  f  [File]    
  # @param  elements  [Array<Validator>]    will be filled with DTD Validators
  # @return  void
  def self.buildValidationEngine(f, elements = [])
    aGroups = []
    complexTypes = []
    parse(f) do |line, start_column, fubber|
      
      buffer = fubber.subst($entities)
      #~ $stderr.puts "buffer[#{buffer.chomp}]" if buffer =~ /(%|&)(#?[-\w.]+?);/m
      
      if buffer =~ /\A<!ENTITY\s+(%\s+)?([^\s"']+)\s+("|')([^\3]*)\3/m then
        typ = $1
        key = $2
        value = $4
        value = value.subst($entities)  # try to take care of recursive calls
        value = value.subst($entities)
        value = value.subst($entities)
        value = value.subst($entities)
        $entities[key] = value
        #~ $stderr.puts "entity typ=#{typ} key=#{key} value=#{value}/// #{$3}"  # debug
        
      elsif buffer =~ /\A<!ELEMENT\s+(\S+)\s+([^>]*)/m then
        name = $1
        defn = $2
        if i = elements.index {|dtd| dtd.name == name } then
          elements[i].mixed = defn.include?("#PCDATA")
          elements[i].childREn = defn.dtd_to_re
        else
          elements << DTD.new(name, {}, defn.dtd_to_re, "", (defn.include?("#PCDATA")))
        end
        
      elsif buffer =~ /\A<!ATTLIST\s+(\S+)\s+/m then
        name = $1
        attributes = $'
        #~ $stderr.puts "attlist: name=#{name} [#{fubber}][#{buffer}]///"
        here = nil
        if i = elements.index {|dtd| dtd.name == name } then
          here = elements[i].attributes
        else
          elements << DTD.new(name)
          here = elements.last.attributes
        end
        while attributes =~ /(\S+)\s+([^#]+)?(#REQUIRED|#IMPLIED|#FIXED)?(\s*("|')([^\5]*?)\5)?/m do
          attr_name = $1
          attr_values = $2
          attr_type = $3
          attr_default = $6
          #~ $stderr.puts "attlist name=#{name} attr_name=#{attr_name} vals=#{attr_values} typ=#{attr_type} def=#{attr_default}///"
          attributes = $'
          
          if attr_default && !attr_default.empty? then
            attr_values = Regexp.new("^#{attr_default}$")
          elsif attr_values.include?("(") then
            attr_values = Regexp.new("^#{attr_values.delete(", \t\n")}$")
          else
            attr_values = Regexp.new(".+")
          end
          attr_name.sub!(/^xml:/i, "")
          here[attr_name] = [attr_values, (attr_type ? attr_type : "#IMPLIED")]
        end
        
      elsif buffer =~ /\A<!\[\s*IGNORE\s*/m then
        # well... ignore!
        
      elsif buffer =~ /\A<!\[\s*INCLUDE\s*\[(.*)\]\]>\s*\z/m then
        str = $1
        #~ $stderr.puts "\n>>>include[#{str}]<<<\n"
        buildValidationEngine(StringIO.new(str), elements)
        
      elsif buffer =~ /\A<!--/ then  # comment
        # ignore
        
      end
    end
  end  # buildValidationEngine
  
end  # class DTD

