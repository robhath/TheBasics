
module Sorts

  def quick_sort!(lo = 0, hi = -1)
    hi = self.length + hi if hi < 0
    if lo < hi then
      # partition...
      pivot = self[lo]
      i = lo - 1
      j = hi + 1
      loop do
        begin
          i += 1 
        end while self[i] < pivot
        begin 
          j -= 1 
        end while self[j] > pivot
        break if i >= j
        self[i], self[j] = self[j], self[i]
      end
      
      quick_sort!(lo, j)
      quick_sort!(j + 1, hi)
    end
  end  # quick_sort!
  
end  # sorts
