
class String
  
  # Convert all < > & " or ' characters in a string to their corresponding XML entity.
  # 
  # @return [String]  a copy of the string with the characters converted
  def to_xml(quotes = true)
    #~ $stderr.puts "to_xml:: #{self}"
    self.gsub(/<|>|"|'|&(?!(#[0-9A-FXa-fx]+|[-\w]+);)/) do |str|
      case str
        when "<" then "&lt;"
        when ">" then "&gt;"
        when "&" then "&amp;"
        when "\"" then (quotes ? "&quot;" : '"')
        when "'" then (quotes ? "&apos;" : "'")
      end
    end
  end  # to_xml
  

  # Convert all instances of the 5 standard XML entities back to < > & " or ' characters.
  # 
  # @return [String]  a copy of the string with the entities converted
  def xml2txt
    self.gsub(/&(lt|gt|amp|quot|apos);/) do |str|
      case str
        when "&lt;" then "<"
        when "&gt;" then ">"
        when "&amp;" then "&"
        when "&quot;" then "\""
        when "&apos;" then "'"
      end
    end
  end  # xml2txt
  

  def to_csv()
    if self.index("\"") || self.index(",") || self.index("\n") then
      return '"' + self.gsub(/"/, '""') + '"'
    else
      return self.gsub(/^(=|-|\+|@|\')/, ' \1') # for Excel's sake
    end
  end  # to_csv
  
  
  def from_csv()
    if self.length < 2 || self[0] != '"' || self[-1] != '"' then
      return String.new(self)
    else
      return self.gsub(/""/, '"')
    end
  end  # from_csv
  
  
  def get_link_parts()
    # get protocol, domain and path...
    result = { "protocol" => "", "domain" => "", "path" => "" }
    if self =~ /^([^:\/]*:(?:\/\/)*)*([^\/]+)(.*)/ then
      result["protocol"] = $1 || ""
      result["domain"] = $2 || ""
      result["path"] = $3 || ""
       if result["path"].empty? then
        result["path"] = result["domain"]
        result["domain"] = "."
      end
    end
    return result
  end  # get_link_parts
  
  
  def burst(separator = "-")
    temp = String.new(self)
    # special case of an initialism (2+ upper-case or digits in a row)...
    # while temp.sub!(/(^|\s|[a-z])([A-Z]{2,})([a-z]|\s|$)/) {|str|
    # $stderr.puts temp if temp =~ /(^|\s|[a-z])([A-Z][0-9A-Z]+)([a-z]|\s|$)/ # do nothing to an initialism
    return temp if temp =~ /^([A-Z][0-9A-Z]+)$/ # do nothing to an initialism itself
    while temp.sub!(/(^|\s|[a-z])([A-Z][0-9A-Z]+)([a-z]|\s|$)/) {|str|
      pre = $1
      initialism = $2
      post = $3
      pre << separator if pre[-1] && pre[-1] =~ /[a-z]/ 
      if post[-1] && post[-1] =~ /[a-z]/ then
        initialism = initialism[0..-2] + separator + initialism[-1].downcase
      end
      pre + initialism + post
    } do end
    while temp.sub!(/([a-z])([A-Z])/) {|str|
      $1 + separator + $2.downcase
    } do end
    while temp.sub!(/(^|\s)([A-Z])/) {|str|
      $1 + $2.downcase
    } do end
    return temp
  end  # burst
  
  
  def unburst(separator = "-")
    temp = String.new(self)
    while temp.sub!(/(#{separator})([A-Za-z])/) {|str|
      $2.upcase
    } do end
    while temp.sub!(/(^|\s)([a-z])/) {|str|
      $1 + $2.upcase
    } do end
    return temp
  end  # unburst


  def indent(str = "  ")
    return self.gsub(/^/) {|s| s + str }
  end  # indent

  
  def indent!(str = "  ")
    return self.gsub!(/^|\n/) {|s| s + str }
  end  # indent


  def json_literal()
    result = case self
      when /true/ then
        true
      when /false/ then
        false
      when /null/ then
        nil
      when /^[-+]?[\d]+$/ then
        self.to_i
      when /^[-+]?[\d\.]+(e(\+|-)?[\d.]+)?$/i then
        self.to_f
      else
        self
    end
  end  # json_literal


  SPACE = "s"
  COMMENT = "/"
  END_COMMENT = "\n"
  DQUOTE = '"'
  LIST = "["
  END_LIST = "]"
  OBJ = "{"
  END_OBJ = "}"
  COMMA = ","
  COLON = ":"
  LITERAL = "l"
  SPECIAL = "\"/[]{},: \n\t\f\r"  # any of the above, incl. whitespace


  def json_parse(strict: true)
    #$stderr.puts "json_parse(strict: #{strict})" 
    line = 1; column = 0; start_column = 0
    where = SPACE
    da_string = ""
    found_empty = false
    r = []

    self.each_char do |c|
      if c == "\n" then
        line += 1; column = 0
      else
        column += 1
      end

      if where == COMMENT then
        if c == END_COMMENT then
          where = SPACE
        end
        
      elsif where == DQUOTE then
        if c == DQUOTE && da_string[-1] == "\\" then
          # escaped quote...
          da_string[-1] = DQUOTE
        elsif c == DQUOTE then
          r << String.new(da_string)
          da_string = ""
          where = SPACE
        else
          da_string << c
        end
     
      elsif SPECIAL.include?(c) then
 
        unless da_string.empty? then
          l = da_string.json_literal
          if l.class == String then
            if (strict || l !~ /(boolean|integer|long|number|timestamp|\*)/i) then
              if defined?(yield) then
                yield(line, column, r, "ERROR:#{line}:#{column}: invalid literal '#{da_string}'")
              else
                $stderr.puts "ERROR: [#{line},#{column}] invalid literal '#{da_string}'"
              end
              return nil
            else
              r << l 
            end
          else
            r << l 
          end
        end
        da_string = ""

        if c == COMMENT then
          # start of comment...
          if strict then
            if defined?(yield) then
              yield(line, column, r, "ERROR:#{line}:#{column}: invalid character '#{c}'") 
            else
              $stderr.puts "ERROR: [#{line},#{column}] invalid character '#{c}'"
            end
            return nil
          else
            where = COMMENT
          end

        elsif c == DQUOTE then
          # start of quoted string...
          where = DQUOTE
  
        elsif c == LIST then
          # $stderr.puts "start of list [#{line},#{column}]"
          r << []
          where = LIST
          found_empty = false
  
        elsif c == OBJ then
          # $stderr.puts "start of object [#{line},#{column}]"
          r << {}
          where = OBJ
          found_empty = false
  
        elsif c == END_LIST then
          if r.length > 0 && r[-1].class == Array && r[-1].empty? && !found_empty then
            # $stderr.puts "empty list [#{line},#{column}]"
            found_empty = true
          elsif r.length > 1 && r[-2].class == Array then
            # $stderr.puts "end of list [#{line},#{column}]"
            item = r.pop
            r[-1] << item 
            found_empty = false
          else 
            if defined?(yield) then
              yield(line, column, r, "ERROR:#{line}:#{column}: unexpected end of list") 
            else
              $stderr.puts "ERROR: [#{line},#{column}] unexpected end of list"
            end
            return nil
          end
          where = END_LIST
  
        elsif c == END_OBJ then
          if r.length > 0 && r[-1].class == Hash && r[-1].empty? && !found_empty then
            # $stderr.puts "empty object [#{line},#{column}]"
            found_empty = true
          elsif r.length > 2 && r[-2].class == String && r[-3].class == Hash then
            # $stderr.puts "end of object [#{line},#{column}]"
            value = r.pop
            key = r.pop
            r[-1][key] = value 
            found_empty = false
          elsif r.length > 0 then
            if defined?(yield) then
              yield(line, column, r, "ERROR:#{line}:#{column}: unexpected end of object") 
            else
              $stderr.puts "ERROR: [#{line},#{column}] unexpected end of object"
            end
            return nil
          end
          where = END_OBJ
  
        elsif c == COMMA then
          # item ends, next item...
          if r.length > 2 && r[-2].class == String && r[-3].class == Hash then
            value = r.pop
            key = r.pop
            r[-1][key] = value 
          elsif r.length > 1 && r[-2].class == Array then
            item = r.pop
            r[-1] << item
          else 
            if defined?(yield) then
              yield(line, column, r, "ERROR:#{line}:#{column}: unexpected comma")
            else
              $stderr.puts "ERROR: [#{line},#{column}] unexpected comma"
            end
            return nil
          end
          where = COMMA
          found_empty = false
  
        elsif c == COLON then
          # key ends; look for value next...
          if r.length > 1 && r[-1].class == String && r[-2].class == Hash then
            # key was probably a quoted string and is living at the top
          elsif !strict && r.length > 1 && r[-2].class == Hash then
            # key was probably a literal
          else
            if defined?(yield) then
              yield(line, column, r, "ERROR:#{line}:#{column}: unexpected colon")
            else
              $stderr.puts "ERROR: [#{line},#{column}] unexpected colon"
            end
            return nil
          end
          where = COLON
          found_empty = false
          
        elsif " \t\n\f\r".include?(c) then 
          # whitespace...
          where = SPACE

        end  # elsif special
  
      else
        # another part of a literal perhaps?...
        if c !~ /\s/ then
          da_string << c
          where = LITERAL
        end

      end  # if

    end  # while c

    if strict && r.length > 1 then
      if defined?(yield) then
        yield(line, column, r, "ERROR:#{line}:#{column}: invalid json")
      else
        $stderr.puts "ERROR: [#{line},#{column}] invalid json"
      end
      return nil
    end

    return r[0]
  end  # json_parse 

end  # String
