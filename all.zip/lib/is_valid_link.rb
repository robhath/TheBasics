#!ruby

require 'net/http'

class String
  
  def is_valid_link(rel_path = "", tf_only = false)\
    
    return (tf_only ? true : "Self reference") if self =~ /^#/
    
    if self =~ /^([^:\/]*:(?:\/\/)*)*([^\/]+)(.*)/ then
      protocol = $1 || ""
      domain = $2 || ""
      path = $3 || ""
      path = "/" if path.empty?
      #~ $stderr.puts "protocol=#{protocol}, domain=#{domain}, path=#{path}"  # debug
      
      # assume the worst
      result = "Invalid protocol: #{protocol}"
      tf_result = false
      
      # "mailto:" is a valid protocol, but not one we wish to check
      return (tf_only ? true : "Email link") if protocol =~ /^mailto:/  #.downcase.include?("mailto")
      
      # if protocol is empty, is it a local file, perhaps?
      if protocol.empty? then
        if File.exists?(File.expand_path((domain + path)[/[^\#]+/], rel_path)) then
          result = "File exists"
          tf_result = true
          #~ $stderr.puts "#{tf_result} result=#{result}"  # debug
          return (tf_only ? tf_result : result)
        end
      end
        
      # o/w if not "http:" and not empty, then it is an invalid protocol, don't bother checking
      return (tf_only ? tf_result : result) unless protocol.empty? || protocol.downcase.include?("http")
      
      begin
        response = Net::HTTP.get_response(domain, path)
        case response.code
          when /^1/ then
            result = "Informational"
          when /^2/ then
            result = "Success"
            tf_result = true
          when /^3/ then
            result = "Redirection"
            tf_result = true
          when /^4/ then
            result = "Client Error"
          when /^5/ then
            result = "Server Error"
          else
            result = "Unknown Error"
          end
        result << " : #{response.code}::#{response.message}"
      rescue
        result = "Invalid domain specification: #{domain}"
      end
    else
      result = "Not a valid link : #{self}"
    end
    
    #~ $stderr.puts "#{tf_result} result=#{result}"  # debug
    return (tf_only ? tf_result : result)
  end  # is_valid_link
  
end  # class String


if __FILE__ == $0 then
  tf_only = false
  ARGV.each do |arg|
    if arg == "-tf" then
      tf_only = true
    else
      puts arg.is_valid_link(tf_only) 
    end
  end
end
