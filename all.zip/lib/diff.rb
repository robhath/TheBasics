#!ruby
# encoding: UTF-8


DELETE = -1
EQUAL = 0
INSERT = 1


def prefix_length(x, y) 
  #~ $stderr.puts "prefix_length(#{x}, #{y})"  # debug
  i = 0
  len1 = x.length
  len2 = y.length
  i += 1 while (i < len1 && i < len2 && x[i] == y[i])
  #~ $stderr.puts "  --> #{i}"  # debug
  return i
end  # prefix_length


def suffix_length(x, y) 
  #~ $stderr.puts "suffix_length(#{x}, #{y})"  # debug
  i = x.length - 1
  j = y.length - 1
  result = 0
  while (i >= 0 && j >= 0 && x[i] == y[j]) do
    i -= 1
    j -= 1 
    result += 1
  end
  #~ $stderr.puts "  --> #{result}"  # debug
  return result
end  # suffix_length


def diff_bisect(x, y) 
  # Find the 'middle snake' of a diff, split the problem in two and return the recursively constructed diff
  # See Myers 1986 paper: An O(ND) Difference Algorithm and Its Variations
  #~ $stderr.puts "diff_bisect(#{x}, #{y})"  # debug
  # store the text lengths to prevent multiple calls...
  x_length = x.length
  y_length = y.length
  max_d = (x_length + y_length + 1) >> 1  # ceil((x_length + y_length) / 2)
  v_offset = max_d
  v_length = max_d << 1
  v1 = Array.new(v_length, -1)
  v2 = Array.new(v_length, -1)
  v1[v_offset + 1] = 0
  v2[v_offset + 1] = 0
  delta = x_length - y_length
  # if the total number of characters is odd, then the front path will collide with the reverse path...
  front = (delta % 2 != 0)
  # offsets for start and end of k loop; prevents mapping of space beyond the grid...
  k1start = 0
  k1end = 0
  k2start = 0
  k2end = 0
  (0...max_d).step do |d|
    # walk the front path one step...
    ((-d + k1start)..(d - k1end)).step(2) do |k1| 
      k1_offset = v_offset + k1
      if (k1 == -d || (k1 != d && v1[k1_offset - 1] < v1[k1_offset + 1])) then
        x1 = v1[k1_offset + 1]
      else
        x1 = v1[k1_offset - 1] + 1
      end
      y1 = x1 - k1
      while (x1 < x_length && y1 < y_length &&
             x[x1] == y[y1]) do
        x1 += 1
        y1 += 1
      end
      v1[k1_offset] = x1
      if (x1 > x_length) then
        # we ran off the right of the graph...
        k1end += 2
      elsif (y1 > y_length) then
        # we ran off the bottom of the graph...
        k1start += 2
      elsif (front) then
        k2_offset = v_offset + delta - k1
        if (k2_offset >= 0 && k2_offset < v_length && v2[k2_offset] != -1) then
          # mirror x2 onto top-left coordinate system...
          x2 = x_length - v2[k2_offset]
          if (x1 >= x2) then
            # overlap detected, given the location of the 'middle snake', split the diff in two parts and recurse...
            xa = x[0...x1] || []
            ya = y[0...y1] || []
            xb = x[x1..-1] || []
            yb = y[y1..-1] || []
            # compute both diffs serially...
            diffs = diff_main(xa, ya)
            diffsb = diff_main(xb, yb)
            return diffs.concat(diffsb)
          end
        end
      end
    end

    # walk the reverse path one step...
    ((-d + k2start)..(d - k2end)).step(2) do |k2| 
      k2_offset = v_offset + k2
      if (k2 == -d || (k2 != d && v2[k2_offset - 1] < v2[k2_offset + 1])) then
        x2 = v2[k2_offset + 1]
      else
        x2 = v2[k2_offset - 1] + 1
      end
      y2 = x2 - k2
      while (x2 < x_length && y2 < y_length &&
             x[x_length - x2 - 1] == y[y_length - y2 - 1]) do
        x2 += 1
        y2 += 1
      end
      v2[k2_offset] = x2
      if (x2 > x_length) then
        # we ran off the left of the graph...
        k2end += 2
      elsif (y2 > y_length) then
        # we ran off the top of the graph...
        k2start += 2
      elsif (!front) then
        k1_offset = v_offset + delta - k2
        if (k1_offset >= 0 && k1_offset < v_length && v1[k1_offset] != -1) then
          x1 = v1[k1_offset]
          y1 = v_offset + x1 - k1_offset
          # mirror x2 onto top-left coordinate system...
          x2 = x_length - x2
          if (x1 >= x2) then
            # overlap detected, given the location of the 'middle snake', split the diff in two parts and recurse...
            xa = x[0...x1] || []
            ya = y[0...y1] || []
            xb = x[x1..-1] || []
            yb = y[y1..-1] || []
            # compute both diffs serially...
            diffs = diff_main(xa, ya)
            diffsb = diff_main(xb, yb)
            return diffs.concat(diffsb)
          end
        end
      end
    end
  end 
  # number of diffs equals number of items so nothing in common...
  return [[DELETE, x], [INSERT, y]]
end  # diff_bisect


def merge(diffs) 
  # reorder and merge like edit sections.  merge equalities...
  # any edit section can move as long as it doesn't cross an equality...
  #~ $stderr.puts "merge(#{diffs})"  # debug
  diffs.push([EQUAL, []])  # add a dummy entry at the end
  pointer = 0
  count_delete = 0
  count_insert = 0
  text_delete = []
  text_insert = []
  while (pointer < diffs.length) do
    case (diffs[pointer][0]) 
      when INSERT
        count_insert += 1
        text_insert += diffs[pointer][1]
        pointer += 1
      when DELETE
        count_delete += 1
        text_delete += diffs[pointer][1]
        pointer += 1
      when EQUAL
        # upon reaching an equality, check for prior redundancies...
        if (count_delete + count_insert > 1) then
          if (count_delete != 0 && count_insert != 0) then
            # factor out any common prefixies...
            plen = prefix_length(text_insert, text_delete)
            if (plen != 0) then
              if ((pointer - count_delete - count_insert) > 0 &&
                  diffs[pointer - count_delete - count_insert - 1][0] == EQUAL) then
                diffs[pointer - count_delete - count_insert - 1][1] +=
                    text_insert[0, plen]
              else
                diffs.unshift([EQUAL, text_insert[0, plen]])
                pointer += 1
              end
              text_insert = text_insert[plen..-1]
              text_delete = text_delete[plen..-1]
            end
            # factor out any common suffixes...
            slen = suffix_length(text_insert, text_delete)
            if (slen != 0) then
              diffs[pointer][1] = text_insert[(text_insert.length - slen)..-1] + diffs[pointer][1]
              text_insert = text_insert[0, (text_insert.length - slen)]
              text_delete = text_delete[0, (text_delete.length - slen)]
            end
          end
          # delete the offending records and add the merged ones...
          if (count_delete == 0) then
            diffs[pointer - count_insert, count_delete + count_insert] = [[INSERT, text_insert]]
          elsif (count_insert == 0) then
            diffs[pointer - count_delete, count_delete + count_insert] = [[DELETE, text_delete]]
          else 
            diffs[pointer - count_delete - count_insert, count_delete + count_insert] = 
                [[DELETE, text_delete], [INSERT, text_insert]]
          end
          pointer = pointer - count_delete - count_insert +
                    (count_delete > 0 ? 1 : 0) + (count_insert > 0 ? 1 : 0) + 1
        elsif (pointer != 0 && diffs[pointer - 1][0] == EQUAL) then
          # merge this equality with the previous one...
          diffs[pointer - 1][1] += diffs[pointer][1]
          diffs.slice!(pointer, 1)
        else 
          pointer += 1
        end
        count_insert = 0
        count_delete = 0
        text_delete = []
        text_insert = []
    end
  end
  if (diffs[diffs.length - 1][1].empty?) then
    diffs.pop  # remove the dummy entry at the end
  end

  # second pass: look for single edits surrounded on both sides by equalities
  # which can be shifted sideways to eliminate an equality...
  # e.g: A<ins>BA</ins>C -> <ins>AB</ins>AC
  changes = false
  pointer = 1
  # intentionally ignore the first and last element (don't need checking)...
  while (pointer < diffs.length - 1) do
    if (diffs[pointer - 1][0] == EQUAL &&
        diffs[pointer + 1][0] == EQUAL) then
      # this is a single edit surrounded by equalities.
      if (diffs[pointer][1][(diffs[pointer][1].length - diffs[pointer - 1][1].length)..-1] == diffs[pointer - 1][1]) then
        # shift the edit over the previous equality...
        diffs[pointer][1] = diffs[pointer - 1][1] +
            diffs[pointer][1][0, (diffs[pointer][1].length - diffs[pointer - 1][1].length)]
        diffs[pointer + 1][1] = diffs[pointer - 1][1] + diffs[pointer + 1][1]
        diffs.slice!(pointer - 1, 1)
        changes = true
      elsif (diffs[pointer][1][0, (diffs[pointer + 1][1].length)] == diffs[pointer + 1][1]) then
        # shift the edit over the next equality...
        diffs[pointer - 1][1] += diffs[pointer + 1][1]
        diffs[pointer][1] =
            diffs[pointer][1][(diffs[pointer + 1][1].length)..-1] +
            diffs[pointer + 1][1]
        diffs.slice!(pointer + 1, 1)
        changes = true
      end
    end
    pointer += 1
  end
  # if shifts were made, the diff needs reordering and another merge...
  if (changes) then
    merge(diffs)
  end
end  # merge


def diff_main(x, y) 
  #~ $stderr.puts "diff_main(#{x}, #{y})"  # debug
  return [] if x.empty? && y.empty?
  
  # trim off common prefix...
  plen = prefix_length(x, y)
  return [[EQUAL, x]] if plen == x.length && plen == y.length  # check for equality
  prefix = x[0, plen]

  # trim off common suffix...
  slen = suffix_length(x, y)
  suffix = x[(x.length - slen)..-1]

  # compute the diff on the middle...
  diffs = nil
  xmid = x[plen...(x.length - slen)]
  ymid = y[plen...(y.length - slen)]
  
  if (xmid.empty?) then
    # just add
    diffs = [[INSERT, ymid]]
  elsif (ymid.empty?) then
    # just delete
    diffs = [[DELETE, xmid]]
  else
    found = -1
    t1len = xmid.length
    t2len = ymid.length
    if t1len > t2len then
      i = 0; j = 0
      while i < t1len do
        while i < t1len && j < t2len do
          if xmid[i] == ymid[j] then
            i += 1
            j += 1
          else
            i += 1
            j = 0
            break if (i + t2len) > t1len
          end
        end
        break if j >= t2len || ((i + t2len) > t1len)
      end
      if j >= t2len then
        diffs = [[DELETE, (xmid[0...(i - j)] || [])],
               [EQUAL, ymid],
               [DELETE, (xmid[((i - j) + t2len)..-1] || [])]]
      end
    else
      i = 0; j = 0
      while i < t2len do
        while i < t2len && j < t1len do
          if ymid[i] == xmid[j] then
            i += 1
            j += 1
          else
            i += 1
            j = 0
            break if (i + t1len) > t2len
          end
        end
        break if j >= t1len || ((i + t1len) > t2len)
      end
      if j >= t1len then
        diffs = [[INSERT, (ymid[0...(i - j)] || [])],
               [EQUAL, xmid],
               [INSERT, (ymid[((i - j) + t1len)..-1] || [])]]
      end
    end
  end
  diffs = diff_bisect(xmid, ymid) unless diffs
  
  # restore the prefix and suffix...
  if (prefix && !prefix.empty?) then
    diffs.unshift([EQUAL, prefix])
  end
  if (suffix && !suffix.empty?) then
    diffs.push([EQUAL, suffix])
  end
  merge(diffs)
  return diffs
end  # diff_main


def diff(x, y, xnotes = nil, ynotes = nil)
  results = ""
  diffs = diff_main(x, y)
  
  lineno1 = 0
  lineno2 = 0
  lines1 = ""
  lines2 = ""
  start1 = 0
  start2 = 0
  end1 = 0
  end2 = 0
  
  diffs.each do |typ, items|
    case typ
      when EQUAL
        if start1 > 0 then
          if xnotes && ynotes then
            results << "#{xnotes[start1]}#{end1 > start1 ? ",#{xnotes[end1]}" : ""}d#{ynotes[lineno2]}#{lines1}\n"
          else
            results << "#{start1}#{end1 > start1 ? ",#{end1}" : ""}d#{lineno2}#{lines1}\n"
          end
        elsif start2 > 0 then
          if xnotes && ynotes then
            results << "#{xnotes[lineno1]}a#{ynotes[start2]}#{end2 > start2 ? ",#{ynotes[end2]}" : ""}#{lines2}\n"
          else
            results << "#{lineno1}a#{start2}#{end2 > start2 ? ",#{end2}" : ""}#{lines2}\n"
          end
        end
        items.each do |item| 
          lineno1 += 1
          lineno2 += 1 
        end
        start1 = 0
        start2 = 0
        # no diff output when equal
        
      when DELETE
        start1 = lineno1 + 1
        lines1 = ""
        items.each do |item|
          lines1 << "\n< " + (item || "")
          lineno1 += 1
        end
        end1 = lineno1
        if start2 > 0 then
          # combine with previous insert...
          if xnotes && ynotes then
            results << 
              "#{xnotes[start1]}#{end1 > start1 ? ",#{xnotes[end1]}" : ""}c#{ynotes[start2]}#{end2 > start2 ? ",#{ynotes[end2]}" : ""}#{lines1}\n---#{lines2}\n"
          else
            results << 
              "#{start1}#{end1 > start1 ? ",#{end1}" : ""}c#{start2}#{end2 > start2 ? ",#{end2}" : ""}#{lines1}\n---#{lines2}\n"
          end
          start1 = 0
          start2 = 0
        else
          # save it till later!
          # results << "#{start1},#{end1}d#{lineno2}#{lines1}\n"
        end
        
      when INSERT
        start2 = lineno2 + 1
        lines2 = ""
        items.each do |item|
          lines2 << "\n> " + (item || "")
          lineno2 += 1
        end
        end2 = lineno2
        if start1 > 0 then
          if xnotes && ynotes then
            results << 
              "#{xnotes[start1]}#{end1 > start1 ? ",#{xnotes[end1]}" : ""}c#{ynotes[start2]}#{end2 > start2 ? ",#{ynotes[end2]}" : ""}#{lines1}\n---#{lines2}\n"
          else
            results << 
              "#{start1}#{end1 > start1 ? ",#{end1}" : ""}c#{start2}#{end2 > start2 ? ",#{end2}" : ""}#{lines1}\n---#{lines2}\n"
          end
          start1 = 0
          start2 = 0
        else
          # save it till later!
          # results << "#{lineno1}a#{start2},#{end2}#{lines2}\n"
        end
    end
  end
  
  # anything left over?
  if start1 > 0 then
    if xnotes && ynotes then
      results << "#{xnotes[start1]}#{end1 > start1 ? ",#{xnotes[end1]}" : ""}d#{ynotes[lineno2]}#{lines1}\n"
    else
      results << "#{start1}#{end1 > start1 ? ",#{end1}" : ""}d#{lineno2}#{lines1}\n"
    end
  elsif start2 > 0 then
    if xnotes && ynotes then
      results << "#{xnotes[lineno1]}a#{ynotes[start2]}#{end2 > start2 ? ",#{ynotes[end2]}" : ""}#{lines2}\n"
    else
      results << "#{lineno1}a#{start2}#{end2 > start2 ? ",#{end2}" : ""}#{lines2}\n"
    end
  end
        
  return results
end  # diff


def lcs(x, y)
  results = []
  diffs = diff_main(x, y)
  
  diffs.each do |typ, items|
    case typ
      when EQUAL
        results += items
      when DELETE
      when INSERT
    end
  end
  
  return results
end  # lcs


# === main ========
if $0 == __FILE__ then
  xin = File.open(ARGV[0], "r:UTF-8")
  yin = File.open(ARGV[1], "r:UTF-8")
  
  x = []
  while line = xin.gets do x << line.chomp end  # crc32(line) end   # line.chomp end
  y = []
  while line = yin.gets do y << line.chomp end  # crc32(line) end   # line.chomp end
  
  xin.close
  yin.close
  
  puts diff(x, y)
  
end    

