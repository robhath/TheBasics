#!ruby


class Array

  def binary_search(target)
    lo = 0
    hi = self.length - 1
    
    while lo <= hi do
      m = (lo + hi)>>1 #/2
      test = self[m] <=> target
      if test < 0 then
        lo = m + 1
      elsif test > 0 then
        hi = m - 1
      else
        return self[m]
      end
    end  # while
    return nil
  end  # bsearch()
  
end  # class Array


if __FILE__ == $0 then

  if ARGV.length < 2 then
    puts "syntax: binary_search.rb <value> <file>"
    exit
  end
  
  things = []
  File.open(ARGV[1], "r") do |input|
    while line = input.gets do
        if line =~ /^\s*#/ then
          # ignore comment
        elsif line =~ /^\s*$/ then
          # ignore blank line
        else
          things << line.chomp
        end
    end
  end
  
  r = things.binary_search(ARGV[0])
  if r.nil? then
    puts "(not found)"
  else
    puts "found #{r}"
  end
  
end
