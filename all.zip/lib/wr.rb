#!ruby

if __FILE__ == $0 then
  $LOAD_PATH << File.dirname($0)
end


require 'webrick'
include WEBrick

def serve(port = 8000, what = File.join(Dir.pwd, "/html"))
  s = HTTPServer.new(Port: port, DocumentRoot: what)
  trap("INT") { s.shutdown }
  s.start
end



if __FILE__ == $0 then
  serve
end
