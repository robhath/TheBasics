#!ruby

class Card

  attr_accessor :rank   # Integer
  attr_accessor :suit   # Integer
  attr_accessor :value  # Array of Integer

  RANKS = %w{ Ace Two Three Four Five Six Seven Eight Nine Ten Jack Queen King }  
  SUITS = %w{ Spades Clubs Diamonds Hearts }
  VALUES = [[1, 11], [2], [3], [4], [5], [6], [7], [8], [9], [10], [10], [10], [10]]


  # initialize: Create a Card instance
  # @param   rank      the card's rank [Integer] (see RANKS)
  # @param   suit      the card's suit [Integer] (see SUITS)
  # @param   value     the card's value in Blackjack [Array of Integer] (see VALUES)
  # @return            Card (instance)
  def initialize(rank, suit, value = nil)
    @rank = rank
    @suit = suit
    @value = (value.nil? ? VALUES[rank] : value)
  end


  # to_s: Convert this node to a string representation.
  # @return  [String]  the string representation
  def to_s
    "#{RANKS[@rank]} of #{SUITS[@suit]}"
  end

  # <=>: 
  # @param   b         the other card compared 
  # @return            -1, 0, +1 if a < b, a = b, a > b
  def <=>(b)
    self.rank <=> b.rank
  end  # <=>

end # Card


class Deck < Array

  attr_accessor :flushness
  attr_accessor :straightness
  attr_accessor :combos


  def how_straight?
    result = []
    if self.length > 1 then
      d = self.sort
      prev_rank = d[0].rank
      result << [d[0]]
      d[1..-1].each do |card|
        if card.rank == (prev_rank + 1) then
          result[-1] << card
        else
          result << [card]
        end
        prev_rank = card.rank
      end
      # allow for wrap-around...
      if (d[-1].rank == (d[-1].class::RANKS.length - 1)) && (d[0].rank == 0) then
        # remove ace from first group and put it in last group...
        result[-1] << result[0].shift
        result.shift if result[0].empty?
      end
    end
    result.sort! {|a,b| b.length <=> a.length }  # put the largest group at the beginning
    # result.unshift [result[0].length]  # put size of largest group at beginning
    return result
  end  # how_straight?


  def how_flush?
    suit_cards = {}
    self.each do |card|
      # cs = card.class::SUITS[card.suit]  # use string assoc. with suit
      cs = card.suit
      if suit_cards.has_key?(cs) then
        suit_cards[cs] << card
      else
        suit_cards[cs] = [card]
      end
    end
    a = suit_cards.values
    a.sort! {|a,b| b.length <=> a.length }  # sort (decreasing) by number of cards in group
    # a.unshift [a[0].length]  # put size of largest group at beginning
    return a
  end  # how_flush?


  def what_combos?
    rank_cards = {}
    self.each do |card|
      # cr = card.class::RANKS[card.rank]  # use string assoc. with rank
      cr = card.rank
      if rank_cards.has_key?(cr) then
        rank_cards[cr] << card
      else
        rank_cards[cr] = [card]
      end
    end
    a = rank_cards.values
    a.sort! {|a,b| b.length <=> a.length }  # sort (decreasing) by number of cards in group
    # a.unshift [a[0].length]  # put size of largest group at beginning
    return a
  end  # what_combos?


  def look
    @flushness = self.how_flush?
    @straightness = self.how_straight?
    @combos = self.what_combos?
  end  # look


  def to_s
    self.join(", ")
  end

end  # Deck


class PokerDeck < Deck

  attr_accessor :value          # i.e. based on odds against and high card
  attr_accessor :description

  MAX_VALUE = (8 * Card::RANKS.length) + Card::RANKS.length


  def initialize(create_cards = true)
    super()
    if create_cards then
      Card::RANKS.each_index do |r|
        Card::SUITS.each_index do |s|
          self << Card.new(r, s, Card::VALUES[r])
        end
      end
    end
  end


  def evaluate(discards = nil)
    # calculate value/description of hand and discard cards if discard deck given...
    #   returns how many cards discarded
    #

    the_ranks = self[0].class::RANKS  # assumes all cards of same type
    ranks_length = the_ranks.length
    look()
    how_many = 0

    if @straightness[0].length > 4 &&
       @flushness[0].length > 4 then
      # >>> a straight flush, stand pat!
      if @straightness[0].last.rank == 0 then
        # ace high...
        @description = "a royal flush"
      else
        @description = "a straight flush"
      end
      @value = (8 * ranks_length) + (@straightness[0][0].rank == 0 ? ranks_length : @straightness[0][0].rank)
    
    elsif @combos[0].length > 3 then
      # >>> four of a kind, stand pat!
      @description = "four of a kind"
      @value = (7 * ranks_length) + (@combos[0][0].rank == 0 ? ranks_length : @combos[0][0].rank)
    
    elsif @combos[0].length == 3 &&
          @combos[1].length == 2 then
      # >>> a full house, stand pat!
      @description = "a full house"
      @value = (6 * ranks_length) + (@combos[0][0].rank == 0 ? ranks_length : @combos[0][0].rank)
    
    elsif @flushness[0].length > 4 then
      # >>> a flush, stand pat!
      @description = "a flush"
      @value = (5 * ranks_length) + (@straightness[0][0].rank == 0 ? ranks_length : @straightness.last.last.rank)
    
    elsif @straightness[0].length > 4 then
      # >>> a straight, stand pat!
      @description = "a straight"
      @value = (4 * ranks_length) + (@straightness[0].last.rank == 0 ? ranks_length : @straightness[0].last.rank)
    
    elsif @combos[0].length == 3 then
      # >>> three of a kind, discard up to 2...
      @description = "three of a kind"
      @value = (3 * ranks_length) + (@combos[0][0].rank == 0 ? ranks_length : @combos[0][0].rank)
      if !discards.nil? && @combos.length > 1 then
        @combos[1..-1].each do |a|
          a.each do |card|
            if card.rank < 10 || card.rank != 0 then 
              # neither ace nor face...
              how_many += 1
              discards << self.delete(card)
            end
          end
        end
      end
    
    elsif @combos[0].length == 2 &&
          (@combos[1] && @combos[1].length == 2) then
      # >>> two pairs, discard 1 if not an ace...
      @description = "two pairs"
      @value = 0  # to start
      @combos[0..1].each do |a|
        v = (2 * ranks_length) + (a[0].rank == 0 ? ranks_length : a[0].rank)
        @value = v if v > @value
      end
      if !discards.nil? then
        @combos[2..-1].each do |a|
          a.each do |card|
            if card.rank != 1 then
              how_many += 1
              discards << self.delete(card)
            end
          end
        end
      end
    
    elsif !discards.nil? &&
          @flushness[0].length > 3 &&
          @flushness.length > 1 then
      # try to draw to a flush (should be discard 1)...
      @description = "hoping for a flush"
      # hand's value is nothing, so use high card's value for hand's value...
      @value = (@straightness[0][0].rank == 0 ? ranks_length : @straightness.last.last.rank)
      if @flushness.length > 1 then
        @flushness[1..-1].each do |a|
          a.each do |card|
            how_many += 1
            discards << self.delete(card)
          end
        end
      end
    
    elsif !discards.nil? && 
          @straightness[0].length > 3 &&
          @straightness.length > 1 then
      # try to draw to a straight (should be discard 1)...
      @description = "hoping for a straight"
      # hand's value is nothing, so use high card's value for hand's value...
      @value = (@straightness[0][0].rank == 0 ? ranks_length : @straightness.last.last.rank)
      @straightness[1..-1].each do |a|
        a.each do |card|
          how_many += 1
          discards << self.delete(card)
        end
     end   
    
    elsif @combos[0].length == 2 then
      # >>> a pair, discard up to 3 if not ace's...
      @description = "a pair"
      @value = ranks_length + (@combos[0][0].rank == 0 ? ranks_length : @combos[0][0].rank)
      if !discards.nil? && @combos.length > 1 then
        @combos[1..-1].each do |a|
          a.each do |card|
            if card.rank != 1 then
              how_many += 1
              discards << self.delete(card)
            end
          end
        end
      end
    
    else
      # >>> nada, discard lowest three...
      a = self.sort
      @description = "nothing"
      @value = (a[0].rank == 0 ? ranks_length : a.last.rank)  # odds: 0 
      if !discards.nil? then
        a.each do |card|
          how_many += 1
          discards << self.delete(card) 
          break if how_many >= 3
        end
      end
    end

    return how_many 
  end  # evaluate


end # PokerDeck


class BlackJackDeck < Deck

  attr_accessor :values

  def initialize(create_cards = true)
    super()
    if create_cards then
      Card::RANKS.each_index do |r|
        Card::SUITS.each_index do |s|
          self << Card.new(r, s, Card::VALUES[r])
        end
      end
    end
  end


  def what_values?
    # for Blackjack
    result = [0]
    self.each do |card|
      prev_result = Array.new(result)
      len = result.length
      card.value.each_index do |i|
        result += prev_result if i > 0 
        len.times do |j|
          result[(i * len) + j] += card.value[i]
        end
      end
    end
    result.uniq! if result.length > 1
    return result
  end  # what_values?


  def look
    @values = self.what_values?   # for Blackjack
  end  # look


end # BlackJackDeck


class PokerPlayer

  attr_accessor :name         # String
  attr_accessor :human        # Boolean (if false then computer plays their hand)
  attr_accessor :purse        # Integer > 0
  attr_accessor :hand         # PokerDeck
  attr_accessor :active       # Boolean (if false then player folded)
  attr_accessor :bluffing     # Boolean (if true then player will bet more than hand value indicates)
  attr_accessor :current_bet  # Integer

  def initialize(name, purse, hand = PokerDeck.new(false))
    @name = name
    @purse = purse
    @hand = hand
  end

  def show_hand
    result = ""
    @hand.each_index {|i| result << "[#{(i + 1).to_s}] #{@hand[i]}  " }
    return result
  end  # show_hand

end  # Player

