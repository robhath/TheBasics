

class Restructured
  
  TITLE_RE = /^([^0-9A-Za-z])\1+$/
  
  ENUM_PERIOD_RE = /^(\s*)(\#|\d+|[A-Za-z]{1,2}|[CILMVXcilmvx]+)\.\s/
  ENUM_PAREN_RE = /^(\s*)\(?(\#|\d+|[A-Za-z]{1,2}|[CILMVXcilmvx]+)\)\s/
  
  BULLET_RE = /^(\s*)([-+*•])\s/
  
  GRID_TABLE_RE = /^(\s*)\+-[-+]+\+\s*$/
  GRID_TABLE_HDR_RE = /^(\s*)\+=[=+]+\+\s*$/
  
  
  def initialize()
    @line = 1
    @column = 1
    @context = []
    @table_pattern = ""
  end  # initialize
  
    
  def each_chunk(f)
    buffer = []
    in_literal = false
    in_table = false
    @line = 0; @column = 1
    
    while line = f.gets do
      @line += 1
      
      if line =~ /^\s*\.\.\s+/ then
        # enter new literal...
        #   first process anything seen prior
        yield buffer unless buffer.empty?
        buffer.clear
        buffer << line
        in_literal = true
      elsif in_literal then
        if line =~ /^\S/ then
          # literal ends when we see an un-indented, non-blank line...
          yield buffer unless buffer.empty?
          buffer.clear
          in_literal = false
          redo
        else
          buffer << line
        end
      elsif in_table then
        if line =~ /^\s*$/ then
          # table ends when we see a blank line...
          yield buffer unless buffer.empty?
          buffer.clear
          in_table = false
          @table_pattern = ""
          redo
        else
          buffer << line
        end
      elsif line =~ GRID_TABLE_RE then
        $stderr.puts line
        # enter new table...
        tp = $&  # table pattern...
        #   first process anything seen prior
        yield buffer unless buffer.empty?
        buffer.clear
        buffer << line
        in_table = true
        @table_pattern = tp
      elsif line =~ /::\s*$/ then
        yield buffer unless buffer.empty?
        buffer.clear
        buffer << line
        in_literal = true
      else
        if line =~ /^\s*$/ then
          # "blank" line...
          yield buffer unless buffer.empty?
          buffer.clear
        elsif line =~ TITLE_RE then
          # title...
          buffer.unshift line  # !!! so defining line is first
          yield buffer unless buffer.empty?
          buffer.clear
        else
          buffer << line
        end
      end
    end  # while
    yield buffer unless buffer.empty?
  end  # each_chunk
  
  
  def parse(f)
    in_literal = false
    in_table = false
    @context.clear
    @context << ["", BLANK, ""]  # [indent, type, tag]
    @line = 0
    
    while line = f.gets do
      @line += 1
      
      if line =~ /^(\s*)\.\.\s+/ then
        # enter new literal...
        indent = $1
        self.method(BLANK).call ""  # but first, act as if we saw a blank line
        in_literal = true
        @context << [indent, DIRECTIVE, ""]
      elsif in_literal then
        if line =~ /^\S/ then
          # literal ends when we see an un-indented, non-blank line...
          self.method(BLANK).call ""  # as if we saw a blank line
          in_literal = false
          @context << ["", BLANK, ""]
          @line -= 1
          redo
        end
      elsif in_table then
        if line =~ /^\S/ then
          # table ends when we see an un-indented, non-blank line...
          self.method(BLANK).call ""  # as if we saw a blank line
          in_table = false
          @context << ["", BLANK, ""]
          @line -= 1
          @table_pattern = ""
          redo
        end
      elsif line =~ GRID_TABLE_RE then
        # enter new table...
        indent = $1
        tp = $&
        self.method(BLANK).call ""  # but first, act as if we saw a blank line
        in_table = true
        @context << [indent, TABLE, ""]
        @table_pattern = tp
      elsif line =~ /^(\s*).*::\s*$/ then
        indent = $1
        self.method(BLANK).call ""  # as if we saw a blank line
        in_literal = true
        @context << [indent, LITERAL, ""]
      else
        case line
          when /^\s*$/ then
            # "blank" line...
            @context << ["", BLANK, ""]
            #~ next
            
          when TITLE_RE then
            # title...
            @context << ["", TITLE, ""]
          
          when ENUM_PERIOD_RE,
                    ENUM_PAREN_RE then
            # enumerated list using period...
            # enumerated list using parens (single or double)...
            # NOTE: separate items may be included (i.e. no blank line was inserted between items in list)!
            @context << [$1, ENUM_LIST, ""]
          
          when BULLET_RE then
            # bullet list...
            # NOTE: separate items may be included (i.e. no blank line was inserted between items in list)!
            @context << [$1, BULLET_LIST, ""]
            
          when /^(\s*)(-{1,2}\S+),?\s+\S/,
                    /^(\s*)(\/\S+),?\s+\S/ then
            # option list...
            # option list, DOS-style...
            # NOTE: separate items may be included (i.e. no blank line was inserted between items in list)!
            @context << [$1, OPTION_LIST, ""]
            
          when /^(\s*)(:([^:]|\\:)+:)\s/ then
            # field list...
            @context << [$1, FIELD_LIST, ""]
            
          when /^(\s+)/ then
            # indented line...
            #~ $stderr.puts "indented"
            indent = $1
            if @context.last == BLANK then
              @context << [indent, BLOCK_QUOTE, ""]
            elsif @context.last == PARAGRAPH then
              @context << [indent, DEFN_LIST, ""]
            end
          
          when /^\S/ then
            @context << ["", PARAGRAPH, ""] #if @context.last == BLANK
        end  # case
      end  # if
      
      self.method(@context.last[1]).call line if @context.last
    end  # while
  end  # parse()
  
  
  def process(f)
    @context.clear
    @context << ["", BLANK, ""]
    each_chunk(f) do |buffer|

      indent = (buffer.first =~ /^(\s+)/ ? $1 : "")  # indentation...
      
      case buffer.first
        
        when /^(\s*)\.\.\s+/ then
          # literal, comment, directive, footnote, citataion, hyperlink target, substitution definition...
          @context << [indent, DIRECTIVE, ""]
          
        when /^(\s*).*::\s*$/ then
          # literal block, construct, ...
          @context << [indent, LITERAL, ""]
          
        when ENUM_PERIOD_RE,
                  ENUM_PAREN_RE then
          # enumerated list using period...
          # enumerated list using parens (single or double)...
          # NOTE: separate items may be included (i.e. no blank line was inserted between items in list)!
          @context << [indent, ENUM_LIST, ""]
        
        when BULLET_RE then
          # bullet list...
          # NOTE: separate items may be included (i.e. no blank line was inserted between items in list)!
          @context << [indent, BULLET_LIST, ""]
          
        when /^(\s*)(-{1,2}\S+),?\s+\S/,
                  /^(\s*)(\/\S+),?\s+\S/ then
          # option list...
          # option list, DOS-style...
          # NOTE: separate items may be included (i.e. no blank line was inserted between items in list)!
          @context << [indent, OPTION_LIST, ""]
          
        when TITLE_RE then
          # title...
          @context << ["", TITLE, ""]
          
        when GRID_TABLE_RE then
          # table...
          @context << [indent, TABLE, ""]
          @table_pattern = $&
          
        else
          
          if buffer.first =~ /^(\s*)(:([^:]|\\:)+:)\s/ then
            # field list...
            @context << [indent, FIELD_LIST, ""]
            
          elsif buffer[1] then
            indent2 = (buffer[1] =~ /^(\s+)/  ? $1 : "")
            if indent2.length > indent.length then
              # definition list!?...
              @context << [indent, DEFN_LIST, ""]
            else
              # paragraph (multi-line)...
              @context << [indent, PARAGRAPH, ""]
            end
            
          elsif indent.length > 0 then
            # block quote...
            @context << [indent, BLOCK_QUOTE, ""]
            
          else
            # paragraph...
            @context << [indent, PARAGRAPH, ""]
            
          end
        end  # case
        
      do_context_switch buffer.join if @context[-1][0..1].join != @context[-2][0..1].join
      self.method(@context.last[1]).call buffer.join if @context.last
      #~ $stderr.puts "#{buffer}\n"  # debugging
      
    end  # each_chunk
  end  # process()
  
  
  @@quote_chars = ["``", "`", "\\|", ":"]
  
  @context = []  # what we have seen, so far
  
  DIRECTIVE = :do_directive
  LITERAL = :do_literal
  ENUM_LIST = :do_enum_list
  BULLET_LIST = :do_bullet_list
  OPTION_LIST = :do_option_list
  TITLE = :do_title
  FIELD_LIST = :do_field_list
  DEFN_LIST = :do_defn_list
  BLOCK_QUOTE =:do_block_quote
  PARAGRAPH = :do_paragraph
  BLANK = :do_blank
  TABLE = :do_table


  def do_context_switch(line)
    $stderr.puts "context_switch" + line
  end  # do_context_switch
  

  def do_directive(line)
    $stderr.puts "directive/literal:\n" + line
  end  # do_directive
  
  
  def do_literal(line)
    $stderr.puts "literal block/construct:\n" + line
  end  # do_literal
  
  
  def do_enum_list(line)
    $stderr.puts "enumerated list:\n" + line
  end  # do_enum_list
  
  
  def do_bullet_list(line)
    $stderr.puts "bullet list:\n" + line
  end  # do_bullet_list
  
  
  def do_option_list(line)
    $stderr.puts "option list:\n" + line
  end  # do_option_list
  
  
  def do_title(line)
    # TODO: backtrack (previous line was really the title)
    $stderr.puts "title:\n" + line
  end  # do_title
  
  
  def do_field_list(line)
    $stderr.puts "field list:\n" + line
  end  # do_field_list
  
  
  def do_defn_list(line)
    # TODO: backtrack (previous line was the term)
    $stderr.puts "definition list:\n" + line
  end  # do_defn_list
  
  
  def do_block_quote(line)
    $stderr.puts "block quote:\n" + line
  end  # do_block_quote
  
  
  def do_paragraph(line)
    $stderr.puts "paragraph:\n" + line
  end  # do_paragraph
  
  
  def do_blank(line)
    $stderr.puts "blank"
  end  # do_blank
  
  
  def do_table(line)
    $stderr.puts "table"
  end  # do_table
  
end  # Restructured

