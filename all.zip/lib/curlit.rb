#!ruby
# encoding: UTF-8



  def curlit(operation: "GET", endpoint: "/greengrass/things/{ThingName}/connectivityInfo",
             path_params: {"ThingName" => "foobar"}, accept: "application/json",
             content: "application/json", payload: "",
             payload_params: {"thingArn" => "yoicks!"})
    
    ep = endpoint.gsub(/\{[^{}\s]+\}/) do |str|
      path_params[str[1..-2]] || str
    end
    pay = payload.gsub(/\{[^{}\s]+\}/) do |str|
      $stderr.puts str
      payload_params[str[1..-2]] || str
    end

    whole_payload = ""
    unless pay.empty? then
      pay.gsub!(/\s+/, " ")
      pay.strip!
      pay.gsub!("\"", "\\\"")
      whole_payload = "-H \"Content-Type: #{content}\" -d \"#{pay}\"" 
    end
    
    return "curl -X #{operation} \"#{ep}\" -H \"accept: #{accept}\" #{whole_payload}"
  end  # curlit


# === main ========
if $0 == __FILE__ then
  json_example = <<EOS
{
  "Name": "string",
  "InitialVersion": {
    "Subscriptions: [
      {
        "Id": "{thingArn}",
        "Source": "string",
        "Subject": "string",
        Target": "string"
      }
    ]
  }
}
EOS
 
  str = curlit(payload: json_example) 
  
  puts str
  
end    

