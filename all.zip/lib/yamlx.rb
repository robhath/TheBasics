#!ruby


class Hash

  def at(path)
    result = self
    new_key = ""
    a = path.split(/\/|\./)
    a.each do |p|
      if result.nil? then
        break
      elsif p.empty? || p == "#" then
        next
      else
        new_key = String.new(p)
        result = result.fetch(p, nil)
      end
    end
    return { new_key => result }
  end  # at
  
  
  def walk(&block)
    #~ $stderr.puts "Hash::walk()"
    self.each_pair do |key, value|
      yield key, value
      if value.respond_to?(:each) then
        value.walk(&block)
      end
    end
  end  # walk
  
  
  def cwalk(context, &block)
    #~ $stderr.puts "Hash::cwalk(#{context.join(",")})"
    self.each_pair do |key, value|
      context << key
      yield key, value, context
      if value.respond_to?(:each) then
        value.cwalk(context, &block)
      end
      context.pop
    end
  end  # cwalk
  
  
  def copy()
    #~ $stderr.puts "Hash::copy()"
    result = {}
    self.each_pair do |key, value|
      result[key] = (value.respond_to?(:copy) ? value.copy : (value.respond_to?(:chars) ? String.new(value) : value))
    end
    return result
  end  # copy
  
  
  
  def canonical_copy()
    #~ $stderr.puts "Hash::canonical_copy()"
    result = {}
    a = self.sort {|x, y| x[0] <=> y[0] }  # sort on key
    a.each do |key, value|
      result[key] = (value.respond_to?(:canonical_copy) ? value.canonical_copy : (value.respond_to?(:chars) ? String.new(value) : value))
    end
    return result
  end  # canonical_copy
  
end  # Hash


class Array
  
  def walk(&block)
    #~ $stderr.puts "Array::walk()"
    self.each do |obj|
      yield nil, obj
      if obj.respond_to?(:each) then
        obj.walk(&block)
      end
    end
  end  # walk
  
  
  def cwalk(context, &block)
    #~ $stderr.puts "Array::cwalk(#{context.join(",")})"
    self.each_index do |i|
      context << i
      obj = self[i]
      yield i, obj, context
      if obj.respond_to?(:each) then
        obj.cwalk(context, &block)
      end
      context.pop
    end
  end  # cwalk
  
  
  def copy()
    #~ $stderr.puts "Array::copy()"
    result = []
    self.each do |obj|
      result << (obj.respond_to?(:copy) ? obj.copy : (obj.respond_to?(:chars) ? String.new(obj) : obj))
    end
    return result
  end  # copy
  
  
  def canonical_copy()
    #~ $stderr.puts "Array::canonical_copy()"
    result = []
    tempa = []
    
    self.each_index {|i| tempa << [i, self[i].to_s] }
    tempa.sort! {|a, b| a[1] <=> b[1] }
    
    tempa.each do |i, str|
      result << (self[i].respond_to?(:canonical_copy) ? self[i].canonical_copy : (self[i].respond_to?(:chars) ? String.new(self[i]) : self[i]))
    end
    return result
  end  # canonical_copy
  
end  # Array




if __FILE__ == $0 then
  require 'yaml'
  require 'json'

  ARGV.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{json,txt,yaml,yml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $stderr.puts fn
  
      y = YAML.load_file(fn)
      if y.nil? || !y || y.empty? then
        $stderr.puts "    something's wrong... skipping file!"
        next
      end
      
      y.walk do |key, value|
        $stderr.puts "key=#{key} value=#{(value.respond_to?(:each) ? "..." : value.to_s)}"
      end
      
    end
  end
end
