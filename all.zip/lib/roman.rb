
class Integer

  FACTORS = [[1000, "M"], [900, "CM"], [500, "D"], [400, "CD"],
             [100, "C"], [90, "XC"], [50, "L"], [40, "XL"],
             [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]]

  def int2roman()
    result = ""
    n = self
    FACTORS.each do |f, str|
      q, r = n.divmod(f)
      result << (str * q) if q > 0
      n = r
    end 
    return result
  end  # int2roman

end  # Integer



class String

  def roman2int()
    result = 0
    rstr = self.upcase
    result += rstr.count("M") * 1000
    result += rstr.count("D") * 500
    result += rstr.count("C") * 100
    result += rstr.count("L") * 50
    result += rstr.count("X") * 10
    result += rstr.count("V") * 5
    result += rstr.count("I")
  
    result -= 200 if rstr =~ /CM/
    result -= 200 if rstr =~ /CD/
    result -= 20 if rstr =~ /XC/
    result -= 20 if rstr =~ /XL/
    result -= 2 if rstr =~ /IX/
    result -= 2 if rstr =~ /IV/
    return result
  end
end  # String

