
class String

  def alpha_to_int()
    result = 0
    factor = 1
    self.downcase.codepoints.reverse_each do |n|
      result += ((n - 96) * factor)
      factor *= 26
    end
    return result
  end  # alpha_to_int
  
end  # String


class Integer
  
  def int_to_alpha(lcase = true)
    result = ""
    n = self
    factor = 26
    while n > 0 do
      q,r = n.divmod(26)
      if r == 0 then
        q -= 1
        r = 26
      end
      result.prepend (r + (lcase ? 96 : 64)).chr
      n = q
    end
    #~ while n >= 26 do
      #~ q, r = n.divmod(26)
      #~ result.prepend (r  + (lcase ? 97 : 65)).chr
      #~ n = q
    #~ end
    #~ n -= 1 if !result.empty? && 
    #~ result.prepend (n + (lcase ? 97 : 65)).chr
    return result
  end
  
end  # Integer
