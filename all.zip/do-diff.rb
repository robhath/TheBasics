#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'
require 'diff.rb'


def do_it(advance: true, command: {}, original: [])
  if advance then
    if command["acd"] == "a" then
      # add it...
      original.insert(command["bstart"] - 1, *command["bbody"])
    elsif command["acd"] == "c" then
      # add first...
      original.insert(command["bstart"] - 1, *command["bbody"])
      # then subtract...
      original.slice!(command["bend"], (command["aend"] - command["astart"] + 1))
    elsif command["acd"] == "d" then
      # delete it...
      original.slice!(command["bstart"], (command["aend"] - command["astart"] +1))
    end
  else 
    if command["acd"] == "a" then
      # delete it...
      original.slice!(command["astart"], (command["bend"] - command["bstart"] + 1))
    elsif command["acd"] == "c" then
      # add first...
      original.insert(command["astart"] - 1, *command["abody"])
      # then delete...
      original.slice!(command["aend"], (command["bend"] - command["bstart"] + 1))
    elsif command["acd"] == "d" then
      # add it...
      original.insert(command["astart"] - 1, *command["abody"])
    end
  end
end  # do_it



if __FILE__ == $0 then
  
  get_args(min: 1, syntax: "do-diff.rb < diff-file > output-file <original-file>  [-advance|-rewind]")

  if $args["-rewind"] then
    $stderr.puts "Diff Rewind  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    $stderr.puts "=================================="
  else
    $stderr.puts "Diff Advance  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    $stderr.puts "==================================="
  end

  # get original file...
  original = [] 
  File.open($nargs[0], "r") {|input| while line = input.gets do original << line.chomp end }

  command = { "abody" => [], "bbody" => [] }

  # get diff file from stdin...
  while line = $stdin.gets do
    if line =~ /^(\d+)(,(\d+))?(a|c|d)(\d+)(,(\d+))?\s*$/ then
      # grab the parts...
      astart = $1.to_i
      aend = ($3 || $1).to_i
      acd = $4
      bstart = $5.to_i
      bend = ($7 || $5).to_i

      # do previous, if any...
      do_it(advance: ($args["-advance"] || !$args["-rewind"]), command: command, original: original)

      # start a new one...
      command["astart"] = astart 
      command["aend"] = aend
      command["acd"] = acd
      command["bstart"] = bstart 
      command["bend"] = bend
      command["abody"].clear
      command["bbody"].clear

    elsif line =~ /< (.+)/ then
      command["abody"] << $1

    elsif line =~ /> (.+)/ then
      command["bbody"] << $1

    end
  end

  # do last remaining, if any...
  do_it(advance: ($args["-advance"] || !$args["-rewind"]), command: command, original: original)

  # output changed original to stdout...
  original.each {|line| puts line }

end
