#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'
require 'diff.rb'

if __FILE__ == $0 then
 
syntax_text = <<EOS
def2ent.rb - convert entity definitions to entities
  | parameter                            | description (default) [Optional/Required]               |
  | ------------------------------------ | ------------------------------------------------------- |
  | <file-or-directory-name>...          | wsl of files or dirs to modify (.) [O]                  |
  | -ent <list of entity-def-files/dirs> | csl of files or dirs (*.ent) with entity definitions    |
  |                                      |  ("#{ENV["HOME"]}/bin/lib/entities.min.txt") [O]        |
  | -ext <file-extensions>               | csl of extensions of files to modify (html,xml) [O]     |
  | -diff (yes|diff-file-name)           | make diff? or diff filename ("diff.def2ent.txt") [O]    |
  | -pre <entity-prefix>                 | string used as created entity prefix ("&") [O]          |
  | -post <entity-postfix>               | string used as created entity postfix (";") [O]         |
  | --chgs                               | ? show unique list of changes made [O]                  |
  | --ow                                 | ? overwrite modified files, o/w create .new files [O]   |
  | --recurse                            | ? expand entities in entity defs one time [O]           |
  | --i                                  | ? make entity definition regex's case-insensitive [O]   |
  | --m                                  | ? make entity definition regex's multi-line [O]         |
  | --x                                  | ? make entity definition regex's extended syntax [O]    |
  | --help                               | ? output this help text and exit [O]                    |
EOS
 
  get_args(min: 0, nmin: 0, syntax: syntax_text)
  files = []
  changed_files = []
  extensions = $args["-ext"] || "html,xml"
  diff_file = nil
  diff_out = nil
  the_changes = ($args["--chgs"] ? Array.new : nil)
  if $args["-diff"] then
    diff_file = ($args["-diff"] == "yes" ? "diff.def2ent.txt" : $args["-diff"])
  end

  if $nargs.empty? then
    files += Dir.glob("./**/*.{#{extensions}}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{#{extensions}}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{#{extensions}}")
       else
         files << narg
       end
     end  # $nargs.each
  end
  entity_prefix = ($args["-pre"] || "&")
  entity_postfix = ($args["-post"] || ";")

  options = nil
  options = (options ? options | Regexp::MULTILINE : Regexp::MULTILINE) if $args["--m"] 
  options = (options ? options | Regexp::IGNORECASE : Regexp::IGNORECASE) if $args["--i"] 
  options = (options ? options | Regexp::EXTENDED : Regexp::EXTENDED) if $args["--x"] 
  not_defined = []
  edefinitions = {"AWS" => "AWS"}
  edef_files = []
  if $args["-ent"] then
    $args["-ent"].split(",") do |edef_fn|
      if edef_fn == "." then
        edef_files += Dir.glob("./**/*.ent")
      elsif File.directory?(edef_fn) then
        edef_files += Dir.glob("#{edef_fn.gsub("\\", "/")}/**/*.ent")
      else
        edef_files << edef_fn
      end
    end 
  else
    edef_files << "#{ENV["HOME"]}/bin/lib/entities.min.txt"
  end
  edef_files.each do |edef_fn|
    # $stderr.puts "edef_fn[#{edef_fn}]"  # debug
    File.open(edef_fn, "r") do |input|
      buffer = input.read
      if buffer[0..255] =~ /^:[\w_-]+:\s+/ then
        pos = 0
        remainder = ""
        while pos = (buffer =~ /^\s*:([\w_-]+):\s+(.+?)$/) do
          remainder = $'
          key = String.new($1)
          value = String.new($2)
          # $stderr.puts "1[#{$1}] 2[#{$2}]"
          $stderr.puts "duplicate definition found for '#{key}'" if edefinitions[key]
          edefinitions[key] = value
          buffer = remainder
        end
      else
        pos = 0
        remainder = ""
        while pos = (buffer =~ /<!ENTITY\s*(\S+)\s*('|")([^\2]*?)\2\s*>/) do
          remainder = $'
          key = String.new($1)
          value = String.new($3)
          # $stderr.puts "1[#{$1}] 2[#{$2}] 3[#{$3}]"  # debug
          $stderr.puts "duplicate definition found for '#{key}'" if edefinitions[key]
          edefinitions[key] = value
          buffer = remainder
        end
      end
    end
  end
  # if --recurse parameter given, find all entities in the entity definitions and try to resolve those...
  if $args["--recurse"] then
    edefinitions.each_value do |value|
      value.gsub!(/#{entity_prefix}([^#{entity_prefix}\s#{entity_postfix}]+)#{entity_postfix}/) do |str|
        definition = $1
        if edefinitions[definition] then
          edefinitions[definition]
        else
          not_defined << definition unless not_defined.include?(definition)
          str
        end
      end
    end
  end
  # replace all definition strings with regular expressions...
  edefinitions.each do |key, value|
    if options then
      edefinitions[key] = (value == "AWS" ? /\bAWS\b/ : Regexp.new(Regexp.escape(value), options))
      # edefinitions[key] = Regexp.new("((#{entity_prefix}([^#{entity_prefix}\\s#{entity_postfix}]+)#{entity_postfix})|(" + (value == "AWS" ? "\\b" : "") + Regexp.escape(value) + (value == "AWS" ? "\\b" : "") + "))", options)
    else
      edefinitions[key] = (value == "AWS" ? /\bAWS\b/ : Regexp.new(Regexp.escape(value)))
      # edefinitions[key] = Regexp.new("((#{entity_prefix}([^#{entity_prefix}\\s#{entity_postfix}]+)#{entity_postfix})|(" + (value == "AWS" ? "\\b" : "") + Regexp.escape(value) + (value == "AWS" ? "\\b" : "") + "))")
    end
  end
  # edefinitions.each {|key, value| $stderr.puts "value[#{value}]" }  # debug

  count = 0

  show_it = "Convert Definitions to their Entities: #{edefinitions.length} definitions "
  puts show_it
  puts ("-" * show_it.length)

  files.each do |f|
    buffer = String.new
    old_buffer_array = Array.new
    changed = false
    puts ">>> " + f
    buffer = ""
    File.open(f, "r") do |input|
      buffer = input.read
      old_buffer_array = buffer.split("\n") if diff_file
      edefinitions.each do |key, value|
        buffer.gsub!(value) do |str|
          # if str[0] == "#{entity_prefix}" then
          if $` =~ /#{entity_prefix}[^\s#{entity_postfix}]*$/ then
            # don't change what is already in an entity
            str
          else
            print "*"
            changed = true
            count += 1
            "#{entity_prefix}#{key}#{entity_postfix}"
          end
        end
      end
    end  # File.open

    puts
    if changed then
      changed_files << f
      File.open(f + ".new", "w") do |output|
        output.print buffer
      end

      if diff_file then
        diff_out = File.open(diff_file, "w") unless diff_out
        diff_out.puts "file: #{f}"
        diff_out.puts diff(old_buffer_array, buffer.split("\n"))
        diff_out.puts "\n\n"
      end
    end

  end  # files.each

  if $args["--ow"] then
    changed_files.each do |f|
      File.delete(f)
      File.rename(f + ".new", f)
    end
  end

  if the_changes then
    puts "\nThe following changes were made:"
    the_changes.uniq!
    puts the_changes.join("\n")
  end

  $stderr.puts "\nEntities not defined/replaced: #{not_defined.join(",")}"
  puts "\n#{count.to_s} instances replaced"
end

