#!/usr/bin/env ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'CardGames'

if __FILE__ == $0 then
  # The game is afoot...
  puts "Welcome to our poker game! Have a seat..."

  names = %w(Ada Beatrice Christine Elizabeth Frances Grace)
  print ">>>What is your name? "
  my_name = gets.chomp
  names.unshift my_name

  print ">>>How many players (besides yourself, max. 5)? "
  pnum = gets.to_i + 1
  player = []
  pnum.times do |i|
    player << PokerPlayer.new(names[i], 124)
  end
  player[0].human = true

  the_pot = 0  # money!
  prng = Random.new      # will determine if player bluffs 

  loop do

    # ante up! 
    # if a player hasn't got sufficient funds, they're out of the game...
    puts "\nAnte up!"
    outs = []
    player.each_index do |i|
      if player[i].purse < 3 then 
        outs << i
        if player[i].human then
          puts "Sorry, but you don't have sufficient funds to continue playing."
          exit 
        else
          puts "#{player[i].name} doesn't have sufficient funds to continue playing."
          puts "Goodbye, #{player[i].name}!"
        end
      else
        # player has at least one chip each for ante, first and second rounds of betting
        player[i].purse -= 1
        player[i].active = true
        the_pot += 1
      end
    end
    outs.each {|o| player.delete_at(o) }

    deck = PokerDeck.new
    discards = PokerDeck.new(false)

    deck.shuffle!

    puts "\nDealing..."
    # deal for 5-card draw...
    5.times do |i|
      pnum.times do |j|
        player[j].hand << deck.pop
      end
    end


    # discards?...
    pnum.times do |i|
      if player[i].human then
        puts "\nYou have: #{player[i].show_hand}" 
        my_discards = []
        done = false
        while !done do
          print ">>>Which card(s) # do you want to discard? (ex. '1' or '1, 2, ...', 0 to stop) "
          d = gets
          # allow for entry as list separated by commas...
          a = d.split(",")
          a.each_index do |i|
            cnum = a[i].to_i
            if cnum > 5 || cnum < 0 then
              puts "Sorry! you don't have a card ##{cnum}, try again."
              done = false
              my_discards.clear
              break
            elsif cnum == 0 then
              done = true
            else
              my_discards << cnum
              done = (i > 0)
            end
          end
        end
        my_discards.sort! {|a,b| b <=> a }
        my_discards.each do |cnum|
          discards << player[i].hand.delete_at(cnum - 1)
        end
        # second draw...
        my_discards.length.times do |j|
          player[i].hand << deck.pop
        end
        puts "You now have: #{player[i].hand.join(", ")}" 
      else
        how_many = player[i].hand.evaluate(discards)
        puts "#{player[i].name} discards #{how_many} cards"
        # second draw...
        how_many.times do |j|
          player[i].hand << deck.pop
        end
      end
    end

    player.each do |p| 
      p.current_bet = 0 
      p.hand.evaluate 
      p.bluffing = (!p.human && prng.rand(24) == 12) 
    end

    # betting...
    puts "\nPlace your bets!"
    current_bet = 0
    loop do
      # puts "The current bet is #{current_bet}."
      player.each do |p|
        if p.active then
          if p.human then
            # $stderr.puts "#{p.name}/#{p.active.to_s}: purse=#{p.purse} value=#{p.hand.value} p.current_bet=#{p.current_bet}"   # debug
            dd = current_bet - p.current_bet
            next if dd == 0 && current_bet > 0
            puts "\nYou have #{p.purse} coins in your purse."
            print ">>>The current bet is #{current_bet}. Your bet so far is #{p.current_bet}. Do you want to #{current_bet == 0 ? "[c]heck" : "[c]all"}, [r]aise, or [f]old? "
            got_it = false
            while !got_it do
              response = gets.chomp
              case response
                when /^\s*c/i then
                  p.current_bet += dd
                  p.purse -= dd
                  the_pot += dd
                  puts "#{p.name} #{current_bet == 0 ? "checks" : "calls."}"
                  got_it = true
                when /^\s*r/i then
                  print ">>>How much do you want to raise? "
                  more = gets.chomp.to_i
                  if more > 0 then
                    delta = (more + current_bet) - p.current_bet
                    if delta > 0 then
                      if p.purse >= delta then
                        current_bet += more
                        p.current_bet = current_bet
                        p.purse -= delta
                        the_pot += delta
                        puts "#{p.name} raises #{more.to_i}. The bet is now #{current_bet}."
                        got_it = true
                      else
                        puts "Sorry, you don't have sufficient funds in your purse. Do you want to [c]all, [r]aise, or [f]old? "
                      end
                    end
                  else
                    puts "Sorry, I didn't understand that. Do you want to [c]all, [r]aise, or [f]old? "
                  end
                when /^\s*f/i then
                  p.active = false
                  puts "#{p.name} folds."
                  got_it = true
                else
                  puts "I didn't get that... Do you want to #{current_bet == 0 ? "[c]heck" : "[c]all"}, [r]aise, or [f]old? "
              end
            end
          else
            best_bet = p.hand.value / (Card::RANKS.length + 1)
            best_bet *= 5 if p.bluffing
            delta = best_bet - current_bet
            delta = p.purse if delta > p.purse
            # $stderr.puts "#{p.name}/#{p.active.to_s}: purse=#{p.purse} value=#{p.hand.value} p.current_bet=#{p.current_bet} current_bet=#{current_bet} best_bet=#{best_bet} delta=#{delta} bluffing=#{p.bluffing}"   # debug
  
            if current_bet == 0 then
              if delta > 0 then
                p.current_bet += delta
                current_bet += delta
                p.purse -= delta
                the_pot += delta
                puts "#{p.name} bets #{delta}"
              else
                puts "#{p.name} checks"
              end
            elsif delta > 1 && (p.current_bet < current_bet) then
              current_bet += delta
              dd = current_bet - p.current_bet
              p.current_bet += dd
              p.purse -= dd
              the_pot += dd
              puts "#{p.name} raises #{delta.to_i}. The bet is now #{current_bet}."
            elsif delta >= 0 && (current_bet > p.current_bet) then
              dd = current_bet - p.current_bet
              p.current_bet += dd
              p.purse -= dd
              the_pot += dd
              puts "#{p.name} calls."
            elsif delta < 0 then
              puts "#{p.name} folds"
              p.active = false
            end
          end
        end
      end
      done = true
      player.each {|p| done &&= (!p.active || (p.current_bet == current_bet)) }
      break if done
    end


    puts
    winning_hand_value = 0
    winner = nil 
    player.each do |p| 
      if p.active then
        puts "#{p.name} has #{p.hand.join(", ")}"
        puts "  #{p.hand.description}"
        if p.hand.value > winning_hand_value then
          winning_hand_value = p.hand.value
          winner = p
        end
      end
    end
    
    puts "#{winner.name} wins this hand!"
    winner.purse += the_pot
    the_pot = 0

    #clean up...
    player.each {|p| p.hand.clear }  # get rid of each player's cards from the last hand (play)
    player << player.shift  # rotate

    print "\n>>>Do you want to play again? [y/n] "
    again = gets.chomp
    break if again =~ /^\s*n/i
  end  # loop

  player.each {|p| puts "#{p.name}'s purse is #{p.purse}." }
  puts "Goodbye until next time!" 
end
