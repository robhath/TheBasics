#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'


if __FILE__ == $0 then
  
  dir = "."  # by default the current directory
  tags = "mediaobject,textobject"
  error_file = nil
  error_out = nil
  edit_files = false
  do_not_found = false
  count = 0

  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^--help$/i then
        $stderr.puts "syntax:\n  find-xml-tag.rb  -d <directory>  -tags <list> --nf --edit"
        $stderr.puts "    -d <directory>         : directory to search (recursive), default= ."
        $stderr.puts "    -tags <comma-sep-list> : list of tag,sub-tag,... to find"
        $stderr.puts "    --nf                   : only report when not found"
        $stderr.puts "    --edit                 : edit files using vim"
        $stderr.puts "\n\nsimplified syntax:\n  find-xml-tag.rb"
        $stderr.puts "    defaults to: find-xml-tag.rb  -d . -tags mediaobject,textobject"
        exit
      when /^-d/i then
        i += 1
        dir = ARGV[i] if ARGV.length > i
      when /^-tags/i then
        i += 1
        tags = ARGV[i] if ARGV.length > i
      when /^--nf$/i then
        do_not_found = true
      when /^--edit$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
      end
      i += 1
  end

  title = "Find Tag: #{tags}  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts title
  puts "=" * title.length

  files = []
  extensions = "html,HTML,xml,XML"
  files += Dir.glob("#{dir}/**/*.{#{extensions}}")

  x = nil
  files.each do |arg|
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{html,xml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)

      File.open(fn, "r") {|input| x = XML.parse_p(input, (fn =~ /\.html?$/)) }
      parents = [x]
      found = []
      not_found = []
      the_tags = tags.split(",")
      this_tag = nil

      while !the_tags.empty? do
        this_tag = the_tags.shift
        found = []
        not_found = [] 
        parents.each do |y|
          y.each do |z|
            found << z if z.tag == this_tag 
          end
          not_found << y if found.empty? && !y.tag.empty?
        end
        parents = found unless the_tags.empty?
      end
      
      if do_not_found then
        puts "\n>>>File: #{fn}" unless not_found.empty?
        not_found.each do |z|
          count += 1
          puts z.pos
          if error_file then
            error_out = File.open(error_file, "w") unless error_out
            error_out.puts "#{fn}:#{z.pos}:missing #{this_tag}"
          end
        end
      else
        puts "\n>>>File: #{fn}" unless found.empty?
        found.each do |z|
          count += 1
          puts z.pos
          if error_file then
            error_out = File.open(error_file, "w") unless error_out
            error_out.puts "#{fn}:#{z.pos}:#{this_tag}"
          end
        end
      end
      
    end
  end
  
  puts "...search completed. #{count} found in all files."
  error_out.close if error_out
  if edit_files && count > 0 then
    exec "vim -q #{error_file}" 
  end
  
end
