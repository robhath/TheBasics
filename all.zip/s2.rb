#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

if __FILE__ == $0 then
  
  files = []

  re_str = ARGV[0]  # by default the first parameter
  re_options = 0
  dir = "."  # by default the current directory
  extensions = ["html", "md", "txt", "xml", "ent", "rb", "c", "h", "json", "smithy"]  # by default
  new_extensions = false
  error_file = nil
  nerror_file = nil
  error_out = nil
  nerror_out = nil
  edit_files = false
  nedit_files = false
  eask = false
  count = 0
  ncount = 0
  ignore_list = []

  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^-ext/ then
        extensions.clear unless new_extensions
        new_extensions = true
        while i < (ARGV.length - 1) && ARGV[i+1][0] != "-" do
          i += 1
          extensions << ARGV[i] 
          extensions[-1] = "*" if extensions[-1] == "all"
        end
        # extensions << $'  # following match
        # extensions[-1] = "*" if extensions[-1] == "all"
      when /^-p/i then
        i += 1
        re_str = ARGV[i] if ARGV.length > i
      when /^-d/i then
        i += 1
        dir = ARGV[i] if ARGV.length > i
      when /^-e$/i then
        i += 1
        error_file = ARGV[i] if ARGV.length > i
      when /^--edit$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
      when /^--eq$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
        eask = true
      when /^--tide$/i then
        nerror_file = "#{ENV["HOME"]}/.nsrch.err.txt"
        nedit_files = true
      when /^--i$/i then
        re_options += Regexp::IGNORECASE
      when /^--m$/i then
        re_options += Regexp::MULTILINE
      when /^--x$/i then
        re_options += Regexp::EXTENDED
      when /^[^\-]/ then
        re_str = ARGV[i]
      when /^-ignore/i then
        i += 1
        ignore_list = ARGV[i].split(',') if ARGV.length > i
      end
      i += 1
  end
  
  re = Regexp.new(re_str, re_options)
  re_file = Regexp.new("#{re_str}[^/]*$", re_options)
  # $stderr.puts re  # debug

  a = Dir.glob("#{dir}/**/#{(extensions.empty? || extensions.index("*")) ? "*" : "*.{#{extensions.join(",")}}"}")

  title = "Search re=#{re} dir=#{dir} ext=[#{extensions.join(" ")}]  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts title
  puts "ignore list [#{ignore_list.join(", ")}]" unless ignore_list.empty?
  puts "=" * title.length
  
  a.each do |fn|
    next if File.directory?(fn)

    File.open(fn, "r") do |input|  
      buffer = input.read

      found = false
      line_number = 1
      pos_in_line = 0
      prev_match_length = 0

      while pos = (buffer =~ re) do
        preceding = $`
        remainder = $'
        da_match = $&

        if !ignore_list.empty? && ignore_list.index(da_match.delete(" \t\r\n")) then
          # ignore it...
          line_number += preceding.count("\n")
          pri = preceding.rindex("\n") 
          if pri.nil? then
            pos_in_line += pos + prev_match_length
          else
            pos_in_line = pos - pri
          end
          prev_match_length = da_match.length
          buffer = remainder
          next
        end

        puts "\n>>>File: #{fn}" unless found
        found = true
        line_number += preceding.count("\n")
        pri = preceding.rindex("\n") 
        if pri.nil? then
          # $stderr.puts "prev_match_length=#{prev_match.length} pos=#{pos} pri=#{pri} preceding.length=#{preceding.length} pos_in_line=#{pos_in_line}"  # debug
          pos_in_line += pos + prev_match_length
        else
          pos_in_line = pos - pri
        end

        # $stderr.puts "da_match[#{da_match}] line_number=#{line_number.to_s} pos_in_line=#{pos_in_line} "  # debug
        count += 1
        puts "#{line_number}:#{pos_in_line}: #{pri ? preceding[pri+1..-1] : ""}#{da_match}#{remainder[/^[^\n]+/]}"
        if error_file then
          error_out = File.open(error_file, "w") unless error_out
          error_out.puts "#{fn}:#{line_number}:#{pos_in_line}:#{da_match}"
        end

        prev_match_length = da_match.length
        buffer = remainder
      end 
    end
      
  end
  
  puts "...search completed. #{count} found in all files."
  error_out.close if error_out
  if edit_files && count > 0 then
    if eask then
      $stdout.print "edit (y|n)? "
      exec "vim -q #{error_file}" if ($stdin.gets.start_with?(/Y|y/))
    else
      exec "vim -q #{error_file}" 
    end
  elsif nedit_files && ncount > 0 then
    exec "vim -q #{nerror_file}" 
  end

end

