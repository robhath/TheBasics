#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'Stringx.rb'
require 'args'


def saveit(title, link, content)
  # $stderr.puts "saveit(#{title}, #{link}, [#{content}])"  # debug
  path = ""
  result = false  # will return true if file written
  link.delete_prefix("https://freertos-wordpress.corp.amazon.com/").split("/").each do |str|
    path << str
    break if str.end_with?(".html")
    path << "/"
    Dir.mkdir(path) unless Dir.exist?(path)
  end

  unless path.end_with?(".html") then
    path << title + ".html"
  end
  if File.exist?(path) then
    $stderr.puts "ERROR: duplicate file '#{path}' not written" 
  else
    File.open(path, "w") {|output| output.puts content }
    result = true
  end
  return result
end  # saveit


if __FILE__ == $0 then

  $stderr.puts "Extracting HTML files..."  # debug
  page_count = 0
  post_count = 0

  x = XML.parse($stdin)
  x.each do |y|
    if y.tag == "item" then

      item_type = false
      title = false
      link = false
      status = false
      content = false

      y.each do |z|
        if z.tag == "wp:post_type" then
          z.each do |q|
            if q.tag == "![CDATA[" then
              item_type = q.pcdata.delete_suffix("]]")
              break
            end
          end

        elsif z.tag == "title" then
          title = z.get_pcdata.xml2txt.delete(" \t\n\r?=\\/") 

        elsif z.tag == "link" then
          link = z.get_pcdata.xml2txt.delete(" \t\n\r?=\\") 

        elsif z.tag == "wp:status" then
          z.each do |q|
            if q.tag == "![CDATA[" then
              status = q.pcdata.delete_suffix("]]")
              break
            end
          end

        elsif z.tag == "content:encoded" then
          z.each do |q|
            if q.tag == "![CDATA[" then
              content = q.pcdata.delete_suffix("]]").gsub("\t", "    ")
              break
            end
          end
        end

      end  # y.each

      if content && !content.empty? && (status == "publish" || status == "inherit") then

        if item_type == "post" then
          # $stderr.puts "post: link[#{link}] title[#{title}]"  # debug
          post_count += 1 if saveit(title, link, content)

        elsif item_type == "page" then
          # $stderr.puts "page: link[#{link}] title[#{title}]"  # debug
          page_count += 1 if saveit(title, link, content)
        end

      else
        # $stderr.puts "status[#{status}]"  # debug
      end

    end  # if y.tag == "item"
  end  # x.each

  $stderr.puts 
  $stderr.puts "#{page_count.to_s} pages extracted"
  $stderr.puts "#{post_count.to_s} posts extracted"
end

