#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'json'
require 'stringio'
require 'XML.rb'
require 'curlit.rb'


$substitute_patterns = [/\{((?!\s)[^}]*)\}/, /``([^`]*)``/, /(-:p:-)/]
$substitute_tags = ["replaceable", "code", "-:p:-"]

class XML
  
  def pattern_to_xml(pattern = /\{([^}]*)\}/, tag = "replaceable")
    self.each do |y|
      new_children = []
      new_parent = nil
      pcd = XML.new
      y.child.each do |z|
        if z.tag.empty? then
          while z.pcdata =~ pattern do
            before = $`
            after = $'
            matched = $1
            all = $&
            if z.pcdata =~ /pattern:/ && before[-1] == "p" then
              pcd.pcdata << before[0..-2] if before.length > 1
              pcd.pcdata << "\\\\p"
              new_children << pcd
              pcd = XML.new
              new_children << XML.new("", {}, "{#{matched}}")
              z.pcdata = after
            elsif z.pcdata =~ /pattern:/ then
              pcd.pcdata << before 
              new_children << pcd
              pcd = XML.new
              new_children << XML.new("", {}, "{#{matched}}")
              z.pcdata = after
            elsif matched == "-:p:-" then
              pcd.pcdata << before
              new_children << pcd
              pcd = XML.new
              z.pcdata = after
              if new_parent then
                new_parent.child << XML.new(String.new(y.tag), {}.merge(y.attributes), "", new_children)
              else
                new_parent = XML.new("", {}, "", [XML.new(String.new(y.tag), {}.merge(y.attributes), "", new_children)])
              end
              new_children = []
            else 
              pcd.pcdata << before
              new_children << pcd
              pcd = XML.new
              new_children << XML.new(tag, {}, "", [XML.new("", {}, matched)])
              z.pcdata = after
            end
          end
          new_children << z
        else
          unless pcd.pcdata.empty? then
            new_children << pcd
            pcd = XML.new
          end
          new_children << z
        end
      end
      if new_parent then
        new_parent.child << XML.new(String.new(y.tag), {}.merge(y.attributes), "", new_children)
        y.tag = new_parent.tag
        y.attributes = new_parent.attributes
        y.pcdata = new_parent.pcdata
        y.child = new_parent.child
      else
        y.child = new_children
      end
    end
  end  # pattern_to_xml
  
end  # XML


class Hash
  
  def cf_to_yaml()
    result = YAML.dump(self).delete('"')
    result.sub!(/^\s*---\s*/, "")
    result.gsub!(/\n( *)- /) {|str| "\n#{$1}  - " }
    return result
  end  # to_yaml
  
end  # Hash


  def get_defn_parts(what, parent = what, choice = false)
    results = []
    
    if what.respond_to?(:each_pair) then
      
      if what["properties"] then
        is_choice = what.keys.any? {|k| k =~ /doc-type$/ && what[k] =~ /oneOf/i }
        temp = "{ "
        temp << get_defn_parts(what["properties"], parent, is_choice).join(", ")
        temp << " }"
        results << temp
      elsif what["additionalProperties"] then
        temp = "{ "
        3.times do |i|
          temp << " \"additionalProperty#{i.to_s}\" => "
          temp << get_defn_parts(what["additionalProperties"], parent).join("")
          temp << ", " unless i == 2
        end
        temp << " }"
        results << temp
      elsif what["items"] then
        temp = "[ "
        temp << get_defn_parts(what["items"], parent).join(", ")
        temp << " ]"
        results << temp
      elsif what["schema"] then
        results += get_defn_parts(what["schema"], parent)
      elsif what["$ref"] then
        newh = parent.at(what["$ref"])
        key = newh.keys[0]
        value = newh[key]
        results += get_defn_parts(value, parent)
      else
        results << "\"*-- NOTE:\" => \"choose one of the following --*\" " if choice
        what.each_pair do |key, value|
          next if (key.to_s == "required" || key.to_s == "enum") && value.respond_to?(:each)
          if value.respond_to?(:each) then
            temp = "\"#{key.to_s}\" => "
            temp2 = get_defn_parts(value, parent).join(", ")
            if temp2.index("=>") && !temp2.index("{") then
              temp << "{"
              temp2 << "}"
            end
            results << (temp + temp2)
          end
        end
        typ = what["type"]
        return results if typ == "object"  # empty object!!!
        desc = what["description"]
        nm = what["name"]
        if what["enum"] then
          typ = what["enum"].join("|")
        end
        fmt = what["format"]
        temp = (nm ? "\"#{nm.to_s}\" => " : "") + (typ ? "\"#{((fmt ? (fmt.to_s + "-") : "") + typ.to_s)}\" " : "") #+ (desc ? " # #{desc.to_s}" : "")
        results << temp unless temp.empty?
      end
      
    elsif what.respond_to?(:each) then
      what.each do |obj|
        results += get_defn_parts(obj, parent)
      end
      
    end
      
    return results
  end  # get_defn_parts
  

  def cf_get_defn(type, resource, target_string, parent, prop_names = [])
    #~ $stderr.puts "cf_get_defn(#{type}, #{resource}, #{target_string}, ...)"
    tempa = type.gsub(".", "::").split("::")
    properties = resource['Properties']
    the_definition = {tempa.last => {"Type" => type, "Properties" => {} } }
    if properties.nil? then
      $stderr.puts "ERROR: unable to find #{tempa} Properties"
      return the_definition 
    end
    
    properties.each do |name, definition|
      if (definition.has_key?('Type') && definition['Type'] != 'List') || definition.has_key?('ItemType') then
        here = nil
        if definition['ItemType'] then
          the_definition[tempa.last]["Properties"][name] = [{}]
          here = the_definition[tempa.last]["Properties"][name][0]
        else
          the_definition[tempa.last]["Properties"][name] = {}
          here = the_definition[tempa.last]["Properties"][name]
        end
        prop_names << (definition['ItemType'] || definition['Type'])
        # find recursively...
        tempp = []
        tempp << [parent['PropertyTypes'][target_string + '.' + prop_names.last], here]
        tempp.each do |mo_stuff, where|
          if mo_stuff.nil? then
            $stderr.puts "ERROR: unable to find #{target_string + '.' + prop_names.last} in PropertyTypes"
            next
          end
          if mo_stuff.has_key?("Properties") then
            mo_stuff["Properties"].each do |n, d|
              if (d.has_key?('Type') && d['Type'] != 'List') || d.has_key?('ItemType') then
                prop_names << (d['ItemType'] || d['Type'])
                if d['ItemType'] then
                  where[n] = [{}]
                  here = where[n][0]
                else
                  where[n] = {}
                  here = where[n]
                end
                tempp << [parent['PropertyTypes'][target_string + '.' + prop_names.last], here]
              elsif d['PrimitiveType'] then
                where[n] = type2value(d['PrimitiveType']) # {"Ref" =&gt; type2type(d['PrimitiveType'])}
              elsif d['PrimitiveItemType'] then
                where[n] = [type2value(d['PrimitiveItemType'])] # [{"Ref" =&gt; type2type(d['PrimitiveItemType'])}]
              end
            end
          end
        end
      elsif definition['PrimitiveType'] then
        the_definition[tempa.last]["Properties"][name] = type2value(definition['PrimitiveType']) # {"Ref" =&gt; type2type(definition['PrimitiveType'])}
      elsif definition['PrimitiveItemType']
        the_definition[tempa.last]["Properties"][name] = [type2value(definition['PrimitiveItemType'])] # [{"Ref" =&gt; type2type(definition['PrimitiveItemType'])}]
      end
    end
    #~ $stderr.puts JSON.pretty_generate(the_definition)
    #~ $stderr.puts YAML.dump(the_definition)
    return the_definition
  end  # cf_get_defn


  def cf_get_defn_linked(type, resource, target_string, parent, prop_names = [])
    #~ $stderr.puts "cf_get_defn_linked(#{type}, #{resource}, #{target_string}, ...)"
    tempa = type.gsub(".", "::").split("::")
    if type.index(".") then
      thisname = "-#{tempa.last.downcase}"
      basename = tempa[1..-2].join("-").downcase
    else
      thisname = ""
      basename = tempa[1..-1].join("-").downcase
    end
    properties = resource['Properties']
    the_definition = {tempa.last => {"Type" => type, "Properties" => {} } }
    return the_definition if properties.nil?
  
    properties.each do |name, definition|
      if (definition.has_key?('Type') && definition['Type'] != 'List') || definition.has_key?('ItemType') then
        here = nil
        if definition['ItemType'] then
          the_definition[tempa.last]["Properties"]["<xref linkend='cfn-#{basename}#{thisname}-#{name.downcase}'/>"] = [{}]
          here = the_definition[tempa.last]["Properties"]["<xref linkend='cfn-#{basename}#{thisname}-#{name.downcase}'/>"][0]
        else
          the_definition[tempa.last]["Properties"]["<xref linkend='cfn-#{basename}#{thisname}-#{name.downcase}'/>"] = {}
          here = the_definition[tempa.last]["Properties"]["<xref linkend='cfn-#{basename}#{thisname}-#{name.downcase}'/>"]
        end
        prop_names << (definition['ItemType'] || definition['Type'])
        # find recursively...
        tempp = []
        tempp << [parent['PropertyTypes'][target_string + '.' + prop_names.last], here, prop_names.last]
        tempp.each do |mo_stuff, where, cur_name|
          if mo_stuff.nil? then
            $stderr.puts "ERROR: unable to find #{target_string + '.' + prop_names.last} in PropertyTypes"
            next
          end
          if mo_stuff.has_key?("Properties") then
            mo_stuff["Properties"].each do |n, d|
              if (d.has_key?('Type') && d['Type'] != 'List') || d.has_key?('ItemType') then
                prop_names << (d['ItemType'] || d['Type'])
                if d['ItemType'] then
                  #~ where["<xref linkend='aws-properties-#{basename}-#{prop_names.last.downcase}'/>"] = [{}]
                  #~ here = where["<xref linkend='aws-properties-#{basename}-#{prop_names.last.downcase}'/>"][0]
                  where["<xref linkend='cfn-#{basename}-#{cur_name.downcase}-#{n.downcase}'/>"] = [{}]
                  here = where["<xref linkend='cfn-#{basename}-#{cur_name.downcase}-#{n.downcase}'/>"][0]
                else
                  #~ where["<xref linkend='aws-properties-#{basename}-#{prop_names.last.downcase}'/>"] = {}
                  #~ here = where["<xref linkend='aws-properties-#{basename}-#{prop_names.last.downcase}'/>"]
                  where["<xref linkend='cfn-#{basename}-#{cur_name.downcase}-#{n.downcase}'/>"] = {}
                  here = where["<xref linkend='cfn-#{basename}-#{cur_name.downcase}-#{n.downcase}'/>"]
                end
                tempp << [parent['PropertyTypes'][target_string + '.' + prop_names.last], here, prop_names.last]
              elsif d['PrimitiveType'] then
                where["<xref linkend='cfn-#{basename}-#{cur_name.downcase}-#{n.downcase}'/>"] = type2type(d['PrimitiveType']) # {"Ref" =&gt; type2type(d['PrimitiveType'])}
              elsif d['PrimitiveItemType'] then
                where["<xref linkend='cfn-#{basename}-#{cur_name.downcase}-#{n.downcase}'/>"] = [type2type(d['PrimitiveItemType'])] # [{"Ref" =&gt; type2type(d['PrimitiveItemType'])}]
              end
            end
          end
        end
      elsif definition['PrimitiveType'] then
        the_definition[tempa.last]["Properties"]["<xref linkend='cfn-#{basename}#{thisname}-#{name.downcase}'/>"] = type2type(definition['PrimitiveType']) # {"Ref" =&gt; type2type(definition['PrimitiveType'])}
      elsif definition['PrimitiveItemType']
        the_definition[tempa.last]["Properties"]["<xref linkend='cfn-#{basename}#{thisname}-#{name.downcase}'/>"] = [type2type(definition['PrimitiveItemType'])] # [{"Ref" =&gt; type2type(definition['PrimitiveItemType'])}]
      end
    end
    #~ $stderr.puts JSON.pretty_generate(the_definition)
    #~ $stderr.puts YAML.dump(the_definition)
    return the_definition
  end  # cf_get_defn_linked


  def defn_to_json(what, parent = what)
    r = get_defn_parts(what, parent).join("")
    foo = {}
    eval("foo = #{r =~ /^\s*(\{|\[)/i ? "" : "{"}#{r}#{r =~ /(\}|\])\s*$/i ? "" : "}"}") if !r.empty? && r.index("=>")
    buffer = JSON.pretty_generate(foo)
    buffer.gsub!(/(:\s+)("|')([^'"]+)\2/) do |str| 
      $1 + case $3
        when "string" then "#{$2}string#{$2}"
        when "boolean" then "true"
        when "integer" then "0"
        when "number" then "1.0"
        when "int32-integer" then "0x01"
        when "int64-integer" then "0x02"
        when "float-number" then "1.0e2"
        when "double-number" then "1.0e3"
        when "byte-string" then "#{$2}base64-encoded#{$2}"
        when "binary-string" then "#{$2}binary-string#{$2}"
        when "date-string" then "#{$2}1996-12-19T16:39:57-08:00#{$2}"
        when "date-time-string" then "#{$2}1996-12-19T16:39:57-08:00#{$2}"
        when "password-string" then "#{$2}password#{$2}"
        else
          $2 + $3 + $2
        end
    end
    return buffer
  end  # defn_to_json


  def defn_to_json2(what, parent = what)
    r = get_defn_parts(what, parent).join("")
    r.gsub!(/X-Amzn-Client-Token/i, "AmznClientToken")
    foo = {}
    eval("foo = #{r =~ /^\s*(\{|\[)/i ? "" : "{"}#{r}#{r =~ /(\}|\])\s*$/i ? "" : "}"}") if !r.empty? && r.index("=>")
    return foo
  end  # defn_to_json2


  def defn_to_yaml(what, parent = what)
    r = get_defn_parts(what, parent).join("")
    foo = {}
    eval("foo = #{r =~ /^\s*(\{|\[)/i ? "" : "{"}#{r}#{r =~ /(\}|\])\s*$/i ? "" : "}"}") if !r.empty? && r.index("=>")
    buffer = YAML.dump(foo)
    buffer.gsub!(/(:\s+)(\S+)\s*$/) do |str| 
      $1 + case $2
        when "string" then "string"
        when "boolean" then "true"
        when "integer" then "0"
        when "number" then "1.0"
        when "int32-integer" then "0x01"
        when "int64-integer" then "0x02"
        when "float-number" then "1.0e2"
        when "double-number" then "1.0e3"
        when "byte-string" then "base64-encoded"
        when "binary-string" then "binary-string"
        when "date-string" then "1996-12-19T16:39:57-08:00"
        when "date-time-string" then "1996-12-19T16:39:57-08:00"
        when "password-string" then "password"
        else
          $2
        end
    end
    return buffer
  end  # defn_to_yaml


  def type2value(what)
    return case what.downcase        
      when "string" then "String"
      when "boolean" then true
      when "integer" then 0
      when "number" then 1.0
      when "int32-integer" then 0x01
      when "int64-integer" then 0x0234
      when "float-number" then 1.0e2
      when "double-number" then 1.0e3
      when "byte-string" then "base64-encoded"
      when "binary-string" then "binary-string"
      when "date-string" then "1996-12-19T16:39:57-08:00"
      when "date-time-string", "timestamp" then "1996-12-19T16:39:57-08:00"
      when "password-string" then "password"
      else
        "???"
      end
  end  # type2value


  def type2type(what)
    return case what.downcase        
      when "string" then "<replaceable>String</replaceable>"
      when "boolean" then "<replaceable>Boolean</replaceable>"
      when "integer" then "<replaceable>Integer</replaceable>"
      when "number" then "<replaceable>Number</replaceable>"
      when "int32-integer" then"<replaceable>String</replaceable>"
      when "int64-integer" then "<replaceable>String</replaceable>"
      when "float-number" then "<replaceable>String</replaceable>"
      when "double-number" then "<replaceable>Double</replaceable>"
      when "byte-string" then "<replaceable>Byte-String</replaceable>"
      when "binary-string" then "<replaceable>Binary-String</replaceable>"
      when "date-string" then "<replaceable>Date-String</replaceable>"
      when "date-time-string", "timestamp" then "<replaceable>Date/Time-String</replaceable>"
      when "password-string" then "<replaceable>Password</replaceable>"
      else
        "???"
      end
  end  # type2type


  def doc_cleanup(str)
    # further clean up...
    result = String.new(str)
    result.gsub!(/simpara/, 'para')
    result.gsub!(/(<ulink[^>]+)type\s*=\s*(?:"|')documentation(?:"|')([^>]*)/) do |s| 
      first = $1
      second = $2
      first.sub!(/\burl\s*=\s*("|')/) {|s1| "url=#{$1}&url-doc-domain;" }
      second.sub!(/\burl\s*=\s*("|')/) {|s1| "url=#{$1}&url-doc-domain;" }
      first + second
    end
    result.gsub!(/<xref[^>]+linkend\s*=\s*("|')([^'"]+)('|")[^>]+>/) do |s|
      $2
    end
    result.gsub!(/<\/xref\s*>/, "")
    #~ $stderr.puts "#{str} -> #{result}"
    return result
  end  # doc_cleanup
    


  def html_doc_cleanup(str)
    # further clean up...
    result = String.new(str)
    result.gsub!(/simpara/, 'p')
    result.gsub!(/<para/, '<p')
    result.gsub!(/(<ulink[^>]+)type\s*=\s*(?:"|')documentation(?:"|')([^>]*)/) do |s| 
      first = $1
      second = $2
      first.sub!(/\burl\s*=\s*("|')/) {|s1| "href=#{$1}&url-doc-domain;" }
      #second.sub!(/\burl\s*=\s*("|')/) {|s1| "url=#{$1}&url-doc-domain;" }
      second.sub!(/\burl\s*=\s*("|')/, '')
      first.sub!(/<ulink/, "<a")
      first + second
    end
    result.gsub!(/<xref[^>]+linkend\s*=\s*("|')([^'"]+)('|")[^>]+>/) do |s|
      $2
    end
    result.gsub!(/<\/xref\s*>/, "")
    #~ $stderr.puts "#{str} -> #{result}"
    return result
  end  # html_doc_cleanup
    


  def y2z(argv)
    $service_name = "xxx"
    template_fn = ""
    x = nil
    output_hdrftr = false
    is_html = false
    
    if i = argv.index("-html") then
      is_html = true
    end

    if i = argv.index("-zi") then
      template_fn = argv[i+1]
      argv[i+1] = nil
      x = XML.parse_lazy_text(StringIO.new(template_fn), 
          delimiters: XML::DELIMITERS, 
          tags: (is_html ? XML::HTML_TAGS : XML::DOCBOOK_TAGS), 
          table_tags: (is_html ? XML::HTML_TABLE_TAGS  : XML::DOCBOOK_TABLE_TAGS), 
          para_tags: (is_html ?  XML::HTML_PARA_TAGS  : XML::DOCBOOK_PARA_TAGS) )
    elsif i = argv.index("-z") then
      template_fn = argv[i+1]
      argv[i+1] = nil
      
      if template_fn =~ /\.xml$/i then
        File.open(template_fn, "r") {|input| x = XML.parse_p(input) }
      else
        File.open(template_fn, "r") do |input|  
          x = XML.parse_lazy_text(input, 
              delimiters: XML::DELIMITERS, 
              tags: (is_html ? XML::HTML_TAGS : XML::DOCBOOK_TAGS), 
              table_tags: (is_html ? XML::HTML_TABLE_TAGS  : XML::DOCBOOK_TABLE_TAGS), 
              para_tags: (is_html ?  XML::HTML_PARA_TAGS  : XML::DOCBOOK_PARA_TAGS) )
        end
      end
    end
    
    if template_fn.empty? || argv.length < 1 then
      $stderr.puts "y2z.rb <path, file or directory> ... -z <zonbook-template-file> 
        [-svc <service-name>]  [-target <target-string>]  [-output <output-filename>]  [-doc <doc-info-file>]  [-html]  [-hf]"
      exit
    else
      line1 = "YAML to ZonBook  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
      $stderr.puts line1
      $stderr.puts "=" * line1.length
      $stderr.puts
    end
    
    if i = argv.index("-svc") then
      $service_name = argv[i+1]
      argv[i+1] = nil
    end

    if i = argv.index("-hf") then
      output_hdrftr = true
    end

    if i = (argv.index("-target") || argv.index("-t"))  then
      $target_string = argv[i+1]
      argv[i+1] = nil
    end

    if i = (argv.index("-output") || argv.index("-o")) then
      $output_fn = argv[i+1]
      argv[i+1] = nil
    end

    d = {}
    if i = (argv.index("-doc") || argv.index("-d")) then
      $document_fn = argv[i+1]
      argv[i+1] = nil
      d = YAML.load_file($document_fn)
      if d.nil? || !d || d.empty? then
        $stderr.puts "    invalid documentation file!"
      end
    end


    argv.each do |arg|
      next if arg.nil? || arg[0,1] == "-"
    
      if File.directory?(arg) then
        a = Dir.glob("#{arg}/**/*.{json,txt,yaml,yml}")
      else
        a = [arg]
      end
      
      a.each do |fn|
        next if File.directory?(fn)
        $stderr.puts fn
    
        y = YAML.load_file(fn)
        if y.nil? || !y || y.empty? then
          $stderr.puts "    something's wrong... skipping file!"
          next
        end
        
        unless d.nil? || d.empty? then
          y.cwalk([]) do |key, value, context|
            if value.respond_to?(:each_pair) && value.has_key?("description") then
              where = d
              context.each do |c|
                begin
                  where = where[c]
                rescue
                  where = nil
                  break
                end
              end
              if where then
                if where.respond_to?(:each_pair) && where.has_key?("description") then
                  value["description"] = where["description"]
                else
                  $stderr.puts "WARNING: no description found at [#{context.join(",")}]" if value.has_key?("description")
                end
              else
                $stderr.puts "ERROR: can't follow description file to [#{context.join(",")}]"
              end
            end
          end
          new_fn = fn.sub(/(.*)(\.[^.]+$)/) {|str| "#{$1}.d#{$2}" }
          $stderr.puts new_fn
          File.open(new_fn, "w") {|output| output.puts JSON.pretty_generate(y) }
        end
      
        new_xml = x.copy
        new_xml.evaluate!(binding)
        
        context = []
        new_xml.ceach(context) do |y, context|
          new_children = []
          y.child.each do |z|
            if z.tag.empty? && z.child.empty? && z.pcdata !~ /\S/ && !context.any? {|tag| XML::LITERAL_TAGS.index(tag) } then
              #new_children += z.child
            else
              new_children << z
            end
          end
          y.child = new_children
        end
        
        ##$substitute_patterns.each_index do |i|
          ##new_xml.pattern_to_xml($substitute_patterns[i], $substitute_tags[i])
        ##end unless is_html
        
        if $output_fn && $output_fn.downcase == "stdout" then
          $stdout.puts(is_html ? XML::HTML_pre : XML::DOCBOOK_pre) if output_hdrftr
          $stdout.puts new_xml.to_s(0, true, (is_html ? XML::HTML_LITERAL_TAGS : XML::DOCBOOK_LITERAL_TAGS) + %w( term ) )
          $stdout.puts(is_html ? XML::HTML_post : XML::DOCBOOK_post) if output_hdrftr
        elsif $output_fn then
          if a.length > 1 then
            output = File.open($output_fn, "a:UTF-8")
          else
            output = File.open($output_fn, "w:UTF-8")
          end
          $stderr.puts "  --> #{$output_fn}"
          output.puts(($the_header || (is_html ? XML::HTML_pre : XML::DOCBOOK_pre)).to_s) if output_hdrftr
          output.puts new_xml.to_s(0, true, (is_html ? XML::HTML_LITERAL_TAGS : XML::DOCBOOK_LITERAL_TAGS) + %w( term ) )
          output.puts(is_html ? XML::HTML_post : XML::DOCBOOK_post) if output_hdrftr
          output.close
        else
          new_xml.to_file(".", ($the_header || (is_html ? XML::HTML_pre : XML::DOCBOOK_pre)).to_s, 0, true, 
                (is_html ? XML::HTML_LITERAL_TAGS : XML::DOCBOOK_LITERAL_TAGS) + %w( term ) )
        end

      end  # a.each
    end
  end  # y2z
  
  
if __FILE__ == $0 then
  
  y2z(ARGV)
  
end

