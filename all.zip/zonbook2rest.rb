#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'Stringx.rb'

  $title_chars = %w( na # = - ` ' . ~ * + ^ & : ; )
  
  
class String
  
  def fixup_inline!()
    self.gsub!(/(\A|.):(\w+):`([^`]*)`([^\\]|\Z)/m) do |str|
      "#{$1}#{" \n\f\t\v".include?($1) ? "" : "\\ "}:#{$2}:`#{$3}`#{" \n\f\t\v".include?($4) ? "" : "\\ "}#{$4}"
    end
    self.gsub!(/&([A-Za-z][-\w_]*);/, '|\1|')
  end  # fixup_inline
  
end  # String

  
class XML
  
  def to_rest(context = [])
    buffer = ""
    context << self.tag
    self.child.each {|c| buffer << c.to_rest(context) }
    context.pop
    
    case self.tag
      
      when "entry"
        $stderr.puts "entry/before[#{buffer}]"
        buffer.strip!
        buffer.fixup_inline!
        $stderr.puts "entry/after[#{buffer}]"
        buffer.gsub!(/\|/, "&#124;")
        found = false
        buffer.gsub!(/\n( +)(\.\. )?/) do |str|
          if $2 then
            found = true
            "\n\n#{$1}.. "
          elsif !found then
            "\n"
          else
            str
          end
        end
        buffer.gsub!(/(?<=\S) {2,}/, " ")
        buffer.rstrip!
        buffer << " | "
      
      when "row"
        if buffer.include?("\n") then
          temp = [[]]
          columns = buffer.split("|")
          columns.pop
          columns.collect! {|c| c.strip.split("\n") }
          i = 0
          loop do
            done = true
            columns.each do |c|
              temp.last << (c[i] || "")
              done = false if c.length > (i+1)
            end
            break if done
            temp << []
            i += 1
          end
          buffer = ""
          temp.each do |a|
            buffer << "| #{a.join(" | ")} |\n"
          end
          buffer << ("+-" * columns.length) + "+\n"
        else
          buffer.rstrip!
          buffer.prepend("| ")
          buffer << "\n"
          buffer << ("+-" * (buffer.count("|") - 1)) + "+\n"
        end
        
      when "thead"
        buffer.gsub!(/\+(-+)(?=\+)/) {|str| "+#{"=" * $1.length}" }
        
      when "table", "informaltable"
        title = ""
        #~ buffer.gsub!(/^(\s*:strong:`[^`]+`\s*)/m) {|str| title = $1; "" }
        buffer.gsub!(/^(\s*:strong:`.+`\n{2,})/m) {|str| title = $1; "" }
        temp = []
        max_lengths = []
        column_count = 0
        buffer.split("\n").each do |row|
          temp << []
          unless column_count > 0 then
            column_count = row.count("|") - 1 
            column_count.times {|i| max_lengths << 0 }
          end
          if row[0] == "+" then
            temp.last << row
          else
            i = 0
            cols = row.split("|")
            cols[1..-1].each do |col|
              col.rstrip!.gsub!(/&#124;/, "|")
              #~ $stderr.puts "i=#{i} col='#{col}' column_count=#{column_count} max_lengths[#{max_lengths.join(",")}]"
              max_lengths[i] = (col.length > (max_lengths[i] || 0) ? col.length : (max_lengths[i] || 0))
              temp.last << col
              i += 1
            end if cols.length > 0
          end
        end
        # put it back together with each column's width = max length...
        sep = ""
        header_sep = ""
        max_lengths.each do |max|
          sep << ("+" + ("-" * (max + 1)))
          header_sep << ("+" + ("=" * (max + 1)))
        end
        sep << "+\n"
        header_sep << "+\n"
        buffer = title + sep
        temp.each do |row|
          if row[0] && row[0][0] == "+" then
            buffer << (row[0][1] == "-" ? sep : header_sep)
          else
            buffer << "|"
            i = 0
            row.each do |col|
              buffer << col.ljust(max_lengths[i]) + " |"
              i += 1
            end
            buffer << "\n"
          end
        end
        buffer << "\n\n"
      
      
      when "chapter", "section"
        buffer.prepend("\n.. _#{self.attributes["id"]}:\n\n") if self.attributes.has_key?("id")
      
      when "title"
        buffer.strip!
        buffer.gsub!(/\s+/, " ")
        if context.last == "chapter" || context.last == "section" then
          buffer.fixup_inline!
          len = buffer.length
          depth = context.count {|obj| obj == "chapter" || obj == "section" }
          #~ $stderr.puts depth
          buffer.prepend(($title_chars[depth] * len) + "\n") if depth < 2
          buffer << "\n" + ($title_chars[depth] * len) + "\n\n"
        elsif context.last == "formalpara" then
          buffer.fixup_inline!
          buffer.gsub!(/^ +/, "")
          buffer.gsub!(/ +/, " ")
          buffer << "\n\n"
        elsif context.last == "bookinfo" then
          buffer.prepend("    #{self.tag}: ")
          buffer << "\n"
        elsif !buffer.empty? then
          buffer.prepend(":strong:`")
          buffer << "`\n\n"
        end
        
      when "listitem", "step"
        buffer.prepend("  * ")
        buffer.gsub!(/\n( *)(?=\S)/) {|str| "\n#{$1}    " }
        
      when "note"
        buffer.prepend("    .. note:: ")
        buffer.gsub!(/\n( *)(?=\S)/) {|str| "\n#{$1}       " }
        
      when "orderedlist", "procedure"  #, "substeps"
        buffer.gsub!(/(^|\n)( +)\* /) {|str| "\n#{$2}1. " }
      
      when "para", "term", "textobject"
        buffer.strip!
        buffer.gsub!(/(.{80,100}) +(?=.)/) {|str|  "#{$1}\n" }
        if context.last == "formalpara" then
          depth = context.count {|obj| obj =~ /list$/ || obj == "blockquote" || obj == "formalpara" }
          buffer.prepend(("  " * depth) + "* ")
          buffer.gsub!(/\n+\s*(?!\Z)/, "\n" + ("  " * depth) + "  ")  # ???
        else
          buffer.fixup_inline!
          found = false
          buffer.gsub!(/\n +(\.\. )?/) do |str|
            if $1 then
              found = true
              "\n\n  .. "
            elsif !found then
              "\n"
            else
              str
            end
          end
          buffer.gsub!(/(?<=\S) {2,}/, " ")
          buffer.sub!(/(contents|topics)/i, ".. contents::") if self.attributes["role"] == "topiclist"  # ???
          buffer << "\n\n"
        end
        
      when "programlisting"
        buffer.fixup_inline!
        buffer.prepend("    .. parsed-literal::\n")
        buffer.gsub!(/\n( *)(?=\S)/) {|str| "\n#{$1}       " }
        buffer << "\n\n"
        
      when "varlistentry", "formalpara"
        if buffer =~ /\n( +)\* +/ then
          term = $`
          pre_indent = $1.length
          indent = ($&.length - 1)
          definition = $'
          if indent > 4 then
            # it contains a sub-list...
            buffer = "#{" " * pre_indent}  #{term.strip}\n#{" " * indent}#{definition.strip}\n\n" 
          else
            definition.gsub!(/\n( *)(?=\S)/) {|str| "\n#{$1}    " }
            buffer = "#{" " * indent}#{term.strip}\n#{" " * indent}    #{definition.strip}\n\n"
          end
        end

        
      when "replaceable" # TBD: userinput
        buffer.prepend(":samp:`{")
        buffer << "}`"
        
      when "code", "guilabel"
        buffer.prepend(":#{self.tag}:`")
        buffer << "`"
        
      when "emphasis", "citetitle"
        if self.attributes["role"] == "bold" || self.attributes["role"] == "strong" then
          buffer.prepend(":strong:`")
          buffer << "`"
        else
          buffer.prepend(":emphasis:`")
          buffer << "`"
        end
        
      when "link"
        buffer.prepend(":ref:`")
        buffer << "<#{self.attributes["linkend"]}>`"
      
      when "ulink"
        buffer.prepend("`")
        buffer << "<#{self.attributes["url"]}>`_"
        
      when "xref"
        buffer << ":ref:`#{self.attributes["linkend"]}`"
        
      when "abstract", "titleabbrev"
        buffer.clear
        
      when "imagedata"
        buffer << "  .. image:: " + self.attributes["fileref"] + "\n"
        
      when "imageobject"
        buffer << "\n"
        
      when "mediaobject"
        if buffer =~ /(\A|\n) *(?!\.\. image::)/ then
          indent = ""
          buffer.gsub!(/(\A|\n)( *)(\.\. image::)?/) do |str| 
            if $3 then
              indent = $2
              $1 + $2 + ".. figure::" 
            elsif $'.empty? then
              $1
            else
              $1 + indent + "   "
            end
          end
        end
      
      when ""
        buffer << self.pcdata.xml2txt unless self.pcdata =~ /^\s*\n+\s*$/
        
      
      when "toc"
        buffer << "Contents
========

.. toctree::
    :maxdepth: 2
    :titlesonly:
    :includehidden:

"
       
      when "xi:include"
        buffer << "    #{self.attributes["href"].sub(/\.xml$/, "")}\n"
        
      when "book"
        title = ""
        if buffer =~ /\n *title: ([^\n]+)/ then
          title << $1
        end
        if buffer =~ /\n *subtitle: ([^\n]+)/ then
          title << " " unless title.empty?
          title << $1
        end
        buffer.prepend(("#" * title.length) + "\n" + title + "\n" + ("#" * title.length) + "\n\n")
        
      when "bookinfo"
        buffer.prepend("\n.. \n")
        buffer.gsub!(/\n( *)(?=\S)/) {|str| "\n#{$1}    " }
        
      when "corpauthor", "publishername", "subtitle"
        buffer.prepend("    #{self.tag}: ")
        buffer << "\n"
        
      #~ when "variablelist", "itemizedlist", "phrase", "tbody", "tgroup", "substeps", "publisher"
        #~ these come out in the wash...
        
      when "colspec", "userinput", "anchor", "simplelist", "chapterinfo", "sectioninfo"
        #~ TBD
        
        else
          #~ $stderr.puts "what about '#{self.tag}'?" unless self.tag[0] == "?" || self.tag[0] == "!"
      
      end  # case self.tag
      
    return buffer
  end  # to_rest


end  # XML


if __FILE__ == $0 then
  
  if ARGV.length < 1 then
    $stderr.puts "syntax:\n  zonbook2rest.rb <file or directory> ... "
    exit
  end
  
  puts "Zonbook to reST  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "======================================"
  
  x = nil
  ARGV.each do |arg|
    next if arg[0,1] == "-"
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{xml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      if fn =~ /(\/|^)(build|zonbook\.redirects)\.xml$/ then
        puts "skipping file: #{fn}\n\n"
        next
      end
      puts fn
      buffer = ""
      File.open(fn, "r:UTF-8") do |input|  
        x = XML.parse(input)  #{|line, start_column, context, buffer| link_check(line, start_column, context, buffer) }
        buffer << x.to_rest
      end
      if buffer.empty? then
        $stderr.puts "ERROR: no data found in file '#{fn}'"
      else
        ofn = fn.sub(/\.xml$/, ".rst")
        puts "  -->#{ofn}\n\n"
        File.open(ofn, "w:UTF-8") do |output|
          output.puts buffer
      end
      end
    end
  end
  
end
