#!ruby

require 'webrick'
include WEBrick

def serve(port = 8000, what = Dir.pwd)
  s = HTTPServer.new(Port: port, DocumentRoot: what)
  trap("INT") { s.shutdown }
  s.start
end



if __FILE__ == $0 then
  port = (ARGV[1] || "8000").to_i
  $stderr.puts "port is #{port}"
  serve(port, (Dir.pwd + (ARGV[0] ? ("/" + ARGV[0]) : "")))
end
