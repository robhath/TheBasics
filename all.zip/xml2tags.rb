#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'args.rb'


if __FILE__ == $0 then
  
  get_args(nmin: 1, nsyntax: "xml2tags.rb <file>")

  puts "======================================"
  puts "XML/HTML to tags #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "======================================"
 
  x = nil

  File.open($nargs[0], "r") do |input|
    x = XML.parse_p(input, ($nargs[0] =~ /\.html?$/))
  end
  File.open($nargs[0].sub(/\.[^.]+$/, ".tags.txt"), "w") do |output|
    output.print x.to_tags_canonical
  end

end
