#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'diff_base.rb'


# === main ========
if $0 == __FILE__ then
  xin = File.open(ARGV[0], "r:UTF-8")
  yin = File.open(ARGV[1], "r:UTF-8")
  
  x = []
  while line = xin.gets do x << line.chomp end  # crc32(line) end   # line.chomp end
  y = []
  while line = yin.gets do y << line.chomp end  # crc32(line) end   # line.chomp end
  
  xin.close
  yin.close
  
  puts diff(x, y)
  
end    

