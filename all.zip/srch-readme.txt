
SEARCH/REPLACE
==============

srch.rb 
srchm.rb
srchm.exe

"srch" and "srchm" are basically "grep" on steroids.  They enable you to search for a bit of text 
in the files in a directory using a regular expression pattern.  In addition, they:

  - can search through files with extensions you specify
  - will search recursively through sub-directories
  - can call vim to edit each occurrence of the text found
  - can produce a file documenting their results
  - can accept case-insensitive, extended, and multi-line regular expression parameters
  - permit a simplified syntax that is easy to use
  
"srchm" allows your bit of text to exist over two lines in the searched files, "srch" requires 
that the bit of text you are looking for exist on a single line.

The .exe can be run from the Windows command line without a Ruby interpreter installed (it 
self-extracts the Ruby interpreter and runs the Ruby code.)

Syntax:

  srch.rb -p <pattern> -d <directory> [--i] [--m] [--x] [--edit] [-e <file-name>] [-ext <file-extensions>...]
  
    where:
    -p <pattern>            : regular expression to match
    -d <directory>          : directory to search (recursive)
    --i                     : case-insensitive regular expression
    --m                     : multi-line regular expression
    --x                     : extended syntax regular expression
    --edit                  : edit what is found using vim
    -e <file-name>          : generate results file
    -ext <file-extensions>  : look in files with this extension, e.g. -ext xml, can be one or more
    
    
Simplified Syntax:

  srch.rb <pattern>
  
    equivalent to: srch.rb -p <pattern> -d . -ext html rst txt xml

    
    
CHECK SPELLING
==============

spell-chk.rb
spell-chk.exe

"spell-chk" will search for spelling errors in the file or directory (recursively) you specify.  
In the case of a directory, it will look in .html, .rst and .xml files.  When looking through 
these sorts of files, "spell-chk" will ignore text inside tags and attributes, literals, comments, 
directives and the like.  "spell-chk" uses the dictionary file "words.txt" supplied with these 
tools (it will look for it in the directory where "spell-chk" resides.)

"spell-chk" will invoke vim to allow you to edit each potential mis-spelling if you specify the 
"--edit" parameter.

The .exe can be run from the Windows command line without a Ruby interpreter installed (it 
self-extracts the Ruby interpreter and runs the Ruby code.)

Syntax:
  
  spell-chk.rb  <file or directory>...  [--edit]
  
    where:
    --edit              : edit what is found using vim


CHECK LINKS
===========

link-ok.rb
link-ok.exe

"link-ok" will search for invalid (unreachable or non-existent) references in the file or 
directory (recursively) you specify.  In the case of a directory, it will look in .html files. 
(And please note that "link-ok" only currently works with files using XHTML syntax.) When 
looking through these sorts of files, "link-ok" will look at "<a href='...'>", 
"<link href='...'>" and "<img src='...'>" references. If the reference seems to be a file, 
"link-ok" will attempt to find it locally. Otherwise, it will invoke an HTTP client to fetch a 
response for the specified URL. (It will ignore a URL with the "mailto:" protocol.)

"link-ok" will invoke vim to allow you to edit each potential invalid link if you specify the 
"--edit" parameter.

The .exe can be run from the Windows command line without a Ruby interpreter installed (it 
self-extracts the Ruby interpreter and runs the Ruby code.)

Syntax:
  
  link-ok.rb  <file or directory>...  [--edit]
  
    where:
    --edit              : edit what is found using vim


Additional Notes For All Tools
==============================

  - The syntax is the same for the .exe forms as for the .rb forms.  
  
  - Under Linux, the .rb files begin with the following "shebang" notation, which allows you to 
    invoke them directly from the command line (if your system is set up similarly, i.e. the 
    location of your Ruby interpreter is the same):
    
      #!/usr/bin/ruby
      
    Remember to "chmod a+x <file>.rb" after you copy the files to the location you desire. I put
    them in my "~/bin" directory, since that is already on my path under our current RedHat
    configuration.

  - Under Windows, when running the .rb forms with a locally installed Ruby interpreter, you must 
    begin the invocation with the path to the interpreter, or, at least, with "ruby ..." if Ruby is 
    on your Path variable. For example:
  
    >ruby srch.rb "foo"
    
  - The "words.txt" file must be present in the same directory in which "spell-chk" resides (both 
    .rb and .exe forms).
  
  - The following files are support (library) files.  They are not needed if you only intend to 
    run the .exe forms. Otherwise, they must be present in the same directory as the main .rb files:
  
    binary_search.rb
    is_valid_link.rb
    rest_spell_checker.rb
    restructured.rb
    spell_checker.rb
    xml_handler.rb
