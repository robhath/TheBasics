#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'


if __FILE__ == $0 then
  
  get_args
  dirs = []
  if $args["-p"] then
    dirs += Dir.glob("./#{$args["-p"]}*/src/*")
  else
    dirs += Dir.glob("#{$args["-d"] || "."}/*")
  end
  dirs.sort! unless $args["--no-sort"]
  if $nargs.empty? then
    $nargs << "git status"
    $nargs << "git log -1"
    $nargs << "echo '------------------------------------------------'"
  end

  dirs.each do |d|
    next unless Dir.exist?(d)
    puts "\n>>> #{d} <<<"
    Dir.chdir(d) do
      $nargs.each do |narg|
        puts `#{narg}`
      end
    end
  end

end
 
