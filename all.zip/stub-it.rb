#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'stringio'
require 'XML.rb'
require 'args.rb'

LINEFEED = XML.new("", {}, "\n")
LINEFEED_INDENT = XML.new("", {}, "\n  ")


def gimme_doc(name, value, assembly, parent_name, stubs)
  # $stderr.puts "gimme_doc name=#{name} assembly=#{assembly} parent_name=#{parent_name}"  # debug
  unless value.has_key?("documentation") || name =~ /Request$|Response$/ then
    stubs.child << XML.new("documentation", 
        { "target" => "#{assembly}##{parent_name}#{parent_name.empty? ? "" : "$"}#{name}" },
        "", [LINEFEED_INDENT, XML.new("para", {}, "", [XML.new("", {}, "TODO")] ), LINEFEED] )
    stubs.child << LINEFEED
    stubs.child << LINEFEED
  end

  if value.has_key?("member") then
    value["member"].each do |m|
      gimme_doc(m["name"], m, value["assembly"], name, stubs)
    end
  end
end  # gimme_doc


  
if __FILE__ == $0 then
  
  stubs = XML.new
  
  get_args

  $nargs.each do |narg|
    stuff = YAML.load_file(narg)
   
    if stuff.has_key?("operation") && stuff.has_key?("structure") then
      stuff["operation"].each_pair do |key, value|
        # next if value.has_key?("internalonly")
        assembly, name = key.split("#")
        gimme_doc(name, value, assembly, "", stubs) if name

        # if value.has_key?("input") then
          # value["input"].each do |input|
            # if input.has_key?("target") then
              # input_name = (input["target"].include?("#") ? "" : (assembly + "#")) + input["target"]
              # if stuff["structure"].has_key?(input_name) then
                # as, nm = input_name.split("#")
                # gimme_doc(nm, stuff["structure"][input_name], as, "", stubs) if nm
              # end
            # end
          # end
        # end
        
        # if value.has_key?("output") then
          # value["output"].each do |output|
            # if output.has_key?("target") then
              # output_name = (output["target"].include?("#") ? "" : (assembly + "#")) + output["target"]
              # if stuff["structure"].has_key?(output_name) then
                # as, nm = output_name.split("#")
                # gimme_doc(nm, stuff["structure"][output_name], as, "", stubs) if nm
              # end
            # end
          # end
        # end

      end
    end 
      
    if stuff.has_key?("structure") then
      stuff["structure"].each_pair do |key, value|
        assembly, name = key.split("#")
        gimme_doc(name, value, assembly, "", stubs) if name
      end
    end 
  
    if stubs.child.length < 1 then
      $stderr.puts "No stubs generated."
    else  
      File.open(narg.sub(/(\.[^.]+)?$/, ".stubs.xml"), "w") {|output| output.puts stubs.to_s } 
    end

  end

end




