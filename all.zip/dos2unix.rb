#!ruby

while line = gets do
  puts line.chomp
end

