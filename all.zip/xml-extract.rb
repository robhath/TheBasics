#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'Stringx.rb'
require 'args'


if __FILE__ == $0 then
  
  files = []
  fn = nil

  get_args(syntax: 
    "syntax:\n  xml-extract.rb -p <tag-pattern>  <XMLfile|directory>... > <results-file>  ")

  $stderr.puts "===================================="
  $stderr.puts "XML Extractor  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  $stderr.puts "===================================="
  
  # extract from the XML file(s)...
  $nargs.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
    files << arg
  end
  files << "." if files.length < 1 

  results = XML.new
  re = Regexp.new($args["-p"])

  x = nil
  files.each do |arg| 
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{html,xml}")
    else
      a = [arg]
    end
  
    a.each do |fn|
      #~ $stderr.puts fn
      next if File.directory?(fn)
      xi = false
      if fn =~ /(\/|^)(build|zonbook\.redirects)\.xml$/ then
        $stderr.puts "\nskipping file: #{fn}"
        next
      elsif fn =~ /book\.xml$/ then
        xi = true
      end
      $stderr.puts fn
      File.open(fn, "r") do |input|  
        x = XML.parse_p(input, (fn =~ /\.html?$/)) do |line, start_column, context, buffer| 
        end
      end
     
      w = nil 
      x.each do |y|
        if y.tag =~ re then
          results.child << w unless w.nil?
          results.child << y
          results.child << XML.new("", {}, "\n")
          w = nil
        elsif y.tag == "" then 
          # PCDATA
          w = y
        else
          w = nil
        end 
      end
     
    end

  end

  puts results.to_s
  
end

