#!ruby

  if RUBY_VERSION =~ /^1.8/ then
    class String
      def force_encoding(enc)
        self
      end
      def clear()
        ""
      end
    end
  end
  
  if ARGV.length < 1 then
    $stderr.puts "syntax:\n  srch.rb -p <pattern> -d <directory> -i -m -x --edit -e <file-name> --ext <file-extensions>..."
    $stderr.puts "    -p <pattern>           : regular expression to match"
    $stderr.puts "    -d <directory>         : directory to search (recursive)"
    $stderr.puts "    -c <line-count>        : include line-count lines as context"
    $stderr.puts "    -A <line-count>        : include line-count lines as pre-context"
    $stderr.puts "    -B <line-count>        : include line-count lines as post-context"
    $stderr.puts "    --i                    : case-insensitive regular expression"
    $stderr.puts "    --m                    : multi-line regular expression"
    $stderr.puts "    --x                    : extended syntax regular expression"
    $stderr.puts "    --edit                 : edit what is found using vim"
    $stderr.puts "    --eq                   : edit what's found using vim but ask first"
    $stderr.puts "    --tide                 : edit file where NOT found using vim"
    $stderr.puts "    --api                  : look in api files"
    $stderr.puts "    --fno                  : show file names and counts only"
    $stderr.puts "    -e <file-name>         : generate results file"
    $stderr.puts "    -ext <file-extension>  : look in files with this extension, e.g. --ext xml"
    $stderr.puts "    -ignore <word list>    : ignore matches in word list (separated by commas, no spaces)"
    $stderr.puts "\n\nsimplified syntax:\n  srch.rb <pattern>"
    $stderr.puts "    defaults to: srch.rb <pattern> -d . --ext html md txt xml ent rb c h smithy"
    exit
  end
  re_str = ARGV[0]  # by default the first parameter
  re_options = 0
  dir = "."  # by default the current directory
  extensions = ["html", "md", "txt", "xml", "ent", "rb", "c", "h", "json", "smithy"]  # by default
  new_extensions = false
  do_api = false
  do_fno = false
  do_api_toldya = false
  error_file = nil
  nerror_file = nil
  error_out = nil
  nerror_out = nil
  edit_files = false
  nedit_files = false
  eask = false
  count = 0
  ncount = 0
  pre_context_count = 0
  post_context_count = 0
  ignore_list = []
  
  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^-ext/ then
        extensions.clear unless new_extensions
        new_extensions = true
        while i < (ARGV.length - 1) && ARGV[i+1][0] != "-" do
          i += 1
          extensions << ARGV[i] 
          extensions[-1] = "*" if extensions[-1] == "all"
        end
        # extensions << $'  # following match
        # extensions[-1] = "*" if extensions[-1] == "all"
      when /^-p/i then
        i += 1
        re_str = ARGV[i] if ARGV.length > i
      when /^-d/i then
        i += 1
        dir = ARGV[i] if ARGV.length > i
      when /^-e$/i then
        i += 1
        error_file = ARGV[i] if ARGV.length > i
      when /^-c/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          pre_context_count = cc
          post_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: context count (-c) must be 1-9"
        end 
      when /^-A/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          pre_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: pre-context count (-A) must be 1-9"
        end 
      when /^-B/i then
        i += 1
        cc = ARGV[i].to_i if ARGV.length > i
        if cc > 0 && cc < 10 then
          post_context_count = cc
        else
          $stderr.puts "PARAMETER ERROR: post-context count (-B) must be 1-9"
        end 
      when /^--api$/i then
        do_api = true
      when /^--fno$/i then
        do_fno = true
      when /^--edit$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
      when /^--eq$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
        eask = true
      when /^--tide$/i then
        nerror_file = "#{ENV["HOME"]}/.nsrch.err.txt"
        nedit_files = true
      when /^--i$/i then
        re_options += Regexp::IGNORECASE
      when /^--m$/i then
        re_options += Regexp::MULTILINE
      when /^--x$/i then
        re_options += Regexp::EXTENDED
      when /^[^\-]/ then
        re_str = ARGV[i]
      when /^-ignore/i then
        i += 1
        ignore_list = ARGV[i].split(',') if ARGV.length > i
      end
      i += 1
  end
  
  re = Regexp.new(re_str, re_options)
  re_file = Regexp.new("#{re_str}[^/]*$", re_options)

  a = Dir.glob("#{dir}/**/#{(extensions.empty? || extensions.index("*")) ? "*" : "*.{#{extensions.join(",")}}"}")

  title = "Search re=#{re} dir=#{dir} ext=[#{extensions.join(" ")}]  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts title
  puts "ignore list [#{ignore_list.join(", ")}]" unless ignore_list.empty?
  puts "=" * title.length
  
  a.each do |fn|
    is_directory = File.directory?(fn)
    if fn =~ re_file then
      puts "\n>>>Matched filename: #{fn}#{is_directory ? "  (directory)" : ""}"
    end
    next if is_directory
    
    if !do_api && File.basename(fn)[0..3] == "api."
      unless do_api_toldya
        puts "\n>>>Skipping api files!" 
        do_api_toldya = true
      end
      next 
    end
    found_in_file = false
    File.open(fn, "r") do |input| # :ISO-8859-1:UTF-8
      if pre_context_count > 0 || post_context_count > 0 then
        context = [] 
        remaining_context = 0
        while line = input.gets do
          offset = 0
          first_instance = true
          found_in_line = false
          begin
            while pos = (line =~ re) do
              remainder = $'
              line_number = $.
              da_match = $&
              if !ignore_list.empty? && ignore_list.index(da_match.delete(" \t\r\n")) then
                # ignore it...
                offset = line.length - remainder.length
                line = remainder
                next
              end
              puts "\n>>>File: #{fn}" unless found_in_file
              found_in_file = true
              found_in_line = true
              if first_instance && !do_fno then
                context.each do |ll|
                  puts "#{' ' * (line_number).to_s.length} #{ll}"
                end
                context.clear
                puts "#{line_number} #{line.chomp}" 
              end
              if post_context_count > 0 then
                remaining_context = post_context_count
              else
                puts "---"
              end
              first_instance = false
              count += 1
              if error_file then
                error_out = File.open(error_file, "w") unless error_out
                error_out.puts "#{fn}:#{line_number}:#{offset+pos+1}:#{da_match}"
              end
              offset = line.length - remainder.length
              line = remainder
            end
          rescue
            # try it this way to avoid encoding error...
            while pos = (line.force_encoding("ISO-8859-1") =~ re) do
              remainder = $'
              line_number = $.
              da_match = $&
              if !ignore_list.empty? && ignore_list.index(da_match.delete(" \t\r\n")) then
                # ignore it...
                offset = line.length - remainder.length
                line = remainder
                next
              end
              puts "\n>>>File: #{fn}" unless found_in_file
              found_in_file = true
              found_in_line = true
              if first_instance && !do_fno then
                context.each do |ll|
                  puts "#{' ' * (line_number).to_s.length} #{ll}"
                end
                context.clear
                puts "#{line_number} #{line.chomp}"
              end
              if post_context_count > 0 then
                remaining_context = post_context_count
              else
                puts "---"
              end
              first_instance = false
              count += 1
              if error_file then
                error_out = File.open(error_file, "w") unless error_out
                error_out.puts "#{fn}:#{line_number}:#{offset+pos+1}:#{da_match}"
              end
              offset = line.length - remainder.length
              line = remainder
            end
          end  # rescue
 
          unless found_in_line then
            if remaining_context > 0 then
              puts "#{' ' * (line_number).to_s.length} #{line.chomp}"
              remaining_context -= 1
              puts "---" if remaining_context < 1
            else
              context << line.chomp
              context.shift if context.length > pre_context_count
            end
          end
        end
      else
        while line = input.gets do
          offset = 0
          begin
            while pos = (line =~ re) do
              remainder = $'
              line_number = $.
              da_match = $&
              if !ignore_list.empty? && ignore_list.index(da_match.delete(" \t\r\n")) then
                # ignore it...
                offset = line.length - remainder.length
                line = remainder
                next
              end
              puts "\n>>>File: #{fn}" unless found_in_file
              found_in_file = true
              unless do_fno then
                puts "#{line_number} #{line.chomp}" 
              end
              count += 1
              if error_file then
                error_out = File.open(error_file, "w") unless error_out
                error_out.puts "#{fn}:#{line_number}:#{offset+pos+1}:#{da_match}"
              end
              offset = line.length - remainder.length
              line = remainder
            end
          rescue
            # try it this way to avoid encoding error...
            while pos = (line.force_encoding("ISO-8859-1") =~ re) do
              remainder = $'
              line_number = $.
              da_match = $&
              if !ignore_list.empty? && ignore_list.index(da_match.delete(" \t\r\n")) then
                # ignore it...
                offset = line.length - remainder.length
                line = remainder
                next
              end
              puts "\n>>>File: #{fn}" unless found_in_file
              found_in_file = true
              puts "#{line_number} #{line.chomp}" unless do_fno
              count += 1
              if error_file then
                error_out = File.open(error_file, "w") unless error_out
                error_out.puts "#{fn}:#{line_number}:#{offset+pos+1}:#{da_match}"
              end
              offset = line.length - remainder.length
              line = remainder
            end
          end  # rescue
        end
      end  # if pre_context_count > 0 || post_context_count > 0
      if !found_in_file then
        if nerror_file then
          puts "\n>>>File: #{fn}"
          nerror_out = File.open(nerror_file, "w") unless nerror_out
          nerror_out.puts "#{fn}:#{1}:#{1}:#{re_str}"
          ncount += 1
        end
      end
    end
  end

  puts "...search completed. #{count} found in all files."
  error_out.close if error_out
  if edit_files && count > 0 then
    if eask then
      $stdout.print "edit (y|n)? "
      exec "vim -q #{error_file}" if ($stdin.gets.start_with?(/Y|y/))
    else
      exec "vim -q #{error_file}" 
    end
  elsif nedit_files && ncount > 0 then
    exec "vim -q #{nerror_file}" 
  end
  
