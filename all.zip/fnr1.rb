#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"



if __FILE__ == $0 then
 
  findRE = Regexp.new(ARGV[0])
  replace = ARGV[1]

  while line = $stdin.gets do
    if line.gsub!(findRE, replace) then
      $stdout.print line #.gsub(findRE, replace)
      $stderr.print "*"
    else
      $stdout.print line
      $stderr.print "."
    end
  end
  $stderr.puts

end

