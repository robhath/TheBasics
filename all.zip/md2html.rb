#!ruby

# require 'redcarpet'
require 'kramdown'

if __FILE__ == $0 then
  
  files = []
  if ARGV.length < 1 then
    files << "."
  elsif i = ARGV.index("-help") || i = ARGV.index("--help") then
    $stderr.puts "md2xhtml.rb <file or directory> ... "
    exit
  end
  
  puts "============================================="
  puts "Convert Markdown to XHTML #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "============================================="
  
  # if i = ARGV.index("--wco") then
    # $do_wc = "yes"
  # end
  
  ARGV.each do |arg|
    next if arg[0,1] == "-"
    files << arg
  end

  # Initializes a Markdown parser
  # markdown = Redcarpet::Markdown.new(Redcarpet::Render::XHTML.new(render_options = {}), extensions = {})

  files.each do |arg|
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{md}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $fn = fn
      line = 1
      input = File.open(fn, "r")
      buffer = input.read
      input.close

      in_list = false
      buffer.gsub!(/(\n\s*[-+*]\s)|(\n\s*\d+\.\s)|(\n.?)/) do |str|
        # $stderr.puts "in_list=#{in_list} str[#{str}] 1[#{$1}]#{$1.nil?} 2[#{$2}]#{$2.nil?} 3[#{$3}]#{$3.nil?} "  # debug
        if $1 || $2 then
          if in_list then
            str
          else
            in_list = true
            "\n#{$1 || $2}"
          end
        else
          in_list = false
          str
        end
      end

      # new_buffer = markdown.render(buffer)
      new_buffer = Kramdown::Document.new(buffer)

      new_fn = fn.sub(/\.md$/, '.html')
      $stderr.puts new_fn  # debug
      output = File.open(new_fn, "w") 
      output.puts new_buffer.to_html
      output.close
    end
  end
end

