#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'binary_search.rb'

  $words = [] if $words.nil?
  $word_counts = Hash.new(0)

  $learned = []
  $learning = {}
  $shy = true  # split hyphenated words and check each individually
  
  if $words.empty? then
    # assume word list all downcase and already sorted...
    File.open("#{File.dirname(File.expand_path(__FILE__))}/lib/words.txt", "r:ISO-8859-1:UTF-8") do |input| 
      while line = input.gets do
        if line =~ /^\s*#/ then
          # comment
        else
          $words << line.chomp
        end
      end
    end
  end


if __FILE__ == $0 then
  
  $error_file = nil
  $error_out = nil
  $fn = nil
  $found = false
  files = []

  if ARGV.length < 1 then
    files << "."
  elsif i = ARGV.index("-help") || i = ARGV.index("--help") then
    $stderr.puts "spell-chk-txt.rb <file or directory> ... [--edit] [--learn] [--nshy] [--wco]"
    exit
  end
  
  puts "============================================="
  puts "Text File Spell Checker  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "============================================="
  
  if i = ARGV.index("--edit") then
    $error_file = "#{ENV["HOME"]}/.spell_checker.err.txt"
  end
  if i = ARGV.index("--learn") then
    $do_learn = true
  end
  if i = ARGV.index("--nshy") then
    $shy = false
  end
  if i = ARGV.index("--wco") then
    $do_wc = "yes"
  end
  
  ARGV.each do |arg|
    next if arg[0,1] == "-"
    files << arg
  end

  all_file_count = 0
  count = 0
  x = nil
  files.each do |arg|
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{md,txt}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      unless $word_counts.empty? then
        wc = $word_counts.to_a.sort! {|a,b| a[0] <=> b[0] }
        wc.sort! {|a,b| a[1] <=> b[1] }
        wc.each {|x| puts "  #{x.join(",")}" }
        puts ":::Total word count = #{count}"
        $word_counts = Hash.new(0)
        count = 0
      end
      next if File.directory?(fn)
      $found = false
      $fn = fn
      line = 1
      File.open(fn, "r") do |input| 
          prev_word = ""  # check for duplicated words
          in_code_section = false

          while str = input.gets do
            if in_code_section then
              in_code_section = false if str =~ /^\s*```/
              # $stderr.puts "ics: #{str}"  # debug
              line += 1
              next
            elsif str =~ /^\s*```/ then
              in_code_section = true
              line += 1
              next 
            end
            offset = 1
            while pos = (str =~ /(?:`[^`]+?`)|(?:<[^<>]+?>)|(&[-_\w]+;)|(\]\([^\)]+\))|((?<=\b)(a|I)(?= ))|((?<=\b)(([A-Za-z][a-z]+)(-([A-Za-z][a-z]+))?)('d|'s|'ll|'t|'ve|'re)?(?=\b))/) do
              pre = $`
              w = $&
              str = $'
              all_file_count += 1
              # $stderr.puts "pre[#{pre}] w[#{w}] str[#{str}] 1[#{$1}] 2[#{$2}] 3[#{$3}] 4[#{$4}] 5[#{$5}] 6[#{$6}]] 7[#{$7}] 8[#{$8}]"  # debug
              if (w[0,1] == "&" && w[-1,1] == ";") ||
                 (w[0,2] == "](" && w[-1,1] == ")") ||
                 (w[0,1] == "<" && w[-1,1] == ">")  ||
                 (w[0,1] == "`" && w[-1,1] == "`") then
                offset += pre.length + w.length
                prev_word = String.new(w)
                next  # skip entity, link, or html
              end
              if $do_wc then
                $word_counts[w.downcase] += 1
                count += 1
                puts "\n>>>File: #{$fn}" unless $found
                $found = true
              elsif $do_learn && $learned.include?(w) || 
                $words.binary_search(w.downcase) ||
                ($shy && $8 && !$8.empty? && $words.binary_search($7.downcase) && $words.binary_search($8[1..-1].downcase)) then
                if w == prev_word then
                  unless pre =~ /\w/ then
                    puts "\n>>>File: #{$fn}" unless $found
                    puts "repeated '#{w}' loc=#{line},#{(pos + offset)}"
                    if $error_file then
                      $error_out = File.open($error_file, "w") unless $error_out
                      $error_out.puts "#{$fn}:#{line}:#{(pos + offset)}:repeated '#{w}'"
                    end
                    $found = true
                  end
                else
                  #~ $stderr.puts "#{w} okay"
                end
              else
                puts "\n>>>File: #{$fn}" unless $found
                puts "#{w} loc=#{line},#{(pos + offset)}"
                if $do_learn then
                  if $learning.has_key?(w) then
                    if $learning[w] = 2 then
                      $learned << w
                      $stderr.puts "!!! #{w} suppressed"
                    end
                    $learning[w] += 1
                  else
                    $learning[w] = 0
                  end
                end
                if $error_file then
                  $error_out = File.open($error_file, "w") unless $error_out
                  $error_out.puts "#{$fn}:#{line}:#{(pos + offset)}:#{w}"
                end
                $found = true
              end
              offset += pre.length + w.length
              prev_word = String.new(w)
            end
            line += 1
          end

      end
    end

    unless $word_counts.empty? then
      wc = $word_counts.to_a.sort! {|a,b| a[0] <=> b[0] }
      wc.sort! {|a,b| a[1] <=> b[1] }
      wc.each {|x| puts "  #{x.join(",")}" }
      puts ":::Total word count = #{count}"
    end
  end
 
  puts "\nTotal word count for all files = #{all_file_count}"
 
  if $error_out then
    $error_out.close
    exec "vim -q #{$error_file}" 
  end
  
end
