#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'json'
require 'yamlx.rb'
  
  
if __FILE__ == $0 then
  
  flavor = "YAML"
  canonical = false
  
  file1 = nil
  file2 = nil
  ARGV.each do |arg|
    if arg.downcase == "-json" then
      flavor = "JSON"
    elsif arg.downcase == "-yaml" then
      flavor = "YAML"
    elsif arg[0,2].downcase == "-c"
      canonical = true
    else
      if file1 then
        file2 = arg unless file2
      else
        file1 = arg
      end
    end
  end
  
  if !file1 || !file2 then
    $stderr.puts "j2y.rb <input-filename> <output-filename> [-json|-yaml] [-c]"
    exit
  else
    line1 = "J2Y  #{file1} -> #{file2}:#{flavor} #{canonical ? "canonical" : ""}"
    $stderr.puts line1
    $stderr.puts "=" * line1.length
    $stderr.puts
  end
  
  
  x = YAML.load_file(file1)
  if x.nil? || !x || x.empty? then
    $stderr.puts "    something's wrong... can't parse file: #{file1}!"
    exit
  end
      
  if canonical then
    y = x.canonical_copy
  else
    y = x
  end
  
  if flavor == "YAML" then
    ystuff = YAML.dump(y)
  elsif flavor == "JSON" then
    ystuff = JSON.pretty_generate(y)
  end
  
  File.open(file2, "w:UTF-8") {|output| output.puts ystuff }
  
end    
