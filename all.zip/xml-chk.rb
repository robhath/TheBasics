#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XSD.rb'
require 'DTD.rb'
require 'Stringx.rb'
require 'args'


class XML
  
  $link_attributes = %w( endterm href linkend linkterm )
  $link_targets = []
  
  def record_link_targets(link_targets = [])
    self.each do |y|
      link_targets << y.attributes["id"] if y.attributes.has_key?("id") && y.tag != "shared"
      link_targets << y.attributes["xml:id"] if y.attributes.has_key?("xml:id")
      link_targets << y.attributes["target"] if y.attributes.has_key?("target")
      link_targets << y.attributes["name"] if $args["--html"] && y.attributes.has_key?("name")
    end
  end  # record_link_targets
  
  
  def image_check(images, images_used)
    results = []
     self.each do |y|
      if self.attributes.has_key?("fileref") then
        image_fn = "./" + self.attributes["fileref"]
        # $stderr.puts image_fn  # debug
        if fi = images.index(image_fn) then
          images_used << images.delete_at(fi)
        elsif !images_used.index(image_fn) then
          results << "#{self.pos}: image file '#{image_fn}' referenced but not found"
        end
      end
     end
    return results
  end  # image_check
  
  
  def internal_link_check(link_targets, link_attributes)
    results = []
    self.each do |y|
      next if y.tag[0..2] == "xi:"
      link_attributes.each do |la| 
        if y.attributes.has_key?(la) then
          unless y.attributes[la] =~ /^http/ || 
              (y.attributes[la][0] == "#" && link_targets.index(y.attributes[la][1..-1])) ||
              link_targets.index(y.attributes[la]) then
            #~ $stderr.puts "missing link: #{y.attributes[la]}"
            results << "#{y.pos}: missing link '#{y.attributes[la]}'"
          end
        end
      end
    end
    return results
  end  # internal_link_check
  
  
  def duplicate_link_check(link_duplicates)
    results = []
    self.each do |y|
      if y.attributes.has_key?("id") || y.attributes.has_key?("xml:id") then
        if link_duplicates.index(y.attributes["id"]) then
          #~ $stderr.puts "duplicate link: #{y.attributes[la]}"
          results << "#{y.pos}: duplicate link '#{y.attributes["id"]}'"
        elsif link_duplicates.index(y.attributes["xml:id"]) then
          #~ $stderr.puts "duplicate link: #{y.attributes[la]}"
          results << "#{y.pos}: duplicate link '#{y.attributes["xml:id"]}'"
        end
      end
    end
    return results
  end  # duplicate_link_check
  
end  # XML


if __FILE__ == $0 then
  
  error_file = nil
  xsd_files = nil
  dtd_files = nil
  elements = []
  files = []
  error_out = nil
  fn = nil
  found = false

  get_args(syntax: 
    "syntax:\n  xml-chk.rb (-cat <catalogfile> | -xsd <XSDfile> | -dtd <DTDfile>)  <XMLfile|directory>...  --edit  --img  --verbose  --suggest  --nolink  --json  --strict --html")

  puts "==========================================="
  puts "XML Validity Checker  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "==========================================="
  
  if $args["--edit"] then
    error_file = "#{ENV["HOME"]}/.xsd.err.txt"
  end
  
  # build the validation engine...
  if $args["-cat"] then
    # start with catalog file containing references to DTD parts
    dtd_files = []
    cat = nil
    cat_file = $args["-cat"]
    directory = File.dirname(cat_file)
    File.open(cat_file, "r") {|input| cat = XML.parse(input) }
    cat.each do |c|
      if c.tag == "public" || c.tag == "system" then
        dtd_files << c.attributes["uri"] if c.attributes["uri"] 
      end
    end
    dtd_files.uniq!
    dtd_files.each do |dtd_file|
      File.open("#{directory}/#{dtd_file.strip}", "r") {|input| DTD.buildValidationEngine(input, elements) }
    end
  elsif $args["-xsd"] then
    # use XSD file for validation
    xsd_files = $args["-xsd"]
    xsd = nil
    xsd_files.split(",").each do |xsd_file|
      File.open(xsd_file.strip, "r") {|input| xsd = XML.parse(input) }
      XSD.buildValidationEngine(xsd, elements)
    end
  elsif $args["--html"] then
    # default to using the HTML XSD file
    File.open("#{File.dirname(File.expand_path(__FILE__))}/lib/xhtml1-strict.xsd.xml", "r") {|input| xsd = XML.parse(input) }
    XSD.buildValidationEngine(xsd, elements)
  elsif $args["-dtd"] then
    # use DTD file for validation
    dtd_files = $args["-dtd"]
    dtd_files.split(",").each do |dtd_file|
      File.open(dtd_file.strip, "r") {|input| DTD.buildValidationEngine(input, elements) }
    end
  else
    # default to using the Zonbook XSD file
    File.open("#{File.dirname(File.expand_path(__FILE__))}/lib/zonbook.xsd.xml", "r") {|input| xsd = XML.parse(input) }
    XSD.buildValidationEngine(xsd, elements)
  end
  
  # run validaton engine against the XML file(s)...
  $nargs.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
    files << arg
  end
  files << "." if files.length < 1 

  x = nil
  files.each do |arg| 
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{html,xml}")
      if $args["--img"] then
        $images = Dir.glob("#{arg}/**/*.{png,jpg,gif,bmp}")
        $images_used = []
      end
    else
      a = [arg]
    end
  
    link_duplicates = []
    unless $args["--nolink"] then 
      # first, gather all link targets...
      a.each do |fn|
        #~ $stderr.puts fn
        next if File.directory?(fn)
        next if fn =~ /(\/|^)(build|zonbook\.redirects)\.xml$/
        $stderr.puts fn  # debug
        File.open(fn, "r") {|input| x = XML.parse(input, (fn =~ /\.html?$/)) }
        x.record_link_targets($link_targets)
      end
      
      $link_targets.sort!
      prev_target = nil
      $link_targets.each do |target|
        link_duplicates << target if target == prev_target
        prev_target = target
      end
      #~ $stderr.puts link_duplicates.join(",")  # debug
    end
      
    
    a.each do |fn|
      #~ $stderr.puts fn
      next if File.directory?(fn)
      xi = false
      if fn =~ /(\/|^)(build|zonbook\.redirects)\.xml$/ then
        puts "\nskipping file: #{fn}"
        next
      elsif fn =~ /book\.xml$/ then
        xi = true
      end
      found = false
      File.open(fn, "r") do |input|  
        x = XML.parse_p(input, (fn =~ /\.html?$/)) do |line, start_column, context, buffer| 
          # deal with any basic XML syntax errors here; validation will be done later
          if buffer[0..5] == "ERROR:" then
            puts "\n>>>File: #{fn}" unless found
            puts buffer[6..-1]
            found = true
            if error_file then
              error_out = File.open(error_file, "w") unless error_out
              error_out.puts "#{fn}:#{buffer[6..-1]}"
            end
          end
        end
      end
      
      x.each do |y|
        next if y.tag[0] == "!" || y.tag[0] == "?"
        results = y.validate(elements: elements, verbose: $args["--verbose"], xi: xi, 
             suggest: $args["--suggest"], ignore: ["update", "updates", "details"], 
             do_json: $args["--json"], strict: $args["--strict"])

        results += y.image_check($images, $images_used)  if $args["--img"] 

        results.each do |r|
          puts "\n>>>File: #{fn}" unless found
          puts r 
          found = true
          if error_file then
            error_out = File.open(error_file, "w") unless error_out
            error_out.puts "#{fn}:#{r}"
          end
        end
      end
     
      unless $args["--nolink"] then 
        results =  x.internal_link_check($link_targets, $link_attributes) 
        results.each do |r|
          puts "\n>>>File: #{fn}" unless found
          puts r 
          found = true
          if error_file then
            error_out = File.open(error_file, "w") unless error_out
            error_out.puts "#{fn}:#{r}"
          end
        end
      end
      
      unless link_duplicates.empty? then
        results =  x.duplicate_link_check(link_duplicates)
        results.each do |r|
          puts "\n>>>File: #{fn}" unless found
          puts r 
          found = true
          if error_file then
            error_out = File.open(error_file, "w") unless error_out
            error_out.puts "#{fn}:#{r}"
          end
        end
      end
      
    end

    if $args["--img"] && !$images.empty? then
      puts "\n\nThe following images are present but not referenced:"
      puts $images.join("\n")
    end
      
  end
  
  if error_out then
    error_out.close
    if RUBY_PLATFORM.include?("mingw") then
      puts "aha! pronoun trouble!"
    else
      exec "vim -q #{error_file}" 
    end
  end
  
end

