#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'json'
require 'stringio'
require 'XML.rb'
require 'binary_search.rb'
require 'args.rb'

  
if __FILE__ == $0 then
  
  x = nil
  the_all = XML.new
  
  get_args
  files = []

  if $nargs.empty? then
    files += Dir.glob("./*/model/*.{xml}")
    files += Dir.glob("./*/model-src/*.{xml}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         #files += Dir.glob("./*/model/*.{xml}")
         files += Dir.glob("./*/model/**/*.{xml}")
         files += Dir.glob("./*/model-src/**/*.{xml}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{xml}")
       else
         files << narg
       end
     end  # $nargs.each
  end
    
  $stderr.puts ">>> reading files..."    
  files.each do |f|
    next if $args["-ex"] && f =~ Regexp.new($args["-ex"])
    $stderr.puts "  " + f
    File.open(f, "r") {|input| x = XML.parse(input) }
    the_all.child += x.child
  end
  
  $stderr.puts "\n>>> parsing definitions..." 
  stuff = the_all.parse_definitions
    
  $stderr.puts "\n>>> writing yaml file..." 
  puts YAML.dump(stuff)

 
end

