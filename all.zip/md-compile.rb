#!ruby

  if RUBY_VERSION =~ /^1.8/ then
    class String
      def force_encoding(enc)
        self
      end
      def clear()
        ""
      end
    end
  end
  

if __FILE__ == $0 then

  manifest_file = "manifest"
  output_file = "book.md"

  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^--help$/i then
        $stderr.puts "syntax:\n  md-compile.rb  -m <manifest-file-name>  -o <output-file-name> ..."
        $stderr.puts "    -m <file-name>         : manifest file with ordered list of files to combine"
        $stderr.puts "    -o <file-name>         : combined file to be written"
        $stderr.puts "\n\nsimplified syntax:\n  md-compile.rb"
        $stderr.puts "    defaults to: md-compile.rb  -m manifest  -o book.md"
        exit
      when /^-m$/i then
        i += 1
        manifest_file = ARGV[i] if ARGV.length > i
      when /^-o$/i then
        i += 1
        output_file = ARGV[i] if ARGV.length > i
      end
      i += 1
  end

  title = "Markdown compile- manifest-file: #{manifest_file} output-file: #{output_file} #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts title
  puts "=" * title.length
 
 
  files = []
  File.open(manifest_file, "r") do |input|
    while line = input.gets do
      begin
        if line =~ /^\s*#/ || line.empty? then
          # comment - ignore
        else
          files << line.chomp
        end
      end
    end
  end

  i = 0
  len = files.length
  count = 0 
  output = File.open(output_file, "w")
  # link_re = /(^|[^\\])\[([^\]]+)\]\(([^#\)]*)(#[^\)]+)?\)/
  link_re = /(^|[^\\])\[(.+)\]\(([^#\)]*)(#[^\)]+)?\)/
 
  files.each do |fn|
    # $stderr.puts "\n>>>File: #{fn}"  # debug
    File.open(fn, "r") do |input|
      while line = input.gets do
        offset = 0
        output_line = ""
        remainder = line

        begin
          while pos = (line =~ link_re) do
            remainder = String.new($')
            output_line << String.new($`)  # pre-match

            bif = String.new($1)
            title = String.new($2)
            link_fn = String.new($3)
            link_frag = String.new($4 || "")
            # $stderr.puts "[1:#{$1} 2:#{$2} 3:#{$3} 4:#{$4}]"  # debug

            if link_frag.empty? then
              output_line << $&  # whole match
            else
              if files.include?(link_fn) then
                output_line << "#{bif}[#{title}](#{link_frag})"
                count += 1
              else
                output_line << "#{bif}[#{title}](#{link_fn}#{link_frag})"
              end
            end
            offset = line.length - remainder.length
            line = remainder
          end
        rescue
          # try it this way to avoid encoding error...
          while pos = (line.force_encoding("ISO-8859-1") =~ link_re) do
            remainder = $'
            output_line << $`

            bif = String.new($1)
            title = String.new($2)
            link_fn = String.new($3)
            link_frag = String.new($4 || "")
            # $stderr.puts "[1:#{$1} 2:#{$2} 3:#{$3} 4:#{$4}]"  # debug

            if link_frag.empty? then
              output_line << $&  # whole match
            else
              if files.include?(link_fn) then
                output_line << "#{bif}[#{title}](#{link_frag})"
                count += 1
              else
                output_line << "#{bif}[#{title}](#{link_fn}#{link_frag})"
              end
            end
            offset = line.length - remainder.length
            line = remainder

          end
        end  # rescue

        output_line << remainder
        output.print output_line 
      end
    end
   
    i += 1
    output.puts "\n<div class=\"page\"></div>\n\n" unless i >= len
  end

  output.close
  puts "#{count.to_s} links changed."

end

