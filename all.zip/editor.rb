#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'args.rb'


if __FILE__ == $0 then
 
  find = /\n\s*/
  replace = " " 
  files = []
  get_args(min: 1, nmin: 1, syntax: "editor.rb <file or directory> ... [-f <regular-expression>] [-r <replacement-string>]")
  $stderr.puts $args
  $stderr.puts $nargs

  find = $args.has_key?("-f") ? Regexp.new($args["-f"]) : find
  replace = $args.has_key?("-r") ? $args["-r"] : replace
  
  puts "======================================"
  puts "HTML/XML Editor  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "======================================"
  puts "find: /#{find}/  replace: '#{replace}'"
  
  $nargs.each do |narg|
    next if narg[0,1] == "-"
    files << narg
  end

  x = nil
  files.each do |arg|
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{html,xml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $fn = fn
      print fn
      File.open(fn, "r") do |input|  
        x = XML.parse(input, (fn =~ /\.html?$/))
      end
      x.each do |y|
        if y.tag == "para" then
          y.each do |z|
            z.pcdata.gsub!(find, replace)
          end
        end
      end
      newfn = fn.sub(/\.[^.]+$/) {|str| ".new" + str } 
      puts " --> " + newfn
      File.open(newfn, "w") do |output|
        output.puts x
      end
    end
  end
  
end
