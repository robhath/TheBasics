#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'binary_search.rb'

  $words = [] if $words.nil?
  $word_counts = Hash.new(0)
  $section_id = nil
  $do_wc = nil
  $shy = true  # split hyphenated words and check each individually

  $learned = []
  $learning = {}
  
  if $words.empty? then
    # assume word list all downcase and already sorted...
    File.open("#{File.dirname(File.expand_path(__FILE__))}/lib/words.txt", "r:ISO-8859-1:UTF-8") do |input| 
      while line = input.gets do
        if line =~ /^\s*#/ then
          # comment
        else
          $words << line.chomp
        end
      end
    end
  end


  def spell_check(line, start_column, context, buffer, learn = false)
    #~ $stderr.puts "spell_check() line=#{line} start_column=#{start_column} context[#{context.join(",")}] buffer[#{buffer}]"
    prev_word = ""  # check for duplicated words
    count = 0
    return count if buffer[0] == "<" || context.include?("head") || context.include?("script") || context.include?("code") ||
        context.include?("pre") || context.include?("programlisting") || context.include?("filename") || 
        context.include?("callout") || context.include?("noloc")

    # word counts...
    unless $do_wc.nil? then
      ci = context.index {|c| c.start_with?("chapter", "section") } 
      if ci then
        tagplus = context[ci].split(",")
        if tagplus[0] = "chapter" ||
           (i = tagplus.index("role") && tagplus[i+1] == "topic") then
          if id = tagplus.index("id") then
            section_id = tagplus[id+1]
            if $do_wc == "yes" && $section_id != section_id && !$word_counts.empty? then 
              unless $section_id.nil? then
                puts "\n<<<Word counts for #{$section_id}>>>"
                wc = $word_counts.to_a.sort! {|a,b| a[0] <=> b[0] }
                wc.sort! {|a,b| a[1] <=> b[1] }
                wc.each {|x| puts "  #{x.join(",")}" }
                $word_counts = Hash.new(0)
              end
              $section_id = section_id
            end
          end
        end
      end
    end
 
    if buffer[0..5] == "ERROR:" then
      $stderr.puts "\n>>>File: #{$fn}" unless $found
      $stderr.puts buffer[6..-1]
      if $error_file then
        $error_out = File.open($error_file, "w") unless $error_out
        $error_out.puts "#{$fn}:#{buffer[6..-1]}"
      end
      $found = true
    
    else
      lines = buffer.split("\n")
      line -= buffer.count("\n")
      lines.each do |str|
        line_len = str.length
        offset = (start_column > 0 ? start_column : 1)
        #~ $stderr.puts "   line=#{line} start_column=#{start_column} str[#{str}]"
        while pos = (str =~ /(&[-_\w]+;)|((?<=\b)(a|I)(?= ))|((?<=\b)(([A-Za-z][a-z]+)(-([A-Za-z][a-z]+))?)('d|'s|'ll|'t|'ve|'re)?(?=\b))/) do
          pre = $`
          w = $&
          str = $'
          count += 1
          # $stderr.puts "pre[#{pre}] w[#{w}] str[#{str}] 1[#{$1}] 2[#{$2}] 3[#{$3}] 4[#{$4}] 5[#{$5} 6[#{$6}]] 7[#{$7}]"  # debug
          if w[0,1] == "&" && w[-1,1] == ";" then
            offset += pre.length + w.length
            prev_word = String.new(w)
            next  # skip entity
          end
          $word_counts[w.downcase] += 1 unless $do_wc.nil?
          if learn && $learned.include?(w) || 
            $words.binary_search(w.downcase) ||
            # ($4 && !$4.empty? && $words.binary_search($2.downcase) && $words.binary_search($4.downcase)) then
            ($shy && $7 && !$7.empty? && $words.binary_search($6.downcase) && $words.binary_search($7[1..-1].downcase)) then
            if w == prev_word then
              unless pre =~ /\w/ then
                $stderr.puts "\n>>>File: #{$fn}" unless $found
                $stderr.puts "repeated '#{w}' loc=#{line},#{(pos + offset)}"
                if $error_file then
                  $error_out = File.open($error_file, "w") unless $error_out
                  $error_out.puts "#{$fn}:#{line}:#{(pos + offset)}:repeated '#{w}'"
                end
                $found = true
              end
            else
              #~ $stderr.puts "#{w} okay"
            end
          else
            $stderr.puts "\n>>>File: #{$fn}" unless $found
            $stderr.puts "#{w} loc=#{line},#{(pos + offset)}"
            if learn && w.downcase != "aws" then
              if $learning.has_key?(w) then
                if $learning[w] = 2 then
                  $learned << w
                  $stderr.puts "!!! #{w} suppressed"
                end
                $learning[w] += 1
              else
                $learning[w] = 0
              end
            end
            if $error_file then
              $error_out = File.open($error_file, "w") unless $error_out
              $error_out.puts "#{$fn}:#{line}:#{(pos + offset)}:#{w}"
            end
            $found = true
          end
          offset += pre.length + w.length
          prev_word = String.new(w)
        end
        line += 1
        start_column = 0
      end
    end
    return count
  end  # spell_check


if __FILE__ == $0 then
  
  $error_file = nil
  $error_out = nil
  $fn = nil
  $found = false
  files = []

  if ARGV.length < 1 then
    files << "."
  elsif i = ARGV.index("-help") || i = ARGV.index("--help") then
    $stderr.puts "spell-chk.rb <file or directory> ... [--edit] [--learn] [--wc] [--nshy]"
    exit
  end
  
  $stderr.puts "============================================="
  $stderr.puts "HTML/XML Spell Checker  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  $stderr.puts "============================================="
  
  if i = ARGV.index("--edit") then
    $error_file = "#{ENV["HOME"]}/.spell_checker.err.txt"
  end
  if i = ARGV.index("--learn") then
    $do_learn = true
  end
  if i = ARGV.index("--wc") then
    $do_wc = "yes"
  end
  if i = ARGV.index("--wcall") then
    $do_wc = "all"
  end
  if i = ARGV.index("--nshy") then
    $shy = false
  end
  
  ARGV.each do |arg|
    next if arg[0,1] == "-"
    files << arg
  end
  files << "." if files.empty?

  count = 0
  x = nil
  files.each do |arg|
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{html,xml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $found = false
      $fn = fn
      File.open(fn, "r") do |input|  
        x = XML.parse_p(input, (fn =~ /\.html?$/)) {|line, start_column, context, buffer| 
                count += spell_check(line, start_column, context, buffer, $do_learn) }
      end
      
    end
  end

  if $do_wc then  
    if $do_wc == "yes" then
      puts "\n<<<Word counts for #{$section_id}>>>" 
    else
      puts "\n<<<Word counts>>>" 
    end
    wc = $word_counts.to_a.sort! {|a,b| a[0] <=> b[0] }
    wc.sort! {|a,b| a[1] <=> b[1] }
    wc.each {|x| puts "  #{x.join(",")}" }
  end

  $stderr.puts "\nTotal word count = #{count}"
 
  if $error_out then
    $error_out.close
    exec "vim -q #{$error_file}" 
  end
  
end
