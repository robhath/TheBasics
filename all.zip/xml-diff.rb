#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'args.rb'
require 'diff.rb'


  def diff_it(fn1, fn2)
    x = []
    y = []
    xin = File.open(fn1, "r:UTF-8")
    yin = File.open(fn2, "r:UTF-8")
    while line = xin.gets do x << line.chomp end
    while line = yin.gets do y << line.chomp end
    xin.close
    yin.close
    return diff(x, y)
  end  # diff_it


  def diff_it_ignore_ws(fn1, fn2)
    x = []
    y = []
    xin = File.open(fn1, "r:UTF-8")
    yin = File.open(fn2, "r:UTF-8")
    while line = xin.gets do x << line.chomp.gsub(/[ \t]+/, " ") end
    while line = yin.gets do y << line.chomp.gsub(/[ \t]+/, " ") end
    xin.close
    yin.close
    return diff(x, y)
  end  # diff_it_ignore_ws


  def text_diff_it(fn1, fn2)
    x = nil
    y = nil

    File.open(fn1, "r") do |input|
      x = XML.parse_p(input, (fn1 =~ /\.html?$/i))
    end
    xlines = []
    xpos = ["0"]
    if fn1 =~ /\.html?$/i then
      xstr = x.to_txt_canonical(block_tags: XML::HTML_BLOCK_TAGS, pre_tags: XML::HTML_PRE_TAGS, skip_tags: XML::HTML_SKIP_TAGS)
    else
      xstr = x.to_txt_canonical
    end
    xstr.each_line do |line|
      a, b = line.chomp.split("\t")
      xlines << a || ""
      xpos << b || ""
    end
    File.open(fn2, "r") do |input|
      y = XML.parse_p(input, (fn2 =~ /\.html?$/))
    end
    ylines = []
    ypos = ["0"]
    if fn2 =~ /\.html?$/i then
      ystr = y.to_txt_canonical(block_tags: XML::HTML_BLOCK_TAGS, pre_tags: XML::HTML_PRE_TAGS, skip_tags: XML::HTML_SKIP_TAGS)
    else
      ystr = y.to_txt_canonical
    end
    ystr.each_line do |line|
      a, b = line.chomp.split("\t")
      ylines << a || ""
      ypos << b || ""
    end

    return diff(xlines, ylines, xpos, ypos)
  end  # text_diff_it


  def tags_diff_it(fn1, fn2)
    x = nil
    y = nil

    File.open(fn1, "r") do |input|
      x = XML.parse_p(input, (fn1 =~ /\.html?$/i))
    end
    xlines = []
    xpos = ["0"]
    xstr = x.to_tags_canonical
    xstr.each_line do |line|
      a, b = line.chomp.split("\t")
      xlines << a
      xpos << b || ""
    end
    File.open(fn2, "r") do |input|
      y = XML.parse_p(input, (fn2 =~ /\.html?$/))
    end
    ylines = []
    ypos = ["0"]
    ystr = y.to_tags_canonical
    ystr.each_line do |line|
      a, b = line.chomp.split("\t")
      ylines << a
      ypos << b || ""
    end

    return diff(xlines, ylines, xpos, ypos)
  end  # tags_diff_it


if __FILE__ == $0 then
 
  get_args(nmin: 2, nsyntax: "xml-diff.rb <file|directory> <file|directory> [--txt|--tags|--i] [--html] [--md] [-exclude <file1>,<file2>,...]")

  exclusions = []
  exclusions += $args["-exclude"].split(",") if $args.has_key?("-exclude")
 
  puts "===================================="
  puts "XML/HTML Diff  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "===================================="


  if File.directory?($nargs[0]) then
    if File.directory?($nargs[1]) then
      path0 = File.absolute_path($nargs[0])
      path1 = File.absolute_path($nargs[1])

      if $args["--md"] then
        $args["--i"] = false
        $args["--txt"] = false
        $args["--tags"] = false
        files0 = Dir.glob("#{$nargs[0]}/**/*.{md}")
        files1 = Dir.glob("#{$nargs[1]}/**/*.{md}")
      else
        files0 = Dir.glob("#{$nargs[0]}/**/*.{#{$args["--html"] ? "html" : "xml"}}")
        files1 = Dir.glob("#{$nargs[1]}/**/*.{#{$args["--html"] ? "html" : "xml"}}")
      end

      files0.delete_if do |f0| 
        if File.directory?(f0) then
          true  # skip and delete
        else
          # i = files1.find_index {|f1| File.basename(f0) == File.basename(f1) }
          p0len = $nargs[0].length
          p1len = $nargs[1].length
          i = files1.find_index {|f1| f0[p0len+1..-1] == f1[p1len+1..-1] }
          if i then
            unless exclusions.index(File.basename(f0)) then
              if $args["--i"] then
                buffer = diff_it_ignore_ws(f0, files1[i])
                if buffer.length > 0 || $args["--verbose"] then
                  puts ">>>>> #{f0} vs. #{files1[i]} IGNORE WHITESPACE <<<<<"
                  puts buffer
                  puts 
                end
              elsif $args["--txt"] then
                puts ">>>>> #{f0} vs. #{files1[i]} TEXT <<<<<"
                puts text_diff_it(f0, files1[i])
                puts
                # buffer = text_diff_it(f0, files1[i])
                # if buffer.length > 0 || $args["--verbose"] then
                  # puts ">>>>> #{f0} vs. #{files1[i]} TEXT <<<<<"
                  # puts buffer
                  # puts 
                # end
              elsif $args["--tags"] then
                buffer = tags_diff_it(f0, files1[i])
                if buffer.length > 0 || $args["--verbose"] then
                  puts ">>>>> #{f0} vs. #{files1[i]} TAGS <<<<<"
                  puts buffer
                  puts
                end
              else
                buffer = diff_it(f0, files1[i])
                if buffer.length > 0 || $args["--verbose"] then
                  puts ">>>>> #{f0} vs. #{files1[i]} <<<<<" 
                  puts buffer
                  puts
                end
              end
            end
            files1.delete_at(i)
            true 
          else
            false
          end
        end
      end

      unless files0.empty? && files1.empty? then
        puts ">>>>> The following files in #{$nargs[0]} did not have a match: <<<<<"
        puts files0.join(", ")
        # files0.each {|f0| puts f0 }
        puts ">>>>> The following files in #{$nargs[1]} did not have a match: <<<<<"
        puts files1.join(", ")
        # files1.each {|f1| puts f1 }
      end
    else
      $stderr.puts "ERROR: cannot compare a file with a directory"
    end
  elsif File.directory?($nargs[1]) then
    $stderr.puts "ERROR: cannot compare a file with a directory"
  else
    if $args["--i"] then
      puts ">>>>> #{$nargs[0]} vs. #{$nargs[1]} IGNORE WHITESPACE <<<<<"
      puts diff_it_ignore_ws($nargs[0],$nargs[1])
    elsif $args["--txt"] then
      puts ">>>>> #{$nargs[0]} vs. #{$nargs[1]} TEXT <<<<<"
      puts text_diff_it($nargs[0],$nargs[1])
    elsif $args["--tags"] then
      puts ">>>>> #{$nargs[0]} vs. #{$nargs[1]} TAGS <<<<<"
      puts tags_diff_it($nargs[0], $nargs[1])
    else
      puts ">>>>> #{$nargs[0]} vs. #{$nargs[1]} <<<<<"
      puts diff_it($nargs[0], $nargs[1])
    end
  end
end
