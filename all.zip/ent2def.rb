#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'
require 'diff.rb'

if __FILE__ == $0 then

syntax_text = <<EOS
ent2def.rb - convert entities to their definitions
  | parameter                            | description (default) [Optional/Required]               |
  | ------------------------------------ | ------------------------------------------------------- |
  | <file-or-directory-name>...          | wsl of files or dirs to modify (.) [O]                  |
  | -ent <list of entity-def-files/dirs> | csl of files or dirs (*.ent) with entity definitions    |
  |                                      |  ("#{ENV["HOME"]}/bin/lib/entities.txt") [O]            |
  | -f <find-re-with/1group>             | regex of entity with 1 group ('&([^&\s;]+);') [O]       |
  |                                      |   note: use '{([^}]+)}' or similar for asciidoc         |
  | -ext <file-extensions>               | csl of extensions of files to modify (html,xml) [O]     |
  | -diff (yes|diff-file-name)           | make diff? or diff filename ("diff.ent2def.txt") [O]    |
  | -pre <entity-prefix>                 | string used as created entity prefix ("&") [O]          |
  | -post <entity-postfix>               | string used as created entity postfix (";") [O]         |
  | --chgs                               | ? show unique list of changes made [O]                  |
  | --ow                                 | ? overwrite modified files, o/w create .new files [O]   |
  | --i                                  | ? make entity definition regex's case-insensitive [O]   |
  | --m                                  | ? make entity definition regex's multi-line [O]         |
  | --x                                  | ? make entity definition regex's extended syntax [O]    |
  | --help                               | ? output this help text and exit [O]                    |
EOS
  
  get_args(min: 0, nmin: 0, syntax: syntax_text)
  files = []
  changed_files = []
  extensions = $args["-ext"] || "html,xml"
  diff_file = nil
  diff_out = nil
  the_changes = ($args["--chgs"] ? Array.new : nil)

  if $nargs.empty? then
    files += Dir.glob("./**/*.{#{extensions}}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{#{extensions}}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{#{extensions}}")
       else
         files << narg
       end
     end  # $nargs.each
  end

  options = nil
  options = (options ? options | Regexp::MULTILINE : Regexp::MULTILINE) if $args["--m"] 
  options = (options ? options | Regexp::IGNORECASE : Regexp::IGNORECASE) if $args["--i"] 
  options = (options ? options | Regexp::EXTENDED : Regexp::EXTENDED) if $args["--x"] 
  if options then
    findRE = Regexp.new(($args["-f"] || "&([^&\\s;]+);"), options)
  else
    findRE = Regexp.new(($args["-f"] || "&([^&\\s;]+);"))
  end
  if $args["-diff"] then
    diff_file = ($args["-diff"] == "yes" ? "diff.ent2def.txt" : $args["-diff"])
  end

  not_defined = []
  edefinitions = {}
  edef_files = []
  if $args["-ent"] then
    $args["-ent"].split(",") do |edef_fn|
      if edef_fn == "." then
        edef_files += Dir.glob("./**/*.ent")
      elsif File.directory?(edef_fn) then
        edef_files += Dir.glob("#{edef_fn.gsub("\\", "/")}/**/*.ent")
      else
        edef_files << edef_fn
      end
    end 
  else
    edef_files << "#{ENV["HOME"]}/bin/lib/entities.txt"
  end
  edef_files.each do |edef_fn|
    # $stderr.puts "edef_fn[#{edef_fn}]"  # debug
    File.open(edef_fn, "r") do |input|
      buffer = input.read
      if buffer[0..255] =~ /^:[\w_-]+:\s+/ then
        pos = 0
        remainder = ""
        while pos = (buffer =~ /^\s*:([\w_-]+):\s+(.+?)$/) do
          remainder = $'
          key = String.new($1)
          value = String.new($2)
          # $stderr.puts "1[#{$1}] 2[#{$2}]"
          $stderr.puts "duplicate definition found for '#{key}'" if edefinitions[key]
          edefinitions[key] = value
          buffer = remainder
        end
      else
        pos = 0
        remainder = ""
        while pos = (buffer =~ /<!ENTITY\s*(\S+)\s*('|")([^\2]*?)\2\s*>/) do
          remainder = $'
          key = String.new($1)
          value = String.new($3)
          # $stderr.puts "1[#{$1}] 2[#{$2}] 3[#{$3}]"
          $stderr.puts "duplicate definition found for '#{key}'" if edefinitions[key]
          edefinitions[key] = value
          buffer = remainder
        end
      end
    end
  end
  # find all entities in the entity definitions and try to resolve those...
  edefinitions.each_value do |value|
    value.gsub!(findRE) do |str|
      definition = $1
      if edefinitions[definition] then
        edefinitions[definition]
      else
        not_defined << definition unless not_defined.include?(definition)
        str
      end
    end
  end
  # edefinitions.each {|key, value| $stderr.puts ":#{key}: #{value}" }  # debug

  show_it = "Convert Entities to their Definitions: find=[#{findRE}] #{edefinitions.length} definitions "
  puts show_it
  puts ("-" * show_it.length)

  count = 0
  files.each do |f|
    buffer = String.new
    old_buffer_array = Array.new
    changed = false
    puts ">>> " + f
    buffer = ""
    File.open(f, "r") do |input|
      buffer = input.read
      old_buffer_array = buffer.split("\n") if diff_file
      buffer.gsub!(findRE) do |str|
        definition = $1
        if edefinitions[definition] then
          print "*"
          changed = true
          count += 1
          the_changes << "#{$&} => #{edefinitions[definition]}" if the_changes
          edefinitions[definition]
        else
          not_defined << definition unless not_defined.include?(definition)
          str
        end
      end
    end  # File.open

    puts
    if changed then
      changed_files << f
      File.open(f + ".new", "w") do |output|
        output.print buffer
      end

      if diff_file then
        diff_out = File.open(diff_file, "w") unless diff_out
        diff_out.puts "file: #{f}"
        diff_out.puts diff(old_buffer_array, buffer.split("\n"))
        diff_out.puts "\n\n"
      end
    end

  end  # files.each

  if $args["--ow"] then
    changed_files.each do |f|
      File.delete(f)
      File.rename(f + ".new", f)
    end
  end

  if the_changes then
    puts "\nThe following changes were made:"
    the_changes.uniq!
    puts the_changes.join("\n")
  end

  $stderr.puts "\nEntities not defined/replaced: #{not_defined.join(",")}"
  puts "\n#{count.to_s} instances replaced"
end

