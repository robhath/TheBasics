#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'
require 'json'

if __FILE__ == $0 then
  
  get_args(min: 2, nmin: 1, syntax: "mem-est.rb <json-file-name>... -o <xml-output-file-name> ")

  ### These are the key values used, so we will use them to verify that the JSON has them in the right order.
  #     It would be better if the JSON contained matching keys so that values could be correctly associated,
  #     or if the JSON contained arrays of values in a guaranteed order, but because these keys do not match
  #     we're reduced to just checking that the JSON has items in this arbitrary order.
  column_labels = ["files_column_header", "files_o1_header", "files_os_header"]
  entry_labels = ["file_name", "o1_size", "os_size"]
  total_entry_labels = ["total_header", "total_o1", "total_os"]

  output = File.open($args["-o"], "w:UTF-8")
  output.puts <<EOS
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE section PUBLIC "-//OASIS//DTD DocBook XML V4.5//EN" "file://zonbook/docbookx.dtd"
 [
  <!ENTITY % common-freertos SYSTEM "common-freertos.ent"> %common-freertos;
  <!ENTITY % xinclude SYSTEM "file://AWSShared/common/xinclude.mod"> %xinclude;
  <!ENTITY % phrases-shared SYSTEM "file://AWSShared/common/phrases-shared.ent"> %phrases-shared;
 ]>
<section id="memory-estimates" role="topic">
    <info>
        <title id="memory-estimates.title">Memory estimates</title>
    </info>

EOS

  $nargs.each do |narg|
    j = JSON.parse(IO.read(narg)) 
    j.each_pair do |key, value|
      $id = key
      value.each_pair do |k, v|
        case k
          when "table_header"
            $table_header = v
          when "column_header" 
            $ch = []; i = 0
            v.each_pair do |h, d|
              $stderr.puts "ERROR: column headers out of order" unless column_labels[i] == h
              $ch << d
              i += 1
            end
          when "files"
            $files = []
            v.each do |finfo|
              $files << []; i = 0
              finfo.each_pair do |title, str|
                $stderr.puts "ERROR: entries out of order" unless entry_labels[i] == title
                $files[-1] << str
                i += 1
              end
            end
          when "total"
            $totals = []; i = 0
            v.each_pair do |h, t|
              $stderr.puts "ERROR: totals out of order" unless total_entry_labels[i] == h
              $totals << t
              i += 1
            end 
        end
      end

      output.puts <<EOS 
    <table id=\"#{$id}-memory-estimate\">
        <title></title>
        <tgroup cols="#{$ch.length}" align="left">
EOS

      $ch.each_index do |i|
          output.puts <<EOS
            <colspec colnum="#{i+1}" colname="c#{i+1}" colwidth="2*"/>
EOS
      end

      $table_header.gsub!(/AWS\s*IoT/i, "&IoT;")
      $table_header.gsub!(/(^|[^&])AWS/i, "&AWS;")
      output.puts <<EOS
            <thead>
                <row>
                    <entry namest="c1" nameend="c3">#{$table_header}</entry>
                </row>
                <row>
EOS

      $ch.each do |ch|
          ch.gsub!(/AWS\s*IoT/i, "&IoT;")
          ch.gsub!(/(^|[^&])AWS/i, "&AWS;")
          output.puts <<EOS
                    <entry>#{ch}</entry>
EOS
      end
      output.puts <<EOS
                </row>
            </thead>
            <tbody>
EOS

      $files.each do |row|
        output.puts "              <row>"
        row.each do |entry|
            entry.gsub!(/AWS\s*IoT/i, "&IoT;")
            entry.gsub!(/(^|[^&])AWS/i, "&AWS;")
            output.puts "                 <entry>#{entry}</entry>"
        end
        output.puts "              <\/row>"
      end

      output.puts "              <row>"
      $totals.each do |total|
        total.gsub!(/AWS\s*IoT/i, "&IoT;")
        total.gsub!(/(^|[^&])AWS/i, "&AWS;")
        output.puts "                  <entry><emphasis role=\"bold\">#{total}</emphasis></entry>"
      end
      output.puts "              <\/row>"

      output.puts <<EOS
            </tbody>
        </tgroup>
    </table>
EOS

    end
  end
  output.puts "</section>"
  output.close

end

