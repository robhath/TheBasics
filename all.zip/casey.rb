#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'args.rb'

  
if __FILE__ == $0 then
  
  x = nil
  error_file = nil
  error_out = nil
  edit_files = false
  count = 0
  
  get_args
  files = []
  if $args["--edit"] then
    error_file = "#{ENV["HOME"]}/.srch.err.txt"
    edit_files = true
  end


  puts "Change Title Case  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "==================================="

  da_tags = Regexp.new($args["-tags"] || "(title|titleabbrev)")
 
  if $nargs.empty? then
    files += Dir.glob("./**/*.{html,xml}")
    files += Dir.glob("./**/*.{html,xml}")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{html,xml}")
         files += Dir.glob("./**/*.{html,xml}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{html,xml}")
       else
         files << narg
       end
     end  # $nargs.each
  end
    
  files.each do |f|
    next if $args["-ex"] && f =~ Regexp.new($args["-ex"])
    puts f
    changed_file = false
    File.open(f, "r") {|input| x = XML.parse_p(input) }
    x.each do |y|
      if y.tag =~ da_tags then
        first_word = true
        changed_item = false
        prev = y.get_pcdata
        y.each do |z|
          if z.tag.empty? then
            z.pcdata.gsub!(/(^|\s|-)((A|[A-Z][a-z]+)|([^\s-]+))(?=\b)/) do |str|
              if first_word || $3.nil? then
                first_word = false
                str # no change
              else
                # $stderr.puts "str[#{$&}] 1[#{$1}] 2[#{$2}] 3[#{$3}] 4[#{$4}] 5[#{$5}]"
                changed_item = true
                changed_file = true
                count += 1
                (($1 || "") + ($args["-up"] ? $3.upcase : $3.downcase))
              end
            end
          end
        end # y.each
        if changed_item then
          puts "#{y.pos}: #{prev} >>> #{y.get_pcdata}"
          if error_file then
            error_out = File.open(error_file, "w") unless error_out
            error_out.puts "#{f}:#{y.pos}:#{prev}"
          end
        end
      end # if y.tag =~ da_tags
    end  # x.each
    if changed_file then
      if $args["-ow"] then
        File.open(f, "w") {|output| output.puts x.to_s }
      else
        File.open(f + ".new", "w") {|output| output.puts x.to_s }
      end
    end
  end
  $stderr.puts "#{count} changes made"
  error_out.close if error_out
  if edit_files && count >  0 then
    exec "vim -q #{error_file}" 
  end
  
end
