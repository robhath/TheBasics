#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

if __FILE__ == $0 then
  
  files = []

  re_str = ARGV[0]  # by default the first parameter
  re_options = 0
  re_list = nil
  re_list_status = nil
  add_filenames = false
  dir = "."  # by default the current directory
  extensions = ["html", "md", "txt", "xml", "ent", "rb", "c", "h", "json", "smithy"]  # by default
  new_extensions = false
  error_file = nil
  nerror_file = nil
  error_out = nil
  nerror_out = nil
  edit_files = false
  nedit_files = false
  eask = false
  count = 0
  ncount = 0
  ignore_list = []
  show_context = false
  show_link = false
  path_to_output = "???"
  hn = "???"

  i = 0
  while i < ARGV.length do
    case ARGV[i]
      when /^--help/i then
        puts "parameters:
  -p <RE patterns (comma delimited)>
  -d <directory>
  -e <error-file>
  -ext <file-extension-list>
  -ignore <string list>
  -ctx <base directory of output> 
  --i    -> re case-insensitive match
  --m    -> re multi-line mode
  --x    -> re extended mode 
  --edit -> usvim
  --eq   -> usvim, but ask first
  --ctx  -> show chapter/section context 
  --fns  -> use filenames as re patterns"
        exit
      when /^-ext$/ then
        extensions.clear unless new_extensions
        new_extensions = true
        while i < (ARGV.length - 1) && ARGV[i+1][0] != "-" do
          i += 1
          extensions << ARGV[i] 
          extensions[-1] = "*" if extensions[-1] == "all"
        end
        # extensions << $'  # following match
        # extensions[-1] = "*" if extensions[-1] == "all"
      when /^-p$/i then
        i += 1
        re_str = ARGV[i] if ARGV.length > i
        re_list = []
      when /^--fns$/
        re_str = ""
        add_filenames = true
        re_list = []
      when /^-d$/i then
        i += 1
        dir = ARGV[i] if ARGV.length > i
      when /^-e$/i then
        i += 1
        error_file = ARGV[i] if ARGV.length > i
      when /^--edit$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
      when /^--eq$/i then
        error_file = "#{ENV["HOME"]}/.srch.err.txt"
        edit_files = true
        eask = true
      when /^--ctx$/i then
        show_context = true
      when /^-ctx$/i then
        show_link = true
        i += 1
        if ARGV.length > i then
          path_to_output = String.new(ARGV[i])
          path_to_output.gsub!(/(^\/)|(\/$)/, "")
        end
        hn = `echo $HOSTNAME`.chomp 
      when /^--im$/i then
        re_options += Regexp::IGNORECASE
        re_options += Regexp::MULTILINE
      when /^--i$/i then
        re_options += Regexp::IGNORECASE
      when /^--m$/i then
        re_options += Regexp::MULTILINE
      when /^--x$/i then
        re_options += Regexp::EXTENDED
      when /^[^\-]/ then
        re_str = ARGV[i]
      when /^-ignore/i then
        i += 1
        ignore_list = ARGV[i].split(',') if ARGV.length > i
      end
      i += 1
  end

  re_file_list = []
  unless re_list.nil? then 
    re_str.split(",").each do |re_pattern|
      re_list << Regexp.new(re_pattern, re_options)
      re_file_list << Regexp.new("#{re_pattern}[^/]*$", re_options)
    end
  else
    re_list = [Regexp.new(re_str, re_options)]
    re_file_list = [Regexp.new("#{re_str}[^/]*$", re_options)]
  end

  a = Dir.glob("#{dir}/**/#{(extensions.empty? || extensions.index("*")) ? "*" : "*.{#{extensions.join(",")}}"}")
  if add_filenames then
    a.each do |fn|
      re_list << Regexp.new(fn[2..-1], re_options)
      re_file_list << Regexp.new(fn[2..-1], re_options)
    end  
    title = "Search dir=#{dir} ext=[#{extensions.join(" ")}]  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    puts title
    puts "ignore list [#{ignore_list.join(", ")}]" unless ignore_list.empty?
    puts "=" * title.length
  else
    title = "Search re=#{re_list.join("; ")} dir=#{dir} ext=[#{extensions.join(" ")}]  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    puts title
    puts "ignore list [#{ignore_list.join(", ")}]" unless ignore_list.empty?
    puts "=" * title.length
  end
  re_list_status = Array.new(re_list.length, false)
  # $stderr.puts re_list.join("; ")  # debug


  a.each do |fn|

    re_list.each_index do |re_index|


    is_directory = File.directory?(fn)
    if fn =~ re_file_list[re_index] then
      puts "\n>>>Matched filename: #{fn}#{is_directory ? "  (directory)" : ""}"
    end
    is_image = (fn =~ /\.(jpg|jpeg|png|tiff)/i)
    next if is_directory || is_image
    contexts = []


    File.open(fn, "r") do |input|  
      buffer = input.read

      found = false
      line_number = 1
      pos_in_line = 0
      prev_match_length = 0

      while pos = (buffer =~ re_list[re_index]) do
        preceding = $`
        remainder = $'
        da_match = $&

        if show_context || show_link then
          context_buffer = String.new(preceding + da_match + remainder[/^[^\n]*/])
          while context_pos = (context_buffer =~ /<(\/)?(chapter|section)([^>]+>|>)/m) do
            context = $&
            context_remainder = $'
            da_end = $1
            da_context = String.new($3)
            if da_end == "/" then
              contexts.pop 
            elsif da_context then
              if da_context =~ /id=('|")([^'"]+)/m then
                contexts.push $2 
                contexts.last << "*" if da_context =~ /role=('|")topic/m
              end              
            end 
            context_buffer = context_remainder 
          end
        end

        if !ignore_list.empty? && ignore_list.index(da_match.delete(" \t\r\n")) then
          # ignore it...
          line_number += preceding.count("\n") 
          pri = preceding.rindex("\n") 
          if pri.nil? then
            pos_in_line += pos + prev_match_length
          else
            pos_in_line = pos - pri
          end
          prev_match_length = da_match.length
          buffer = remainder
          next
        end

        puts "\n>>>File: #{fn}" unless found
        found = true
        re_list_status[re_index] = true
        line_number += preceding.count("\n") 
        pri = preceding.rindex("\n") 
        if pri.nil? then
          # $stderr.puts "prev_match_length=#{prev_match.length} pos=#{pos} pri=#{pri} preceding.length=#{preceding.length} pos_in_line=#{pos_in_line}"  # debug
          pos_in_line += pos + prev_match_length
        else
          pos_in_line = pos - pri
        end

        # $stderr.puts "da_match[#{da_match}] line_number=#{line_number.to_s} pos_in_line=#{pos_in_line} remainder[#{remainder[0..12]}]"  # debug
        count += 1
        puts "#{line_number}:#{pos_in_line}: #{pri ? preceding[pri+1..-1] : ""}#{da_match}#{remainder[/^[^\n]*/]}"
        unless contexts.empty? then
          if show_context then
            puts "  {#{contexts.join("; ")}}" 
          elsif show_link then
            lmi = contexts.rindex {|c| c[-1] == "*" }
            puts "  http://#{hn}/#{path_to_output}/#{contexts[lmi][0..-2] || "???"}.html" 
          end
        end
        if error_file then
          error_out = File.open(error_file, "w") unless error_out
          error_out.puts "#{fn}:#{line_number}:#{pos_in_line}:#{da_match.gsub(/\s+/, " ")}"
        end

        prev_match_length = da_match.length
        buffer = remainder
        line_number += da_match.count("\n")
      end 
    end

    end  # re_list.each_index
      
  end
  
  puts "...search completed. #{count} found in all files."
  re_list_status.each_index do |i|
    puts "...#{re_list[i]} not found in any file" unless re_list_status[i]
  end
  error_out.close if error_out
  if edit_files && count > 0 then
    if eask then
      $stdout.print "edit (y|n)? "
      exec "vim -q #{error_file}" if ($stdin.gets.start_with?(/Y|y/))
    else
      exec "vim -q #{error_file}" 
    end
  elsif nedit_files && ncount > 0 then
    exec "vim -q #{nerror_file}" 
  end

end

