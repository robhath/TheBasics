#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'json'
require 'yamlx.rb'
require 'diff_base.rb'
  
  
if __FILE__ == $0 then
  
  flavor = ""
  
  file1 = nil
  file2 = nil
  ARGV.each do |arg|
    if arg[0,1] == "-" then
      flavor = case arg.downcase
        when "-json" then "JSON"
        when "-yaml" then "YAML"
        else
          flavor
        end
    else
      if file1 then
        file2 = arg unless file2
      else
        file1 = arg
      end
    end
  end
  
  if !file1 || !file2 then
    $stderr.puts "ydiff.rb <file1> <file2> [-json|-yaml]"
    exit
  else
    line1 = "YDIFF  #{file1} vs. #{file2}  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    $stderr.puts line1
    $stderr.puts "=" * line1.length
    $stderr.puts
  end
  
  
  x = YAML.load_file(file1)
  if x.nil? || !x || x.empty? then
    $stderr.puts "    something's wrong... can't parse file: #{file1}!"
    exit
  end
      
  y = YAML.load_file(file2)
  if y.nil? || !y || y.empty? then
    $stderr.puts "    something's wrong... can't parse file: #{file2}!"
    exit
  end
      
  x2 = x.canonical_copy
  y2 = y.canonical_copy
  
  if flavor == "YAML" then
    xlines = YAML.dump(x2).split("\n")
    ylines = YAML.dump(y2).split("\n")    
  elsif flavor == "JSON" then
    xlines = JSON.pretty_generate(x2).split("\n")
    ylines = JSON.pretty_generate(y2).split("\n")
  else
    xlines = []
    context = []
    x2.cwalk(context) do |key, value, context|
      xlines << "#{context.join(":")}:#{key.nil? ? "[]" : key.to_s}:#{value.to_s}" unless value.respond_to?(:each)
    end
    ylines = []
    context = []
    y2.cwalk(context) do |key, value, context|
      ylines << "#{context.join(":")}:#{key.nil? ? "[]" : key.to_s}:#{value.to_s}" unless value.respond_to?(:each)
    end
  end
  
  puts diffnl(xlines, ylines)
  
end    
