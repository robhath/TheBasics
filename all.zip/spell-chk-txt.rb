#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'binary_search.rb'

  $words = [] if $words.nil?

  $learned = []
  $learning = {}
  
  if $words.empty? then
    # assume word list all downcase and already sorted...
    File.open("#{File.dirname(File.expand_path(__FILE__))}/lib/words.txt", "r:ISO-8859-1:UTF-8") do |input| 
      while line = input.gets do
        if line =~ /^\s*#/ then
          # comment
        else
          $words << line.chomp
        end
      end
    end
  end


if __FILE__ == $0 then
  
  $error_file = nil
  $error_out = nil
  $fn = nil
  $found = false
  files = []

  if ARGV.length < 1 then
    files << "."
  elsif i = ARGV.index("-help") || i = ARGV.index("--help") then
    $stderr.puts "spell-chk-txt.rb <file or directory> ... [--edit] [--learn]"
    exit
  end
  
  puts "============================================="
  puts "Text File Spell Checker  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "============================================="
  
  if i = ARGV.index("--edit") then
    $error_file = "#{ENV["HOME"]}/.spell_checker.err.txt"
  end
  if i = ARGV.index("--learn") then
    $do_learn = true
  end
  
  ARGV.each do |arg|
    next if arg[0,1] == "-"
    files << arg
  end

  count = 0
  x = nil
  files.each do |arg|
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{md,txt}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $found = false
      $fn = fn
      line = 1
      File.open(fn, "r") do |input| 
          prev_word = ""  # check for duplicated words

          while str = input.gets do
            offset = 1
            while pos = (str =~ /(?<=\b)(([A-Za-z][a-z]+)(-([A-Za-z][a-z]+))?)('d|'s|'ll|'t|'ve|'re)*(?=\b)/) do
              pre = $`
              w = $&
              str = $'
              count += 1
              if pre[-1,1] == "&" && str =~ /^\S*;/ then
                next  # skip entity
              end
              if $do_learn && $learned.include?(w) || 
                $words.binary_search(w.downcase) ||
                ($4 && !$4.empty? && $words.binary_search($2.downcase) && $words.binary_search($4.downcase)) then
                if w == prev_word then
                  puts "\n>>>File: #{$fn}" unless $found
                  puts "repeated '#{w}' loc=#{line},#{(pos + offset)}"
                  if $error_file then
                    $error_out = File.open($error_file, "w") unless $error_out
                    $error_out.puts "#{$fn}:#{line}:#{(pos + offset)}:repeated '#{w}'"
                  end
                  $found = true
                else
                  #~ $stderr.puts "#{w} okay"
                end
              else
                puts "\n>>>File: #{$fn}" unless $found
                puts "#{w} loc=#{line},#{(pos + offset)}"
                if $do_learn then
                  if $learning.has_key?(w) then
                    if $learning[w] = 2 then
                      $learned << w
                      $stderr.puts "!!! #{w} suppressed"
                    end
                    $learning[w] += 1
                  else
                    $learning[w] = 0
                  end
                end
                if $error_file then
                  $error_out = File.open($error_file, "w") unless $error_out
                  $error_out.puts "#{$fn}:#{line}:#{(pos + offset)}:#{w}"
                end
                $found = true
              end
              offset += pre.length + w.length
              prev_word = String.new(w)
            end
            line += 1
          end

      end
    end
  end
 
  puts "\nWord count = #{count}"
 
  if $error_out then
    $error_out.close
    exec "vim -q #{$error_file}" 
  end
  
end
