#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'


  def word_count(line, start_column, context, buffer)
    result = 0
    #~ $stderr.puts "word_count() line=#{line} start_column=#{start_column} context[#{context.join(",")}] buffer[#{buffer}]"
    return result if buffer[0] == "<" || context.include?("head") || context.include?("script") || context.include?("code") ||
        context.include?("pre") || context.include?("programlisting") # || context.include?("ulink")
    
    lines = buffer.split("\n")
    line -= buffer.count("\n")
    lines.each do |str|
      line_len = str.length
      offset = (start_column > 0 ? start_column : 1)
      #~ $stderr.puts "   line=#{line} start_column=#{start_column} str[#{str}]"
      # while pos = (str =~ /(?<=\b)(([A-Za-z][a-z]+)(-([A-Za-z][a-z]+))?)('d|'s|'ll|'t|'ve|'re)*(?=\b)/) do
      while pos = (str =~ /(?<=\b)(([A-Za-z][a-z]+))('d|'s|'ll|'t|'ve|'re)*(?=\b)/) do
        pre = $`
        w = $&
        str = $'
        result += 1
        # $stderr.print w + ", "
        if pre[-1,1] == "&" && str =~ /^\S*;/ then
          next  # skip entity
        end

        offset += pre.length + w.length
      end
      line += 1
      start_column = 0
    end
    return result
  end  # word_count


if __FILE__ == $0 then
  
  files = []

  if ARGV.length < 1 then
    files << "."
  elsif i = ARGV.index("-help") || i = ARGV.index("--help") then
    $stderr.puts "word-count.rb <file or directory> ... "
    exit
  end
  
  puts "=========================================="
  puts "HTML/XML Word Count  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "=========================================="
  
  ARGV.each do |arg|
    next if arg[0,1] == "-"
    files << arg
  end
  total_word_count = 0

  x = nil
  files.each do |arg|
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{html,xml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      file_word_count = 0
      puts "\n>>>File: #{fn}"
      File.open(fn, "r") do |input|  
        x = XML.parse_p(input, (fn =~ /\.html?$/)) {|line, start_column, context, buffer| 
                file_word_count += word_count(line, start_column, context, buffer) }
      end
      puts "  word count: #{file_word_count}" 
      total_word_count += file_word_count
      
    end
  end
  puts "\nTotal word count: #{total_word_count}" 
  
end
