#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'
require 'XML.rb'

if __FILE__ == $0 then
  
  get_args
  files = []

  if $nargs.empty? then
    files += Dir.glob("./**/*.{html}")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./**/*.{html}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{html}")
       else
         files << narg
       end
     end  # $nargs.each
  end
  # $stderr.puts files.join(", ")
  #
  location = $args["-loc"] || "https://docs.aws.amazon.com/freertos/latest/"

header = <<EOS 
<?xml version="1.0" encoding="UTF-8"?>
EOS

  x = XML.new("urlset", { 
      "xmlns" => "http://www.sitemaps.org/schemas/sitemap/0.9",
      "xmlns:xsi" => "http://www.w3.org/2001/XMLSchema-instance",
      "xsi:schemaLocation" => "http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" })

  $stderr.puts "files counted = #{files.length}"    
  know_where = false 
  files.each do |f|
    ##next if $args["-ex"] && f =~ Regexp.new($args["-ex"])
    ##$stderr.puts "  " + f

    url = XML.new("url")
    loc = XML.new("loc", {}, "", [XML.new("", {}, location + f.sub(/^[^\/]+\//, ""))])
    $stderr.puts "WARNING: directory used is e.g. " + location + f.sub(/^[^\/]+\//, "") unless know_where
    know_where = true
    url.child << loc
    x.child << url

    #<lastmod>2019-06-25T06:55:13+00:00</lastmod>
    lastmod = XML.new("lastmod", {}, "", [XML.new("", {}, File.new(f).mtime.strftime("%FT%T%:z"))])
    url.child << lastmod
  end

  puts header
  puts x.to_s(0, true)
 
end

