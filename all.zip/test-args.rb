#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'


if __FILE__ == $0 then
 
  get_args(syntax: "test.rb ... ")
  $stderr.puts $args
  $stderr.puts $nargs

end
