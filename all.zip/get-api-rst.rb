#!ruby

$LOAD_PATH << File.dirname($0)
$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'json'
require 'stringio'
require 'XML.rb'
require 'binary_search.rb'
require 'args.rb'
require 'y2z.rb'

da_template = DATA.read

  
if __FILE__ == $0 then
  
  x = nil
  the_all = XML.new
  
  get_args
  files = []

  if $nargs.empty? then
    files += Dir.glob("./*/model/*.{xml}")
    files += Dir.glob("./*/model-src/*.{xml}")
    #$stderr.puts files.join(", ")
  else  
    $nargs.each do |narg|
       if narg == "." then
         #files += Dir.glob("./*/model/*.{xml}")
         files += Dir.glob("./*/model/**/*.{xml}")
         files += Dir.glob("./*/model-src/**/*.{xml}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/**/*.{xml}")
       else
         files << narg
       end
     end  # $nargs.each
  end

  $stderr.puts ">>> reading files..."    
  files.each do |f|
    next if $args["-ex"] && f =~ Regexp.new($args["-ex"])
    $stderr.puts "  " + f
    File.open(f, "r") {|input| x = XML.parse(input) }
    the_all.child += x.child
  end
 
  $stderr.puts "\n>>> parsing definitions..." 
  stuff = the_all.parse_definitions


  if $args["-svc"] then
    service_name = $args["-svc"]
  elsif stuff.has_key?("operation") then
    if stuff["operation"].keys[0] =~ /^\s*com\.amazonaws\.([^.]+)/ then
      service_name = $1 
    else
      service_name = "xxx" 
    end
  end
  $stderr.puts "  service name is #{service_name}"

  if $args["-chk-svc"] then
    $stderr.puts ">>> checking services..."
    if stuff.has_key?("service") then
      stuff["service"].each_pair do |key, value|
        if value.respond_to?(:each_pair) && value.has_key?("operation") then
          my_assembly = value["assembly"] || ""
          value["operation"].each do |op|
            if op.has_key?("target") then
              target = op["target"]
              if target then
                tt = String.new(target)
                assembly = tt.slice!(/^[^#]*#/)
                target_names = tt.split("$")
                #$stderr.puts "    [#{target_names.join(", ")}]"
                what = stuff
                target_names.each do |n|
                  if what.respond_to?(:each_pair) then
                    f = nil
                    what.each_pair do |key, value|
                      if value.respond_to?(:each_pair) then
                        nn = "#{(assembly && !assembly.empty?) ? (assembly + n) : (my_assembly + "#" + n)}"
                        if value.has_key?(nn) then
                          f = value[nn]  
                          break
                        elsif value.has_key?(n) then
                          f = value[n]  
                          break
                        end
                      elsif value.respond_to?(:each) then
                        value.each do |a|
                          if a.respond_to?(:each_pair) then
                            a.each_pair do |k, v|
                              if v == n then
                                f = a 
                                break
                              end
                            end
                          end
                        end
                      end
                    end
                    what = f
                  else
                    what = nil
                    break
                  end
                end
                
                unless what then
                  $stderr.puts " \"#{target}\" not found (operation target)"
                end
              end
              
            end
          end
        end
      end
    end
  end


  $stderr.puts "\n>>> writing yaml file..." 
  yamlfn = "api.#{Time.now.strftime("%Y%m%d")}.yaml"
  File.open(yamlfn, "w") {|output| output.puts YAML.dump(stuff) }
 
  $stderr.puts "\n>>> creating html..."
  zargs = [yamlfn, "-zi", da_template, "-output", "api.#{Time.now.strftime("%Y%m%d")}.html", "-hf", "-html", "-svc", service_name]
  y2z(zargs) 

end

__END__
-subtemplate(key="header") -nochange <?xml version="1.0" encoding="UTF-8"?>
  <html>
    <head>
      <link rel="stylesheet" type="text/css" href="standard.css"/>
    </head>
    <body>


-dothis `
      def populate_structure(input_target, y, do_http = false)
        json = {}
        my_assembly = input_target['assembly'] || ""
        input_target['member'].each do |m|
          next if (m.has_key?('deprecated') && m['deprecated'])
          next if !do_http && (m.has_key?('httplabel')  || m.has_key?('httpheader'))

          if !m['target'].include?('#') then
            t = my_assembly + "#" + m['target']
          else
            t = m['target']
          end

          huh = (m['name'] || m['target']).sub(/^[^#]*#/, '')
          if (y.has_key?('string') && y['string'].has_key?(t)) || 
                (y.has_key?('String') && y['String'].has_key?(t)) then
            json[huh] = "string"
          elsif (y.has_key?('integer') && y['integer'].has_key?(t)) || 
                (y.has_key?('Integer') && y['Integer'].has_key?(t)) then
            json[huh] = "integer"
          elsif (y.has_key?('float') && y['float'].has_key?(t)) ||
                (y.has_key?('Float') && y['Float'].has_key?(t)) then
            json[huh] = "float"
          elsif (y.has_key?('long') && y['long'].has_key?(t)) ||
                (y.has_key?('Long') && y['Long'].has_key?(t)) then
            json[huh] = "long"
          elsif (y.has_key?('double') && y['double'].has_key?(t)) ||
                (y.has_key?('Double') && y['Double'].has_key?(t)) then
            json[huh] = "double"
          elsif (y.has_key?('boolean') && y['boolean'].has_key?(t)) ||
                (y.has_key?('Boolean') && y['Boolean'].has_key?(t)) then
            json[huh] = "boolean"
          elsif (y.has_key?('timestamp') && y['timestamp'].has_key?(t)) ||
                (y.has_key?('Timestamp') && y['Timestamp'].has_key?(t)) then
              json[huh] = "timestamp"
          elsif (y.has_key?('blob') && y['blob'].has_key?(t)) ||
                (y.has_key?('Blob') && y['Blob'].has_key?(t)) then
              json[huh] = "blob"
          elsif (y.has_key?('map') && y['map'].has_key?(t)) then
            json[huh] = {}
            dat = y['map'][t]
            dat_assembly = (dat.has_key?('assembly') ? dat['assembly'] : '')
            len = dat['key'].length
            len.times do |i|
                khash = { "member" => [dat['key'][i]], "assembly" => dat_assembly }
                kjson = populate_structure(khash, y, do_http)
                vhash = { "member" => [dat['value'][i]], "assembly" => dat_assembly }
                vjson = populate_structure(vhash, y, do_http)
                json[huh][kjson[dat['key'][i]['target']]] = vjson[dat['value'][i]['target']]
            end
          elsif (y.has_key?('list') && y['list'].has_key?(t)) then
            json[huh] = []
            temp_json = populate_structure(y['list'][t], y, do_http)
            temp_json.each_pair do |k, v|
                json[huh] << v
            end
          elsif (y['structure'].has_key?(t)) then
            json[huh] = populate_structure(y['structure'][t], y, do_http)
          end
        end if input_target.has_key?('member')
        return json
      end  #populate_structure


      def coral_get_params(target, y, do_http = false)
        params = []
        my_assembly = target['assembly'] || ""
        target['member'].each do |m|
          next if (m.has_key?('deprecated') && m['deprecated'])
          next if !do_http && (m.has_key?('httplabel')  || m.has_key?('httpheader'))

          if !m['target'].include?('#') then
            t = my_assembly + "#" + m['target']
          else
            t = m['target']
          end
          # t = m['target'].sub(/^[^#]*#/, '')


          huh = (m['name'] || m['target'] || "").sub(/^[^#]*#/, '')
          
          if (y.has_key?('string') && y['string'].has_key?(t))  || 
                (y.has_key?('String') && y['String'].has_key?(t)) then
            temp = "string"
            temp2 = ""
            stuff = (y['string'][t] || y['String'][t])
            if stuff.has_key?('length') then
              temp << ";  (length-"
              if stuff['length'].has_key?('max') then
                str = stuff['length']['max'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " max:" + str 
              end
              if stuff['length'].has_key?('min') then
                str = stuff['length']['min'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " min:" + str
              end
              temp << ")"
            end
            if stuff.has_key?('pattern') then
              if stuff['pattern'].has_key?('regex') then
                str = stuff['pattern']['regex'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << Regexp.escape(v['value'])
                end
                temp << ";  (pattern: " + str.gsub('_', '\_') + ")"
              end
            end
            if stuff.has_key?('enum') then
              if stuff['enum'].has_key?('enumValue') then
                str = stuff['enum']['enumValue'].inject("") do |s, v| 
                  s << " | " unless s.empty?
                  s << v['value'] 
                end
                temp2 << "\n  enum: " + str
              end
            end
            if stuff.has_key?('enumjava') then
              if stuff['enumjava'].has_key?('class') then
                str = stuff['enumjava']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                #temp << "\n  java class: " + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            if !temp2.empty? then
              doc << "\n<p>#{temp2}</p>"
            end
            params << [huh, temp, doc]
            
          elsif (y.has_key?('integer') && y['integer'].has_key?(t)) || 
                (y.has_key?('Integer') && y['Integer'].has_key?(t)) then
            temp = "integer"
            stuff = (y['integer'][t] || y['Integer'][t])
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end
            if stuff.has_key?('range') then
              temp << "\n  range-"
              if stuff['range'].has_key?('max') then
                str = stuff['range']['max'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " max:" + str
              end
              if stuff['range'].has_key?('min') then
                str = stuff['range']['min'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " min:" + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            
          elsif (y.has_key?('float') && y['float'].has_key?(t)) ||
                (y.has_key?('Float') && y['Float'].has_key?(t)) then
            temp = "float"
            stuff = (y['float'][t] || y['Float'][t])
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end
            if stuff.has_key?('range') then
              temp << "\n  range-"
              if stuff['range'].has_key?('max') then
                str = stuff['range']['max'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " max:" + str
              end
              if stuff['range'].has_key?('min') then
                str = stuff['range']['min'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " min:" + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            
          elsif (y.has_key?('long') && y['long'].has_key?(t)) ||
                (y.has_key?('Long') && y['Long'].has_key?(t)) then
            temp = "long"
            stuff = (y['long'][t] || y['Long'][t])
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end
            if stuff.has_key?('range') then
              temp << "\n  range-"
              if stuff['range'].has_key?('max') then
                str = stuff['range']['max'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " max:" + str
              end
              if stuff['range'].has_key?('min') then
                str = stuff['range']['min'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end 
                temp << " min:" + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            
          elsif (y.has_key?('boolean') && y['boolean'].has_key?(t)) ||
                (y.has_key?('Boolean') && y['Boolean'].has_key?(t)) then
            temp = "boolean"
            stuff = (y['boolean'][t] || y['Boolean'][t])
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            
          elsif (y.has_key?('timestamp') && y['timestamp'].has_key?(t)) ||
                (y.has_key?('Timestamp') && y['Timestamp'].has_key?(t)) then
            temp = "timestamp"
            stuff = (y['timestamp'][t] || y['Timestamp'][t])
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            
          elsif (y.has_key?('blob') && y['blob'].has_key?(t)) ||
                (y.has_key?('Blob') && y['Blob'].has_key?(t)) then
            temp = "blob"
            stuff = (y['blob'][t] || y['Blob'][t])
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            
          elsif (y.has_key?('map') && y['map'].has_key?(t)) || 
              (y.has_key?('Map') && y['Map'].has_key?(t)) then
            temp = "map"
            stuff = (y['map'][t] || y['Map'][t])
            if stuff.has_key?('key') then
              str = stuff['key'].inject("") do |s, v| 
                s << ", " unless s.empty?
                s << v['target'].sub(/^[^#]*#/, '') 
              end
              temp << "\n  key: " + str
            end
            if stuff.has_key?('value') then
              str = stuff['value'].inject("") do |s, v| 
                s << ", " unless s.empty?
                s << v['target'].sub(/^[^#]*#/, '') 
              end
              temp << "\n  value: " + str
            end
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end

            stuff_assembly = (stuff.has_key?('assembly') ? stuff['assembly'] : '')
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            len = stuff['key'].length
            len.times do |i|
              khash = { "member" => [stuff['key'][i]], "assembly" => stuff_assembly }
              temp = coral_get_params(khash, y, do_http)
              temp.shift unless $args["-full"]
              params += temp
              vhash = { "member" => [stuff['value'][i]], "assembly" => stuff_assembly  }
              temp = coral_get_params(vhash, y, do_http)
              temp.shift unless $args["-full"]
              params += temp
            end
            
          elsif (y.has_key?('list') && y['list'].has_key?(t)) || 
              (y.has_key?('List') && y['List'].has_key?(t)) then
            temp = "list"
            stuff = (y['list'][t] || y['List'][t])
            if stuff.has_key?('member') then
              str = stuff['member'].inject("") do |s, v| 
                s << ", " unless s.empty?
                s << v['target'].sub(/^[^#]*#/, '') 
              end
              temp << "\n  member: " + str
            end
            if stuff.has_key?('java') then
              if stuff['java'].has_key?('class') then
                str = stuff['java']['class'].inject("") do |s, v| 
                  s << ", " unless s.empty?
                  s << v['value'] 
                end
                temp << "\n  java class: " + str
              end
            end
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, temp, doc]
            temp = coral_get_params(stuff, y, do_http)
            temp.shift unless $args["-full"]
            params += temp
            
          elsif (y['structure'].has_key?(t)) then
            doc = m.has_key?('documentation') ? html_doc_cleanup(m['documentation']) : "<p/>"
            params << [huh, t.sub(/^[^#]*#/, ''), doc]
            params += coral_get_params(y['structure'][t], y, do_http)
            
          end
        end if target.has_key?('member')
        return params
      end  #coral_get_params


      def ref_type(m, assembly, y)
        result = nil

        if m['target'].include?('#') then
          t = m['target']
        else
          t = (assembly + '#' + m['target'])
        end

        if (y.has_key?('string') && y['string'].has_key?(t)) || 
              (y.has_key?('String') && y['String'].has_key?(t)) then
          result = "string"
        elsif (y.has_key?('integer') && y['integer'].has_key?(t)) || 
              (y.has_key?('Integer') && y['Integer'].has_key?(t)) then
          result = "integer"
        elsif (y.has_key?('float') && y['float'].has_key?(t)) ||
              (y.has_key?('Float') && y['Float'].has_key?(t)) then
          result = "float"
        elsif (y.has_key?('long') && y['long'].has_key?(t)) ||
              (y.has_key?('Long') && y['Long'].has_key?(t)) then
          result = "long"
        elsif (y.has_key?('boolean') && y['boolean'].has_key?(t)) ||
              (y.has_key?('Boolean') && y['Boolean'].has_key?(t)) then
          result = "boolean"
        elsif (y.has_key?('timestamp') && y['timestamp'].has_key?(t)) ||
              (y.has_key?('Timestamp') && y['Timestamp'].has_key?(t)) then
            result = "timestamp"
        elsif (y.has_key?('map') && y['map'].has_key?(t)) then
            result = ""
            m = y['map'][t]
            len = (m.has_key?('key') && m.has_key?('value') ? m['key'].length : 0)
            len.times do |i|
              result << ", " unless result.empty?
              result << "#{m['key'][i]['target']} : #{m['value'][i]['target']}"
            end
            result.prepend "map {"
            result << "}"
        elsif (y.has_key?('list') && y['list'].has_key?(t)) then
          result = ""
          y['list'][t]['member'].each do |m|
              result << ", " unless result.empty?
              result << m['target']
          end if y['list'][t].has_key?('member')
          result.prepend "list ["
          result << "]"
        elsif (y['structure'].has_key?(t)) then
          result = "structure {#{y['structure'][t]}}"
        else
          #$stderr.puts "??? t:#{t.to_s} m:#{m.to_s}"
          result = t.to_s
        end
        return result
      end  #ref_type

      $cli_commands = { 'com.amazonaws.iot.laser.thingjobmanagerservice.external#' => 'iot-jobs-data',
          'com.amazonaws.iot.moonraker#' => 'iot-data',
          'com.amazonaws.iot.krieger#' => 'iotanalytics',
          'com.amazonaws.iot.krieger.data#' => 'iotanalytics' }
`
    ###############################################################
 
    
    -dothis `
        operations = y['operation'].sort {|a, b| a[0].sub(/^[^#]*#/, '') <=> b[0].sub(/^[^#]*#/, '') } 
`  

    -each iterator="operations"  varlist="key, value"
        
        -if  test="value.has_key?('http') && !value.has_key?('internalonly')"
            
            -dothis `
                    http = value['http']
                    if $cli_commands.has_key?(key[/^[^#]+#/]) then
                      cli = "aws #{$cli_commands[key[/^[^#]+#/]].downcase}  #{key.sub(/^[^#]*#/, '').burst.downcase}"
                      link_target = "_cli-#{($cli_commands[key[/^[^#]+#/]])}.#{key.sub(/^[^#]*#/, '')}"
                    else
                      cli = "aws #{$service_name.downcase}  #{key.sub(/^[^#]*#/, '').burst.downcase}"
                    end
                    cli_input_json = {}
                    cli_output_json = {}
                    input_params = []
                    output_params = []
                    `
                  
            -if  test="http.has_key?('verb') && http.has_key?('uri')"
                    -dothis
                        verb = http['verb'].inject("") do |str, v|
                            str << ' ' unless str.empty?
                            str << v['value']
                        end
                        uri = http['uri'].inject("") do |str, v|
                            str << ' ' unless str.empty?
                            str << v['value']
                        end
                        da_example = ""
                        da_header = ""
                                    
                    -dothis `
                        value['input'].each  do |input|
                            if input['target'].include?('#') then
                              tt = input['target']
                            else
                              tt = (value.has_key?('assembly') ? value['assembly'] + '#' : '') + input['target']
                            end
                            input_target = y['structure'][tt]
                            input_target['member'].each do |m|
                              if m.has_key?('httpheader') then
                                  nm = m['name']
                                  m['httpheader']['header'].each do |v|
                                      da_header << "\n#{v['value']}: {#{nm}}"
                                  end if m['httpheader'].has_key?('header')
                              end
                            end if input_target.has_key?('member')
                            input_params += coral_get_params(input_target, y, true)
                            da_json = populate_structure(input_target, y, false)
                            $stderr.puts "ERROR: #{input['target']} structure not found!" if input_target.nil?
                            #$stderr.puts da_json.to_s
                            if !da_json.empty? then
                                da_example << "\nContent-type: application/json\n\n" + JSON.pretty_generate(da_json)
                            end
                        end
                        `
                                  
                          
            -if  test="value.has_key?('input')"
                    -each  iterator="value['input']"  varlist="input"
                        -dothis `
                            if input['target'].include?('#') then
                              tt = input['target']
                            else
                              tt = (value.has_key?('assembly') ? value['assembly'] + '#' : '') + input['target']
                            end
                            input_target = y['structure'][tt]
                            #input_target = y['structure'][input['target'].sub(/^[^#]*#/, '')]
                            input_target['member'].each do |m|
                                req = (m.has_key?('required') && m['required']) ? true : false
                                rt = ref_type(m, (input_target['assembly'] || ""), y)
                                #$stderr.puts "rt=#{rt} m=#{m}"
                                if rt.downcase == "boolean" then
                                    cli << " \\\n    #{req ? '' : '['}--#{m['name'].burst.downcase} | --no-#{m['name'].burst.downcase}#{req ? '' : ']'}"
                                else
                                    cli << " \\\n    #{req ? '' : '['}--#{m['name'].burst.downcase} <value>#{req ? '' : ']'}"
                                end
                                cli_input_json.merge!(populate_structure(input_target, y, true))
                            end if input_target.has_key?('member')
                            `
                            
            -if  test="value.has_key?('output')"
                                  
                    -dothis `
                        da_example = ""
                        value['output'].each  do |output|
                            if output['target'].include?('#') then
                              tt = output['target']
                            else
                              tt = (value.has_key?('assembly') ? value['assembly'] + '#' : '') + output['target']
                            end
                            output_target = y['structure'][tt]
                            #output_target = y['structure'][output['target'].sub(/^[^#]*#/, '')]
                            output_params += coral_get_params(output_target, y, true)
                            da_json = populate_structure(output_target, y)
                            $stderr.puts "ERROR: #{output['target']} structure not found!" if output_target.nil?
                            #$stderr.puts da_json.to_s
                            if !da_json.empty? then
                                da_example << "\nContent-type: application/json\n\n" + JSON.pretty_generate(da_json)
                            end
                            cli_output_json.merge!(populate_structure(output_target, y, true))
                        end
                        `
                                  
                    -each  iterator="value['output']"  varlist="output"
                        -dothis `
                            if output['target'].include?('#') then
                              tt = output['target']
                            else
                              tt = (value.has_key?('assembly') ? value['assembly'] + '#' : '') + output['target']
                            end
                            output_target = y['structure'][tt]
                            #output_target = y['structure'][output['target'].sub(/^[^#]*#/, '')]
                            `
                                  
                          

            -pre `


.. #{link_target}:

#{key.sub(/^[^#]*#/, '')}
#{("-" * key.sub(/^[^#]*#/, '').length)}

#{value.has_key?('documentation') ? value['documentation'].gsub(/<[^>]+>/, ' ').gsub("\n", " ") : '???'}
                 
*CLI Synopsis*:

.. code-block:: sh

`
            -nochange `
   #{cli.gsub("\\", "")} 
   [--cli-#{"input"}-json <value>] 
   [--generate-cli-skeleton]
`
            -pre `

*cli-input-json* format:

.. code-block:: json

#{JSON.pretty_generate(cli_input_json).indent("   ")}

*fields*:

`

            -if test="!input_params.empty?" 

                -each  iterator="input_params"  varlist="ips"
                    -pre `
   * #{ips[0]}

     *type*: #{ips[1].gsub("\n", "  ")}
     
     #{ips[2].gsub(/<[^>]+>/, ' ').gsub("\n", " ")}
     
     
`
                        

            -if test="!output_params.empty?" 
                -pre `
Output:

.. code-block:: json

#{JSON.pretty_generate(cli_output_json).indent("   ")}

*fields*:

`

                -each  iterator="output_params"  varlist="ops"
                    -pre `
   * #{ops[0]}

     *type*: #{ops[1].gsub("\n", "  ")} 
     
     #{ops[2].gsub(/<[^>]+>/, "").gsub("\n", " ")}
     
     

`
            -else
                -pre `

Output:

None

`
 
            -if  test="value.has_key?('error')"
                -pre   `

Errors:
`
                              
                -each  iterator="value['error']"  varlist="error"
                              
                            -dothis `
                                if error['target'].include?('#') then
                                  tt = error['target']
                                else
                                  tt = (value.has_key?('assembly') ? value['assembly'] + '#' : '') + error['target']
                                end
                                error_target = y['structure'][tt]
                                if error_target.nil? then
                                  tt = (value.has_key?('assembly') ? value['assembly'] : '') + error['target'][/#.+/]
                                  #~ $stderr.puts tt
                                  error_target = y['structure'][tt]
                                end
                                #~ $stderr.puts error_target
                                #error_target = y['structure'][error['target'].sub(/^[^#]*#/, '')]
                                `
                                      
                            -pre `
  * #{error['target'].sub(/^[^#]*#/, '')}

`                                          
                                      
                            -if test="!error_target.nil? && error_target.has_key?('documentation')"
                                    -pre ` 

    #{error_target['documentation'].gsub(/<[^>]+>/, ' ').gsub("\n", " ")}
`
                                      
                            -if test="!error_target.nil? && error_target.has_key?('httperror') && error_target['httperror'].has_key?('httpresponsecode')"
                                    -dothis `
                                        resp_code = ""
                                        error_target['httperror']['httpresponsecode'].each do |v|
                                            resp_code << ", " unless resp_code.empty?
                                            resp_code << v['value']
                                        end
                                        `
                                    -pre ` 

    HTTP response code: #{resp_code}
`
                          
