#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'args.rb'


if __FILE__ == $0 then
  
  get_args(nmin: 1, nsyntax: "xml2text-c.rb <file>")

  puts "==================================================="
  puts "XML/HTML to text (canonical)  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "==================================================="
 
  x = nil

  $stderr.puts $nargs.join(", ")
  File.open($nargs[0], "r") do |input|
    x = XML.parse_p(input, ($nargs[0] =~ /\.html?$/))
  end
  File.open($nargs[0].sub(/\.[^.]+$/, ".txt"), "w") do |output|
    if $nargs[0] =~ /\.html?$/i then 
      output.print x.to_txt_canonical(block_tags: XML::HTML_BLOCK_TAGS, pre_tags: XML::HTML_PRE_TAGS, skip_tags: XML::HTML_SKIP_TAGS)
    else
      output.print x.to_txt_canonical
    end
  end

end
