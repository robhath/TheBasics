#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'XML.rb'
require 'args.rb'


class XML
 
  def build_index(index = {}, revision = {})
    latest_context = ""
    self.each do |y|
      if y.tag == "indexterm" then
        if y.attributes.has_key?("revision") then
          date = y.attributes["revision"] 
          if (Time.now - Time.new(date[0..3].to_i, date[4..5].to_i, date[6..7].to_i)) > (($args["-days"] || 90) * 86400) then
            next  # skip it if revision date > 90? days
          else
            $stderr.puts "  > including revision of #{date}" if $args["--verbose"]
          end
          index_terms = revision
        else
          index_terms = index
        end
        term0 = nil; term1 = nil; term2 = nil
        see = nil; seealso = nil
        context = latest_context

        y.each do |z|
          case z.tag
            when "primary" then
              temp = z.get_pcdata.strip
              term0 = temp unless temp.empty? 

            when "secondary" then
              temp = z.get_pcdata.strip
              term1 = temp unless temp.empty? 

            when "tertiary" then
              temp = z.get_pcdata.strip
              term2 = temp unless temp.empty? 

            when "see" then
              temp = z.get_pcdata.strip
              context = "see:#{temp}" unless temp.empty? 

            when "seealso" then
              temp = z.get_pcdata.strip
              seealso = temp unless temp.empty? 
              context = "seealso:#{temp}:#{latest_context}" unless temp.empty? 
          end
        end

        # put it together...
        if term2 then
          if term1 then
            if term0 then
              if index_terms.has_key?(term0) then
                if index_terms[term0].has_key?(1) then
                  if index_terms[term0][1].has_key?(term1) then
                    if index_terms[term0][1][term1].has_key?(1) then
                      if index_terms[term0][1][term1][1].has_key?(term2) then
                        index_terms[term0][1][term1][1][term2][0] << context
                      else
                        index_terms[term0][1][term1][1][term2] = {0 => [context]}
                      end
                    else
                      index_terms[term0][1][term1][1] = {term2 => {0 => [context]}}
                    end
                  else
                    index_terms[term0][1][term1] = {0 => [], 1 => {term2 => {0 => [context]}}}
                  end
                else
                  index_terms[term0][1] = {term1 => {0 => [], 1 => {term2 => {0 => [context]}}}}
                end
              else
                index_terms[term0] = {0 => [], 1 => {term1 => {0 => [], 1 => {term2 => {0 => [context]}}}}}
              end
            else
              $stderr.puts "ERROR: tertiary index without primary"
            end
          else
            $stderr.puts "ERROR: tertiary index without secondary"
          end
        elsif term1 then
          if term0 then
            if index_terms.has_key?(term0) then
              if index_terms[term0].has_key?(1) then
                if index_terms[term0][1].has_key?(term1) then
                  index_terms[term0][1][term1][0] << context
                else
                  index_terms[term0][1][term1] = {0 => [context]}
                end
              else
                index_terms[term0][1] = {term1 => {0 => [context]}}
              end
            else
              index_terms[term0] = {0 => [], 1 => {term1 => {0 => [context]}}}
            end
          else
            $stderr.puts "ERROR: secondary index without primary"
          end
        elsif term0 then
          if index_terms.has_key?(term0) then
            index_terms[term0][0] << context
          else
            index_terms[term0] = {0 => [context]}
          end
        else
          $stderr.puts "ERROR: indexterm without primary"
        end

      elsif (y.tag == "chapter" || y.tag == "section") && y.attributes.has_key?("id") then
        latest_context = y.attributes["id"] + "::" + y.attributes["id"] + ".title"

      elsif (y.tag == "anchor") && y.attributes.has_key?("id") && latest_context =~ /::.+/ then
        latest_context = y.attributes["id"] + "::" + $&[2..-1]
      end
    end
  end  # build_index 
  
end  # XML


class Hash

  def index_terms2xml()
    return "<para>Nothing here at the moment. Check this space later for updates.</para>" if self.empty?
    buffer = ""

    anchor_targets = {}
    at_id = 0
    self.each do |term, value|
      at_id += 1
      anchor_targets[term] = at_id.to_s
      if seconds = value[1] then
        seconds.each do |term2, value2|
          at_id += 1
          anchor_targets[(term + "-" + term2)] = at_id.to_s
        end
        if thirds = seconds[1] then
          thirds.each do |term3, value3|
            at_id += 1
            anchor_targets[(term + "-" + term2 + "-" + term3)] = at_id.to_s
          end
        end
      end
    end

    it = self.sort {|a,b| a[0].upcase <=> b[0].upcase }
    first_letter = ""
    unless $args["--letters"] then
      buffer << "<variablelist>\n"
    end

    it.each do |term, value|
      $stderr.puts "  " + term if $args["--verbose"]

      if $args["--letters"] then
        if term[0].upcase != first_letter then
          unless first_letter.empty? then
            buffer << "</variablelist></section>\n"
          end
          first_letter = term[0].upcase
          buffer << "<section id=\"#{first_letter}-idx\"><info><title id=\"#{first_letter}-idx.title\">-#{first_letter}-</title></info>\n"
          buffer << "<variablelist>\n"
        end
      end

      buffer << "  <varlistentry><term><anchor id=\"at#{anchor_targets[term]}-idx\"/>#{term}</term><listitem><para>\n"
      #~buffer << "  <varlistentry><term><anchor id=\"#{term.gsub(/\W+/, "")}-idx\"/>#{term}</term><listitem><para>\n"

      if links = value[0] then
        sees1 = ""
        links.each do |link|
          if link =~ /^seealso:([^:]+):(.+)/ then
            buffer << "    &nbsp;[<xref linkend=\"#{$2}\" endterm=\"#{$2}.title\"/>]\n"
            sees1 << "    <para>See also #{$1}</para>\n"
          elsif link =~ /^see:([^:]+)/ then
            see_term = $1
            see_elements = see_term.split(/\s*\|\s*/)
            $stderr.puts "ERROR: can't find 'see' target: #{see_elements.join("-")}" unless anchor_targets[see_elements.join("-")]
            sees1 << "    <para>See <link linkend=\"at#{anchor_targets[see_elements.join('-')]}-idx\">#{see_term}</link></para>\n"
          elsif link =~ /^([^:]+)::(.+)/ then
            buffer << "    &nbsp;[<xref linkend=\"#{$1}\" endterm=\"#{$2}\"/>]\n"
          end
        end
        buffer << "    </para>\n"
        buffer << sees1
  
        if seconds = value[1] then
          buffer << "    <variablelist>"
          it2 = seconds.sort {|a,b| a[0].upcase <=> b[0].upcase }
          it2.each do |term2, value2|
            $stderr.puts "    " + term2 if $args["--verbose"]
            buffer << "      <varlistentry><term><anchor id=\"at#{anchor_targets[term + "-" + term2]}-idx\"/>#{term2}</term><listitem><para>\n"
            #~buffer << "      <varlistentry><term><anchor id=\"#{term.gsub(/\W+/, "")}-#{term2.gsub(/\W+/, "")}-idx\"/>#{term2}</term><listitem><para>\n"
            if links2 = value2[0] then
              sees2 = ""
              links2.each do |link2|
                if link2 =~ /^seealso:([^:]+):(.+)/ then
                  buffer << "      &nbsp;[<xref linkend=\"#{$2}\" endterm=\"#{$2}.title\"/>]\n"
                  sees2 << "      <para>See also #{$1}</para>\n"
                elsif link2 =~ /^see:([^:]+)/ then
                  see_term = $1
                  see_elements = see_term.split(/\s*\|\s*/)
                  $stderr.puts "ERROR: can't find 'see' target: #{see_elements.join("-")}" unless anchor_targets[see_elements.join("-")]
                  sees2 << "      <para>See <link linkend=\"at#{anchor_targets[see_elements.join('-')]}-idx\">#{see_term}</link></para>\n"
                elsif link2 =~ /^([^:]+)::(.+)/ then
                  buffer << "      &nbsp;[<xref linkend=\"#{$1}\" endterm=\"#{$2}\"/>]\n"
                end
              end
              buffer << "     </para>\n" 
              buffer << sees2
    
              if thirds = value2[1] then
                buffer << "      <variablelist>"
                it3 = thirds.sort {|a,b| a[0].upcase <=> b[0].upcase }
                it3.each do |term3, value3|
                  $stderr.puts "      " + term3 if $args["--verbose"]
                  buffer << "        <varlistentry><term><anchor id=\"at#{anchor_targets[term + "-" + term2 + "-" + term3]}-idx\"/>#{term3}</term><listitem><para>\n"
                  #~buffer << "        <varlistentry><term><anchor id=\"#{term.gsub(/\W+/, "")}-#{term2.gsub(/\W+/, "")}-#{term3.gsub(/\W+/, "")}-idx\"/>#{term3}</term><listitem><para>\n"
                  if links3 = value3[0] then
                    sees3 = ""
                    links3.each do |link3|
                      if link3 =~ /^seealso:([^:]+):(.+)/ then
                        buffer << "          &nbsp;[<xref linkend=\"#{$2}\" endterm=\"#{$2}.title\"/>]\n"
                        sees3 << "          <para>See also #{$1}</para>\n"
                      elsif link3 =~ /^see:([^:]+)/ then
                        see_term = $1
                        see_elements = see_term.split(/\s*\|\s*/)
                        $stderr.puts "ERROR: can't find 'see' target: #{see_elements.join("-")}" unless anchor_targets[see_elements.join("-")]
                        sees3 << "          <para>See <link linkend=\"at#{anchor_targets[see_elements.join('-')]}-idx\">#{see_term}</link></para>\n"
                      elsif link3 =~ /^([^:]+)::(.+)/ then
                        buffer << "          &nbsp;[<xref linkend=\"#{$1}\" endterm=\"#{$2}\"/>]\n"
                      end
                    end
                    buffer << "          </para>\n"
                    buffer << sees3
                  end  # if links3
                  buffer << "        </listitem></varlistentry>\n"
                end  # it3.each
                buffer << "      </variablelist>"
              end  # if thirds

            end  # if links2
            buffer << "    </listitem></varlistentry>\n"
          end  # it2.each
          buffer << "  </variablelist>"
        end  # if seconds

      end  # if links
      buffer << " </listitem></varlistentry>\n"
    end  # it.each
    buffer << "</variablelist>\n"
    buffer << "</section>\n" unless first_letter.empty? 
    return buffer 
  end  # index2xml

end  # Hash


if __FILE__ == $0 then

  get_args(syntax: "build-index.rb  
  optional parameters:      default:
    <file|directory>...     .
    --verbose 
    --letters     
    -title <string>         How Do I ...?
    -output <file>          index.xml 
    -rtitle <string>        What's Changed?
    -routput <file>         revisions.xml
    -days <number>          90
    -ex <file_re>             ")
  
  files = []
  index_terms = {}
  revision_terms = {}

  $stderr.puts "================================="
  $stderr.puts "Build Index #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  $stderr.puts "================================="
  

  index_output_file = ($args["-output"] || "index.xml")
  revision_output_file = ($args["-routput"] || "revisions.xml")

  if $nargs.empty? then
    files += Dir.glob("./*.{xml}")
  else  
    $nargs.each do |narg|
       if narg == "." then
         files += Dir.glob("./*.{xml}")
       elsif File.directory?(narg) then
         files += Dir.glob("#{narg.gsub("\\", "/")}/*.{xml}")
       else
         files << narg
       end
     end  # $nargs.each
  end
    
  $stderr.puts ">>> reading files..."    
  files.each do |f|
    next if $args["-ex"] && f =~ Regexp.new($args["-ex"])
    next if f == index_output_file
    $stderr.puts "  " + f
    x = nil
    File.open(f, "r") {|input| x = XML.parse(input) }
    x.build_index(index_terms, revision_terms)
  end
  
  #~$stderr.puts index_terms  # debug
  #~$stderr.puts revision_terms  # debug
  
  $stderr.puts ">>> creating index entries (file: #{index_output_file})..."    
  File.open(index_output_file, "w") do |output|
    output.puts "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
    output.puts "<!DOCTYPE chapter PUBLIC \"-//OASIS//DTD DocBook XML V4.5//EN\" \"file://zonbook/docbookx.dtd\""
    output.puts "["
        output.puts "<!ENTITY % xinclude SYSTEM \"file://AWSShared/common/xinclude.mod\">"
        output.puts "%xinclude;"
        output.puts "<!ENTITY % phrases-shared SYSTEM \"file://AWSShared/common/phrases-shared.ent\"> "
        output.puts "%phrases-shared;           "
    output.puts "]>"
    output.puts "<section id=\"the-index\">\n    <info><title id=\"the-index.title\">#{$args["-title"] || "How Do I ...?"}</title></info>"
    output.puts index_terms.index_terms2xml
    output.puts "</section>"
  end
  
  $stderr.puts ">>> creating revision entries (file: #{revision_output_file})..."    
  File.open(revision_output_file, "w") do |output|
    output.puts "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
    output.puts "<!DOCTYPE chapter PUBLIC \"-//OASIS//DTD DocBook XML V4.5//EN\" \"file://zonbook/docbookx.dtd\""
    output.puts "["
        output.puts "<!ENTITY % xinclude SYSTEM \"file://AWSShared/common/xinclude.mod\">"
        output.puts "%xinclude;"
        output.puts "<!ENTITY % phrases-shared SYSTEM \"file://AWSShared/common/phrases-shared.ent\"> "
        output.puts "%phrases-shared;           "
    output.puts "]>"
    output.puts "<section id=\"the-revisions\">\n    <info><title id=\"the-revisions.title\">#{$args["-rtitle"] || "What's Changed?"}</title></info>"
    output.puts revision_terms.index_terms2xml
    output.puts "</section>"
  end
end

