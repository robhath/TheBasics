#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"

require 'args.rb'
require 'diff.rb'


  def diff_it(fn1, fn2)
    x = []
    y = []
    xin = File.open(fn1, "r:UTF-8")
    yin = File.open(fn2, "r:UTF-8")
    while line = xin.gets do x << line.chomp end
    while line = yin.gets do y << line.chomp end
    xin.close
    yin.close
    return diff(x, y)
  end  # diff_it


if __FILE__ == $0 then
  
  get_args(nmin: 2, nsyntax: "rdiff.rb <file|directory> <file|directory> [--<ext>] [-exclude <file1>,<file2>,...]")

  puts "====================================="
  puts "Recursive Diff  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
  puts "====================================="

  extensions = ""
  exclusions = []
  $args.each_pair do |akey, aval|
    if akey[0..1] == "--" then
      extensions << "," unless extensions.empty?
      extensions << akey[2..-1]
    elsif akey == "-exclude" then
      exclusions += aval.split(",")
    end
  end
 
  if File.directory?($nargs[0]) then
    if File.directory?($nargs[1]) then
      files0 = Dir.glob("#{$nargs[0]}/**/*#{extensions.empty? ? "" : (".{" + extensions + "}")}")
      files1 = Dir.glob("#{$nargs[1]}/**/*#{extensions.empty? ? "" : (".{" + extensions + "}")}")
      files0.delete_if do |f0| 
        if File.directory?(f0) then
          true  # skip and delete
        else
          i = files1.find_index {|f1| File.basename(f0) == File.basename(f1) }
          if i then
            unless exclusions.index(File.basename(f0)) then
              puts ">>>>> #{f0} vs. #{files1[i]} <<<<<"
              puts diff_it(f0, files1[i]) 
              puts
            end
            files1.delete_at(i)
            true  # delete
          else
            false  # no match found, don't delete
          end
        end
      end

      unless files0.empty? then
        puts ">>>>> The following files in #{$nargs[0]} did not have a match: <<<<<"
        puts files0.join(", ")
        # files0.each {|f0| puts f0 }
        puts
      end
      unless files1.empty? then
        puts ">>>>> The following files in #{$nargs[1]} did not have a match: <<<<<"
        puts files1.join(", ")
        # files1.each {|f1| puts f1 }
        puts
      end
    else
      $stderr.puts "ERROR: cannot compare a file with a directory"
    end
  elsif File.directory?($nargs[1]) then
    $stderr.puts "ERROR: cannot compare a file with a directory"
  else
    puts ">>>>> #{$nargs[0]} vs. #{$nargs[1]} <<<<<"
    puts diff_it($nargs[0], $nargs[1])
    puts
  end

end
