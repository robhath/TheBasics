#!ruby

  if ARGV.length < 2 || ARGV.any? {|obj| obj =~ /^-h/ } then
    $stderr.puts "syntax:  tag-replace.rb tag replacement < filein > fileout"
    exit
  end

  re = Regexp.new("<!--|-->|<(/)?" + ARGV[0] + "(\s|>|$)")
  replace = ARGV[1]

  in_comment = false
  while line = $stdin.gets do
    line.gsub!(re) do |str|
      if in_comment then
        in_comment = false if str == "-->"
        str
      elsif str == "<!--" then
        in_comment = true
        str
      elsif replace.empty? then
        ""
      else
        "<#{$1}#{replace}#{$2}"
      end
    end
    $stdout.puts line
  end
