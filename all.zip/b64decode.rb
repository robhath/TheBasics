#!ruby


require 'base64'

if ARGV.length > 0 then
  ARGV.each do |arg|
    $stdout.puts Base64.decode64(arg)
  end
else
  while line = $stdin.gets do
    $stdout.puts Base64.decode64(line.chomp)
  end
end

