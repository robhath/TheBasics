Wormy is a web (or file system) crawler that searches for every instance of a string that 
matches a regular expression and writes out a file (wormy.html) showing its results.  You 
give it a URL or a file path (or several) as a starting point and it will search in that 
location and in locations linked to from there. The results show a link to the nearest 
heading (chapter or section) that has an id attribute followed by the actual phrase or 
phrases found and some of the surrounding context.

Syntax:
    wormy.rb <path, file or directory> ...  -p <pattern> [-i] [-o <output-directory>] [-depth <integer>] [-toc] [-stay]
    
Parameters:
    -p <pattern>            :  the regular expression to search for
    -i                      :  makes the regular expression case-insensitive
    -o <output-directory>   :  the directory where the output file will be written (the 
                                default is the directory in which wormy is invoked)
    -depth <integer>        :  the recursive depth (how many levels of references from the 
                                original file you wish to go; default is 1)
    -toc                    :  search and process sections marked as tables of contents
    -stay                   :  stay within the first specified domain and don't process 
                                files outside it (e.g. docs.aws.amazon.com)
