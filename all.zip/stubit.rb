#!ruby

$LOAD_PATH << File.dirname($0) + "/lib"


require 'yaml'
require 'json'
require 'stringio'
require 'XML.rb'



if __FILE__ == $0 then
  
  exclusions = %w( x-amazon-apigateway-integration  )
  what = %w( delete  get  post  put )
  what2 = %w( definitions parameters properties responses )
  
  if ARGV.length < 1 then
    $stderr.puts "stubit.rb <path, file or directory> ... [-output <output-filename>]  [-tbd <tbd-string>]"
    exit
  else
    line1 = "STUBIT  #{Time.now.strftime("%b %e %Y  %H:%M:%S")}"
    $stderr.puts line1
    $stderr.puts "=" * line1.length
    $stderr.puts
  end
  
  if i = (ARGV.index("-output") || ARGV.index("-o")) then
    $output_fn = ARGV[i+1]
    ARGV[i+1] = nil
  end

  if i = ARGV.index("-tbd") then
    $tbd_string = ARGV[i+1]
    ARGV[i+1] = nil
  end

  ARGV.each do |arg|
    next if arg.nil? || arg[0,1] == "-"
  
    if File.directory?(arg) then
      a = Dir.glob("#{arg}/**/*.{json,txt,yaml,yml}")
    else
      a = [arg]
    end
    
    a.each do |fn|
      next if File.directory?(fn)
      $stderr.puts fn
  
      y = YAML.load_file(fn)
      if y.nil? || !y || y.empty? then
        $stderr.puts "    something's wrong... skipping file!"
        next
      end
      
      y.cwalk([]) do |key, value, context|
        #~ $stderr.puts "key=#{key} value=#{(value.respond_to?(:each) ? "..." : value.to_s)} context=#{context.join(",")}"
        if !exclusions.any? {|e| context.index(e) } &&
              (what.index(key) || what2.index(context.last)) &&
              value.respond_to?(:each_pair) && (!value.has_key?("description") || value["description"].empty?) && !value.has_key?("$ref") then
          $stderr.puts "  adding description to: key=#{key} context=[#{context.join(",")}]"
          value["description"] = ($tbd_string || "TBD")
        end
      end
      
      if $output_fn then
        if a.length > 1 then
          output = File.open($output_fn, "a:UTF-8")
        else
          output = File.open($output_fn, "w:UTF-8")
        end
        $stderr.puts "  --> #{$output_fn}"
        output.puts JSON.pretty_generate(y)
        output.close
      else
        $stdout.puts JSON.pretty_generate(y)
      end

    end  # a.each
  end

end

